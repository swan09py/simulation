"""
Implementation of DDPG - Deep Deterministic Policy Gradient
Algorithm and hyperparameter details can be found here:
    http://arxiv.org/pdf/1509.02971v2.pdf
The algorithm is tested on the Pendulum-v0 OpenAI gym task
and developed with tflearn + Tensorflow
Author: Patrick Emami
"""
import tensorflow as tf
import numpy as np
import gym
from gym import wrappers
import tflearn
import argparse
import pprint as pp
from scipy import io
import math
import matplotlib.pyplot as plt
import time
import random
import scipy.io as sio
import mosek
import sys
import copy
import operator
import itertools

from replay_buffer import ReplayBuffer
from uplink_scenario_no_interference import UplinkScenarioNoInterference

pi = 3.1415926925
inf = 1e+9


# Define a stream printer to grab output from MOSEK
def stream_printer(text):
    sys.stdout.write(text)
    sys.stdout.flush()


def mkdir(path):
    """
    this function is used to create a path for saving results
    generated during the process of running the program !
    :param path:
    :return: True if it creates a dictionary; otherwise, False if the dictionary already exists
    """
    import os

    path = path.strip()
    path = path.rstrip("\\")

    isExists = os.path.exists(path)

    if not isExists:
        os.makedirs(path)

        print(path + ' Successfully Created!')

        return True
    else:
        print(path + ' Document has Existed!')

        return False

# ===========================
#   Agent Training
# ===========================

def train_uplink(sess, env_task, args, path,
                 ap_location, user_location_collection, seq_len_min_index,
                 interfering_user_list, interfering_user_array, num_groups, user_height):
    # Set up summary Ops
    mkdir(path)

    # Initialize the scenario
    uplink_scenario = UplinkScenarioNoInterference(env_task,
                                     float(args['noise_power']),
                                     float(args['uplink_bandwidth']),
                                     int(args['ap_number']),
                                     float(args['uplink_QoS']),
                                     float(args['alpha']),
                                     int(args['user_number']),
                                     interfering_user_list,
                                     interfering_user_array,
                                     num_groups,
                                     10**(float(args['inst_total_user_power'])/10) -
                                     10**(float(args['user_circuit_power'])/10),
                                     float(args['rayleigh_gain'])
                                     )
    # Initialize the interfering indicator matrix
    uplink_scenario.initialize_interfering_indicator_matrix()

    # (Awaiting) should call a function to obtain [Q]^+ vector
    q_plus = np.ones((int(args['user_number']),))
    q_collection = []
    for i_q in range(int(args['user_number'])):
        q_collection.append([100.])
    # tradeoff_coefficient_v = 200

    reward_t_collection = []
    count_t = 0
    train_iter = 0
    sum_time = time.time()

    # update the users' locations every x times
    # obtain a user's location
    user_location = []
    for num_user in range(int(args['user_number'])):
        user_i_loc = user_location_collection[num_user]  # a 2-array in R^{T * 2}
        # get the user location at time slot t = 10
        user_location.append(user_i_loc[:, 0].tolist())
    user_location = np.array(user_location)  # all users' locations

    for i in range(int(args['max_episodes'])):
        ep_reward_up = 0
        ep_ave_max_q_up = 0
        # #  ----------  start the epoch  --------------
        #         each episode include J epoch
        # # --------------------------------------------
        for j in range(int(args['max_episode_len'])):
            # update the users' locations every x times
            if int(train_iter % int(np.ceil(int(args['max_episode_len']) * int(args['max_episodes']) /
                                             len(user_location_collection[seq_len_min_index][0, :])))) == 0:
                # obtain a user's location
                user_location = []
                for num_user in range(int(args['user_number'])):
                    user_i_loc = user_location_collection[num_user]  # a 2-array in R^{T * 2}
                    # get the user location at time slot t = 10
                    user_location.append(user_i_loc[:, count_t].tolist())
                user_location = np.array(user_location)  # all users' locations

                count_t += 1

            # ========================
            #           Calculate the power matrix R^{I * J}
            # ========================
            power_matrix = uplink_scenario.uplink_power(user_location, ap_location, user_height,
                                                        float(args['ap_height']))
            # Generate the candidate action by assigning users to their closet APs
            candidate_action = np.zeros((int(args['user_number']), int(args['ap_number'])))
            for i_user_index in range(int(args['user_number'])):
                j_indices = np.argmin(power_matrix[i_user_index])
                candidate_action[i_user_index][j_indices] = 1

            # check whether the candidate action violate the service ability constraints
            # candidate_action_sel = copy.deepcopy(candidate_action)
            ap_sum = np.sum(candidate_action, 0)
            service_ability_indicator = np.sum(ap_sum > int(args['ap_uplink_serving_users']))
            t_count = 0
            while service_ability_indicator:  # it indicates that the service ability constraint is violated
                ap_sum = np.sum(candidate_action, 0)
                max_vio_index = ap_sum.argmax()  # the j_star
                active_power = np.multiply(power_matrix[:, max_vio_index], candidate_action[:, max_vio_index])
                # Step 1: serving which user violates the AP service ability constraint
                active_power_descend_idx = active_power.argsort()[::-1]
                sel_idx = int(ap_sum[max_vio_index] - int(args['ap_uplink_serving_users']))
                service_vio_idx = active_power_descend_idx[:sel_idx]
                # Step 2: move user i_star's AP access to another AP consuming more power to serve the user i_star
                for vio_idx in service_vio_idx.tolist():  # the i_star
                    value = 1e+6
                    j_ap_sel = max_vio_index
                    for j_ap_index in range(args['ap_number']):
                        power_difference = power_matrix[vio_idx][j_ap_index] - power_matrix[vio_idx][max_vio_index]
                        if (power_difference > 1e-6) & (power_difference <= value):
                            value = power_difference
                            j_ap_sel = j_ap_index
                    # move user i_star's AP access to a more power consumption AP
                    candidate_action[vio_idx][max_vio_index] = 0
                    candidate_action[vio_idx][j_ap_sel] = 1
                # update the service ability indicator
                ap_sum = np.sum(candidate_action, 0)
                service_ability_indicator = np.sum(ap_sum > int(args['ap_uplink_serving_users']))
                t_count = t_count + 1

            # check the power consumption constraint # if not feasible, then set it zero
            power_testing_matrix = np.multiply(candidate_action, power_matrix)
            power_testing_matrix = np.where(power_testing_matrix > 10**(float(args['inst_total_user_power'])/10) -
                                     10**(float(args['user_circuit_power'])/10), 1, 0)
            for i_user_index in range(int(args['user_number'])):
                if np.sum(power_testing_matrix[i_user_index]) > 0.9:  # set the power constraint violation be zero
                    candidate_action[i_user_index] = np.zeros((int(args['ap_number']), ))

            # Given the candiate action, calculate the power consumption of users
            user_power, feasible_up = uplink_scenario.uplink_optimization(candidate_action,
                                                                          user_location, ap_location,
                                                                          q_plus, user_height, float(args['ap_height']))
            assert feasible_up is True
            if feasible_up:
                power_sum = np.dot(10 ** (float(args['user_circuit_power']) / 10) + np.array(user_power),
                                   np.sum(candidate_action, 1)) / \
                            (10 ** (float(args['average_total_user_power']) / 10) *
                             np.sum(candidate_action))

                # calculate the maximize - f(p_t), for maximizing - f(p_t)
                r_up = - power_sum + float(args['tradeoff_coefficient_v']) / \
                                                      int(args['user_number']) * \
                                                      int(np.sum(np.max(candidate_action, 1)))
            else:
                r_up = 0
                print("The selected action was imfeasible!")

            print("r[" + str(train_iter) + "]=" + str(r_up))

            ep_reward_up += r_up
            train_iter += 1
            reward_t_collection.append(r_up)

    # # plot the loss value of the critic network
    # plt.figure(3)
    # plt.plot(reward_t_collection)
    # plt.show()
    # pass
    file_name = 'Heuristic_uplink_reward_t_value_' + str(int(args['user_number'])) + '.mat'
    io.savemat(file_name, {'reward_t_value': reward_t_collection})


def main(args):
    start_time = time.time()
    # gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=0.7)
    with tf.Session() as sess:

        # env = gym.make(args['env'])
        np.random.seed(int(args['random_seed']))
        tf.set_random_seed(int(args['random_seed']))
        # env.seed(int(args['random_seed']))

        # generate user locations
        # (Awaiting) load the original data
        user_location_collection = []
        user_location_len = []
        min_x = []
        min_y = []
        max_x = []
        max_y = []
        for num_user in range(int(args['user_number'])):
            data_path = 'C:/Users/swan/PycharmProjects/Federated_ESN_VR/original_data_sets/Predicted_Trajectory_' + \
                        str(num_user + 1) + '.mat'
            data = sio.loadmat(data_path)
            print(data.keys())
            # ori_data = data['userInterpLocations']  # a 2-array in R^{T*2}
            ori_data = data['predicted_trajectory']

            min_x.append(np.min(ori_data[:, 0]))
            min_y.append(np.min(ori_data[:, 1]))
            max_x.append(np.max(ori_data[:, 0]))
            max_y.append(np.max(ori_data[:, 1]))

            # find the minimum sequence length of all user data
            user_location_len.append(len(ori_data[:, 0]))
            user_location_collection.append(ori_data)  # a list including 64 2-arrays

        # obtain the boundary of user locations
        min_loc_x = np.min(min_x)
        min_loc_y = np.min(min_y)
        max_loc_x = np.max(max_x)
        max_loc_y = np.max(max_y)

        # calculate the radius of a circular communication coverage region
        radius_comm = np.sqrt((max_loc_y - min_loc_y) ** 2 + (max_loc_x - min_loc_x) ** 2) / 2

        # obtain the aps' locations
        ap_location = np.zeros((int(args['ap_number']), 2))
        for j in range(int(args['ap_number'])):
            ap_location[j, 0] = radius_comm * np.cos(2 * np.pi / int(args['ap_number']) * j) + radius_comm
            ap_location[j, 1] = radius_comm * np.sin(2 * np.pi / int(args['ap_number']) * j) + radius_comm

        seq_len_min_index = user_location_len.index(min(user_location_len))

        # generate the users' heights
        user_height = np.random.normal(float(args['user_height']),
                                       float(args['user_height_std']), int(args['user_number']))

        # clustering users into four groups, where only users in the same group will interfere with each other
        interfering_user_list = list(range(int(args['user_number'])))
        np.random.shuffle(interfering_user_list)
        interfering_user_array = \
            np.reshape(interfering_user_list, (int(args['user_groups']),
                                                int(int(args['user_number'])/int(args['user_groups']))))  # a 2-array

        Run = False
        # Run = True  # testing
        if not Run:
            path = 'Simulation_results_collection'
            with mosek.Env() as env_task:
                # create mosek task
                train_uplink(sess, env_task, args, path,
                             ap_location, user_location_collection, seq_len_min_index,
                             interfering_user_list, interfering_user_array, int(args['user_groups']), user_height)

        # print the running time of this program
        print("The running time of this program is --- %.4f seconds ---" % (time.time() - start_time))
        # if args['use_gym_monitor']:
        #     env.monitor.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='provide arguments for DDPG agent')

    # agent parameters
    parser.add_argument('--actor-lr', help='actor network learning rate', default=0.01)
    # parser.add_argument('--critic-lr', help='critic network learning rate', default=0.01)
    parser.add_argument('--gamma', help='discount factor for critic updates', default=0.99)
    parser.add_argument('--tau', help='soft target update parameter', default=0.001)
    parser.add_argument('--buffer-size', help='max size of the replay buffer', default=1000000)  # 1000000
    parser.add_argument('--minibatch-size', help='size of minibatch for minibatch-SGD', default=256)  # 1024
    parser.add_argument('--forgot-len', help='length of initial forgotten samples', default=200)  # 1024
    parser.add_argument('--training-interval', help='training interval', default=10)  # 10
    # deployment scenario parameters
    # user configuration
    parser.add_argument('--average-total-user-power', help='the average total user power', default=28.5)  # in dBm 700
    parser.add_argument('--inst-total-user-power', help='the total instant user power', default=27.0)  # in dBm
    parser.add_argument('--user-circuit-power', help='user circuit power', default=23.0)  # in dBm
    parser.add_argument('--noise-power', help='noise power', default=-167.0)  # 107.0
    parser.add_argument('--uplink-bandwidth', help='uplink bandwidth', default=200)  # in MHz, 20MHz  4GHz/num_groups
    parser.add_argument('--user-number', help='the number of users', default=20)  # 64
    parser.add_argument('--user-groups', help='the group number of users', default=22)  # classify users into 4 groups
    parser.add_argument('--alpha', help='the path loss coefficient', default=5)  # 2-4
    parser.add_argument('--tradeoff-coefficient-v', help='the tradeoff coefficient value V', default=1)  # 200
    parser.add_argument('--uplink-QoS', help='the QoS of uplink transmission', default=200)  # .2 in times or 20 dB

    parser.add_argument('--user-height', help='the height of a user', default=1.8)
    parser.add_argument('--user-height-std', help='the standard variance of the height of a user', default=0.05)
    parser.add_argument('--rayleigh-gain', help='the Rayleigh channel gain', default=0.3)


    # ap configuration
    parser.add_argument('--ap-power', help='the ap power', default=230.0)
    parser.add_argument('--ap-inst-power', help='the instant ap power', default=30.0)
    parser.add_argument('--downlink-bandwidth', help='the downlink bandwidth', default=200)  # in MHz
    parser.add_argument('--ap-number', help='the number of aps', default=3)
    parser.add_argument('--antenna-number', help='the number of antennas', default=2)
    parser.add_argument('--downlink-QoS', help='the QoS of downlink transmission', default=0.02)
    parser.add_argument('--eta-LoS', help='max length of 1 episode for test', default=2.0)
    parser.add_argument('--eta-NLoS', help='max length of 1 episode for test', default=2.4)
    parser.add_argument('--sigma-LoS', help='max length of 1 episode for test', default=5.3)
    parser.add_argument('--sigma-NLoS', help='max length of 1 episode for test', default=5.27)
    parser.add_argument('--light-speed', help='max length of 1 episode for test', default=3e+8)
    parser.add_argument('--carrier-frequency', help='the carrier frequency of downlink transmission', default=2.8e+10)
    parser.add_argument('--ap-downlink-serving-users', help='number of downlink serving users of the ap', default=6)
    parser.add_argument('--ap-uplink-serving-users', help='number of uplink serving users of the ap', default=8)
    parser.add_argument('--ap-height', help='height of an ap', default=5.5)

    parser.add_argument('--max-episode-len-test', help='max length of 1 episode for test', default=5000)

    # run parameters
    parser.add_argument('--env', help='choose the gym env- tested on {Pendulum-v0}', default='Pendulum-v0')
    parser.add_argument('--random-seed', help='random seed for repeatability', default=1234)
    parser.add_argument('--max-episodes', help='max num of episodes to do while training', default=1)  # 2000
    parser.add_argument('--max-episode-len', help='max length of 1 episode', default=5000)  # 2000
    parser.add_argument('--render-env', help='render the gym env', action='store_true')
    parser.add_argument('--use-gym-monitor', help='record gym results', action='store_true')
    parser.add_argument('--monitor-dir', help='directory for storing gym results', default='./results/gym_ddpg')
    parser.add_argument('--summary-dir', help='directory for storing tensorboard info', default='./results/tf_ddpg')

    parser.set_defaults(render_env=False)
    parser.set_defaults(use_gym_monitor=True)

    args = vars(parser.parse_args())

    pp.pprint(args)

    main(args)