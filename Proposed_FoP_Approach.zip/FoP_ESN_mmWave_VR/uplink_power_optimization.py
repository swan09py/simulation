import mosek
import sys
import numpy as np
import scipy.io as sio

# Since the value of infinity is ignored, we define it solely
# for symbolic purposes
inf = 0.0


# Define a stream printer to grab output from MOSEK
def stream_printer(text):
    sys.stdout.write(text)
    sys.stdout.flush()


def dis_calculate(user_index, ap_index, user_location, ap_location):
    distance = np.sqrt(np.sum(list(map(lambda x: (x[0]-x[1]) ** 2, zip(user_location[user_index], ap_location[ap_index])))))
    # distance = np.sqrt(np.sum(user_location[user_index][i] - ap_location[ap_index][i]
    #                           for i in range(len(user_location[user_index]))))
    return distance


def uplink_power_optimization():
    # make a mosek environment
    with mosek.Env() as env:
        # create mosek task
        with env.Task(0, 0) as task:
            task.set_Stream(mosek.streamtype.log, stream_printer)

            # (Awaiting) Initialize the parameters
            num_user = 4
            num_ap = 3
            theta_th = 0.200
            single_noise_power = 2e-12  # in mW/Hz
            band_ul = 2e+7  # in MHz
            alpha = 2

            # (Awaiting) load the original data
            path = 'C:/Users/swan/PycharmProjects/Federated_ESN_VR/original_data_sets/locationInterpCartesian_64.mat'
            data = sio.loadmat(path)
            print(data.keys())
            ori_data = data['userInterpLocations']

            # user_location = ori_data[:, [0, 1]]  # it is an array
            user_location = [[0, 0], [150, 150], [600, 200], [300, 360]]
            ap_location = [[100.0, 200.0], [400.0, 600.0], [330.0, 460.0]]  # it is a list

            # (Awaiting) should call a function to obtain [Q]^+ vector
            q_plus = np.ones((num_user,))

            # (Awaiting) obtain a_ij_ul, it should be a two-dimensional array
            a_ij_ul = np.zeros((num_user, num_ap))
            for i_user in range(num_user):
                j_index = np.mod(i_user, num_ap)
                a_ij_ul[i_user][j_index] = 1
            # a_ij_ul[0][0] = 0  # in this way, for instance the 1st user cannot access any AP
            a_ij_ul[3][0] = 0

            # bound keys for constraints and variables
            bkc = []
            for i_user in range(num_user):
                for j_ap in range(num_ap):
                    if a_ij_ul[i_user][j_ap] == 1:
                        bkc.append(mosek.boundkey.lo)

            bkx = [mosek.boundkey.lo] * num_user
            # bkx = np.tile(bkx, num_user)

            # bound value for constraints and variables
            blc = []
            buc = []
            for i_user in range(num_user):
                for j_ap in range(num_ap):
                    if a_ij_ul[i_user][j_ap] == 1:
                        blc.append(theta_th * single_noise_power * band_ul)
                        buc.append(+inf)

            blx = [0.0000] * num_user
            bux = [+inf] * num_user

            # objective coefficients
            c = []
            for i_user in range(num_user):
                c.append(q_plus[i_user])

            # obtain the value of A
            # calculate the number of constraints
            numcons = len(bkc)
            numvars = len(bkx)
            asub = np.tile(range(numcons), (num_user, 1))
            aval = np.zeros((num_user, numcons))

            # obtain the ap index connecting to each active user
            j_star_cons = []
            for i_user in range(num_user):
                for j_ap in range(num_ap):
                    if a_ij_ul[i_user][j_ap] == 1:
                        j_star_cons.append(j_ap)

            assert len(j_star_cons) == numcons, "the length of j_star corresponding to constraints must be numcons"

            index_unaccess = []
            for i_user in range(num_user):
                j_star = None
                for j_ap in range(num_ap):
                    if a_ij_ul[i_user][j_ap] == 1:
                        j_star = j_ap

                if j_star is None:
                    index_unaccess.append(i_user)  # record the index of a user cannot access to an AP
                    aval[i_user] = [0.] * numcons
                else:
                    num_unaccess = len(index_unaccess)
                    for cons_index in range(numcons):
                        disval = dis_calculate(i_user,
                                               j_star_cons[cons_index], user_location, ap_location)
                        if cons_index == i_user - num_unaccess:
                            # disval = dis_calculate(i_user,
                            #                        a_ij_ul[i_user].tolist().index(1), user_location, ap_location)
                            aval[i_user][cons_index] = disval ** (-alpha)
                        else:
                            # disval = dis_calculate(i_user,
                            #                        j_star_cons[cons_index], user_location, ap_location)
                            aval[i_user][cons_index] = - theta_th * disval ** (-alpha)  # the sum(a_ij) is not needed
                            # because if i is active, then it must be an interference user to other active users

            # Append 'numcons' empty constraints
            task.appendcons(numcons)

            # Append 'numvars' variables
            task.appendvars(numvars)

            for j in range(numvars):
                # set the objective function
                task.putcj(j, c[j])

                # set the bounds on variables
                task.putvarbound(j, bkx[j], blx[j], bux[j])

                # set the expression of A
                task.putacol(j, asub[j], aval[j])

            # set the bounds on constraints
            for i in range(numcons):
                task.putconbound(i, bkc[i], blc[i], buc[i])

            # input the objective sense
            task.putobjsense(mosek.objsense.minimize)

            # solve the optimization problem
            task.optimize()

            # print a summary of containing information
            task.solutionsummary(mosek.streamtype.msg)

            # get state information about the solution
            solsta = task.getsolsta(mosek.soltype.bas)

            if (solsta == mosek.solsta.optimal or
                    solsta == mosek.solsta.near_optimal):
                xx = [0.] * numvars
                task.getxx(mosek.soltype.bas, xx)
                print("The optimal solution:")
                for i in range(numvars):
                    print("x[" + str(i) + "]=" + str(xx[i]))
            elif (solsta == mosek.solsta.dual_infeas_cer or
                  solsta == mosek.solsta.prim_infeas_cer or
                  solsta == mosek.solsta.near_dual_infeas_cer or
                  solsta == mosek.solsta.near_prim_infeas_cer):
                print("Primal or dual infeasibility certification found! \n")
            elif solsta == mosek.solsta.unknown:
                print("Unknown solution status! \n")
            else:
                print("Other solution status!")


# call the main function
try:
    uplink_power_optimization()
except mosek.Error as e:
    print("ERROR: %s" % str(e.errno))
    if e.msg is not None:
        print("\t %s" % e.msg)
        sys.exit(-1)
except:
    import traceback
    traceback.print_exc()
    sys.exit(-1)










