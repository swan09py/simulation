
import pprint as pp
import argparse
import numpy as np
import scipy.io as sio
import matplotlib.pyplot as plt
import sys
import mosek

from collections import defaultdict

from echoStateNetwork import EchoStateNetwork
from comput_nrmse import ComputeNRMSE
from federated_learning_local import FederatedLearningLocal
from genetic_federated_learning import GeneticFederatedLearning

# Since the value of infinity is ignored, we define it solely
# for symbolic purposes
inf = 0.0


# Define a stream printer to grab output from MOSEK
def stream_printer(text):
    sys.stdout.write(text)
    sys.stdout.flush()


def main(args):
    # load the original data
    for num_user in [17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31]: #range(int(args['number_user'])):
        path = 'C:/Users/swan/PycharmProjects/Federated_ESN_VR/original_data_sets/Pedestrian_Trajectory_Cartesian_' + \
               str(num_user + 1) + '.mat'
        data = sio.loadmat(path)
        # print(data.keys())
        ori_data = data['userInterpLocations']
        input_data = np.zeros((len(ori_data[:, 0]), int(args['input_len'])))
        xy_predict = []

        for xy_ind in range(2):
            input_data[:, 0] = ori_data[:, xy_ind]
            # input_data[:, 0] = ori_data[:, 1]
            # input_data[:, 1] = ori_data[:, 1]
            x_loc = input_data[:, 0]

            max_loc = np.max(x_loc)
            min_loc = np.min(x_loc)

            federated_learning = FederatedLearningLocal(int(args['number_ap']),
                                                        int(args['train_len']) - int(args['forget_len']),
                                                        int(args['federated_episode']), int(args['output_len']),
                                                        int(args['input_len']), int(args['reservoir_size']),
                                                        int(args['train_len']), int(args['forget_len']),
                                                        int(args['predict_size']),
                                                        float(args['leak_rate']),
                                                        float(args['teacher_scale']), float(args['teacher_shift']),
                                                        float(args['input_scale']), float(args['input_shift']),
                                                        float(args['ksi']), float(args['kappa']), max_loc, min_loc)

            # genetic_federated_learning = GeneticFederatedLearning(int(args['number_ap']), int(args['train_len']) - int(args['forget_len']),
            #                                        int(args['federated_episode']), int(args['output_len']),
            #                                        int(args['input_len']), int(args['reservoir_size']),
            #                                        int(args['train_len']), int(args['forget_len']), int(args['predict_size']),
            #                                        float(args['leak_rate']),
            #                                        float(args['teacher_scale']), float(args['teacher_shift']),
            #                                        float(args['input_scale']), float(args['input_shift']),
            #                                        float(args['ksi']), float(args['kappa']))

            # train the ESN network:
            # # Method (1): the centralized ESN method
            # weight_output, x_state = echo_state_network.train_esn(input_data)
            # # test the ESN network, input from 'train_len', and predict the value from 'train_len + 1'
            # y_Q = echo_state_network.predict_esn(input_data[int(args['train_len'])].reshape(int(args['input_len']), 1),
            #                                      weight_output, x_state)  # in N_o * Q

            # # Method (2): the federated learning method based training method
            sample_indices = [[0], [2, 5, 3], [4, 1]]
            predict_times = int(args['predict_time'])  # the predicting times
            start_train = True
            # the initialized network state of the next training
            predict_x_state = 0
            trained_len = int(args['train_len']) - int(args['forget_len'])
            y_predict = []

            for t in range(predict_times):
                # u_predict_index: the index of the input data for prediction
                u_predict_index = int(args['forget_len']) + trained_len + int(args['predict_size']) * t
                # data_start_index: the index of the first input data for training
                u_start_train_index = u_predict_index - trained_len
                weight_output, train_error, start_train = \
                    federated_learning.train_esn(input_data, sample_indices, u_start_train_index,
                                                 start_train, predict_x_state)
                y_Q, predict_x_state = \
                    federated_learning.predict_esn(input_data[u_predict_index].reshape(int(args['input_len']), 1),
                                                   weight_output)  # in N_o * Q
                y_predict.append(y_Q)
                # measure the predicted value
                # Initialize the NRMSE computation class
                compute_nrmse = ComputeNRMSE()
                error_len = int(args['predict_size'])
                input_data_Q = input_data[u_predict_index + 1:u_predict_index + error_len + 1, :].T

                for i_len in range(int(args['input_len'])):
                    nrmse = compute_nrmse.compute_nrmse(y_Q[i_len, 0: error_len],
                                                        input_data_Q[i_len, 0: error_len])
                    print('NRMSE = {0}'.format(str(nrmse)))
                # nrmse = compute_nrmse.compute_nrmse([i for j in y_Q for i in j],
                #                                     input_data[int(args['train_len'])+1:(int(args['train_len'])+error_len+1)])
                # print(nrmse)
            # weight_output, train_error, start_train = \
            #     federated_learning.train_esn(input_data, sample_indices, int(args['forget_len']),
            #                                  start_train, predict_x_state)
            # y_Q = federated_learning.predict_esn(input_data[int(args['train_len'])].reshape(int(args['input_len']), 1),
            #                                      weight_output)  # in N_o * Q
            # # Method (3): the genetic federated learning method based training method
            # weight_output, x_state, x_matrix, train_error = genetic_federated_learning.train_esn(input_data)
            # y_Q = genetic_federated_learning.predict_esn(input_data[int(args['train_len'])].reshape(int(args['input_len']), 1),
            #                                      weight_output, x_state)  # in N_o * Q

            # plot the figure
            t_x = range(error_len * predict_times)
            # collect the predicted value
            y_collection_0 = []
            for t in range(predict_times):
                y_collection_0.append(y_predict[t][0, :])
            y_collection_0 = [j for i in y_collection_0 for j in i]
            # plot the figure to verify the prediction accuracy
            plt.figure(1).clear()
            plt.plot(t_x, y_collection_0, "g-", label="Free-running predicted signal")
            plt.plot(t_x,
                     input_data[int(args['train_len']) + 1:(error_len * predict_times + int(args['train_len']) + 1), 0],
                     "r-.", label="Target signal", linewidth=2)
            #
            plt.axis([t_x[0], t_x[-1], np.min(y_collection_0) - 10.0, np.max(y_collection_0) + 10.0])
            plt.xlabel("t")
            plt.ylabel("v")
            plt.title("Target and generated signals y(n) starting at n=0")

            plt.grid(True)
            plt.legend()
            plt.show()

            xy_predict.append(y_collection_0)

        # save the prediction results of each user's Trajectory
        prediction_save_path = 'C:/Users/swan/PycharmProjects/Federated_ESN_VR/original_data_sets/Predicted_Trajectory_' + \
                           str(num_user + 1) + '.mat'
        sio.savemat(prediction_save_path, {'predicted_trajectory': np.array(xy_predict)})

    # plt.figure(2).clear()
    # plt.plot(t, y_Q[1, range(error_len)], "g-", label="Free-running predicted signal")
    # plt.plot(t, input_data[int(args['train_len']) + 1:(error_len + int(args['train_len']) + 1), 1],
    #          "r-.", label="Target signal", linewidth=2)
    # plt.axis([t[0], t[-1], np.min(y_Q[1]) - 10.0, np.max(y_Q[1]) + 10.0])
    # plt.xlabel("t")
    # plt.ylabel("v")
    # plt.title("Target and generated signals y(n) starting at n=0")
    # plt.grid(True)
    # plt.legend()
    # plt.show()

    # begin to solve an optimization problem
    # Make mosek environment
    with mosek.Env() as env:
        # Create a task object
        with env.Task(0, 0) as task:
            # Attach a log stream printer to the task
            task.set_Stream(mosek.streamtype.log, stream_printer())





if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='provide arguments for the FL ESN VR scenario!')

    # ESN parameters
    parser.add_argument('--input-len', help='input length of the ESN network', default=1)
    parser.add_argument('--output-len', help='output length of the ESN network', default=1)
    parser.add_argument('--reservoir-size', help='size of the reservoirs', default=300)
    parser.add_argument('--leak-rate', help='leaking rate', default=0.001)  # 0.3
    parser.add_argument('--forget-len', help='length of the forget samples', default=104)  # 104
    parser.add_argument('--train-len', help='length of the training samples', default=110)  # 109
    parser.add_argument('--predict-size', help='length of the prediction points', default=8)  # 10
    parser.add_argument('--predict-time', help='times of the prediction', default=140)  # 10
    parser.add_argument('--teacher-scale', help='the scaling value of the teacher', default=1.0)
    parser.add_argument('--teacher-shift', help='the shift value of the teacher', default=0.0)
    parser.add_argument('--input-scale', help='the scaling value of the input', default=1.0)
    parser.add_argument('--input-shift', help='the shift value of the input', default=0.0)

    parser.add_argument('--number-user', help='the number of users', default=16)

    # Federated learning parameters
    parser.add_argument('--federated-episode', help='the episode of federated learning', default=1000)
    parser.add_argument('--number-ap', help='the number of APs', default=3)
    parser.add_argument('--ksi', help='the parameter ksi', default=0.25)  # ksi = kappa / 4
    parser.add_argument('--kappa', help='the parameter kappa', default=1.0)

    # # run parameters
    # parser.add_argument('--env', help='choose the gym env- tested on {Pendulum-v0}', default='Pendulum-v0')
    # parser.add_argument('--random-seed', help='random seed for repeatability', default=1234)
    # parser.add_argument('--max-episodes', help='max num of episodes to do while training', default=50000)
    # parser.add_argument('--max-episode-len', help='max length of 1 episode', default=1000)
    # parser.add_argument('--render-env', help='render the gym env', action='store_true')
    # parser.add_argument('--use-gym-monitor', help='record gym results', action='store_true')
    # parser.add_argument('--monitor-dir', help='directory for storing gym results', default='./results/gym_ddpg')
    # parser.add_argument('--summary-dir', help='directory for storing tensorboard info', default='./results/tf_ddpg')
    #
    # parser.set_defaults(render_env=False)
    # parser.set_defaults(use_gym_monitor=True)

    args = vars(parser.parse_args())

    pp.pprint(args)

    main(args)
