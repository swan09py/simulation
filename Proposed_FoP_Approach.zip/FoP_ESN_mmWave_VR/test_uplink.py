





if mode is 'OP':
    path = path + '/OP_DNN_UL_training'
    mkdir(path)
elif mode is 'KNN':
    path = path + '/KNN_DNN_UL_training'
    mkdir(path)
else:
    print('The mode must be OP or KNN!')

    minibatch_size
    training_interval
    actor_lr
