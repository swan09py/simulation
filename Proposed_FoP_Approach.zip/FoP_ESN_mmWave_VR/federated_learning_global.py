
import numpy as np
from numpy import linalg as LA


class FederatedLearning:
    def __init__(self, num_ap, num_samples, federated_episode, outSize, inSize, resSize, trainLen, initLen, testLen,
                 leak_rate, teacher_scaling, teacher_shift, input_scaling, input_shift, ksi, kappa):
        self.num_ap = num_ap  # K
        self.outSize = outSize  # N_o
        self.num_samples = num_samples  # Q
        self.inSize = inSize  # N_i
        self.resSize = resSize  # N_r
        self.trainLen = trainLen
        self.initLen = initLen
        self.testLen = testLen
        self.leakRate = leak_rate
        self.teacherScaling = teacher_scaling
        self.teacherShift = teacher_shift
        self.inputScaling = input_scaling
        self.inputShift = input_shift
        self.ksi = ksi
        self.kappa = kappa
        self.T = federated_episode
        self.weight_in = 0
        self.weight_reservoir = 0
        self.x_matrix = 0
        self.y_matrix = 0

        # given the desired output matrix Y

    def generate_A_matrix(self):
        # np.random.seed(4)
        a_matrix = np.random.random((self.num_ap * self.num_samples, self.outSize))

        return a_matrix

    def generate_Zk_matrix(self, k_index):
        zk_matrix = np.zeros((self.num_ap * self.num_samples, self.num_ap * self.num_samples))
        k_identity = np.identity(self.num_samples)
        zk_matrix[self.num_samples*k_index:(k_index+1)*self.num_samples, self.num_samples*k_index:(k_index+1)*self.num_samples] = k_identity

        return zk_matrix

    def initialize_Ak_matrix(self, k_index, a_ini_matrix):
        ak_matrix = np.dot(self.generate_Zk_matrix(k_index), a_ini_matrix)

        return ak_matrix

    def generate_Xk_matrix(self, k_index, x_matrix):
        xk_matrix = np.dot(x_matrix, self.generate_Zk_matrix(k_index))

        return xk_matrix

    def initialize_V_matrix(self, x_matrix):
        v_matrix = np.zeros((self.inSize + self.resSize, self.outSize))
        for k in range(self.num_ap):
            v_matrix = v_matrix + np.dot(self.generate_Xk_matrix(k, x_matrix),
                                         self.initialize_Ak_matrix(k, self.generate_A_matrix()))
        v0_matrix = 1 / (self.ksi * self.num_ap * self.num_samples) * v_matrix.transpose()

        return v0_matrix  # in R^{N_o * (N_i + N_r)}

    def generate_Yk_matrix(self, k_index, y_matrix):
        yk_matrix = np.dot(self.generate_Zk_matrix(k_index), y_matrix)

        return yk_matrix

    # # Generate the input and reservior weight matrix
    def generate_input_weight(self, rand_scaling):
        # return (np.random.random((self.resSize, self.inSize)) - 0.5) * rand_scaling
        # np.random.seed(66)
        return (np.random.random((self.resSize, self.inSize))) * rand_scaling

    def generate_reservoir_weight(self, rand_scaling):
        # np.random.seed(77)
        # weight = (np.random.random((self.resSize, self.resSize)) - 0.5) * rand_scaling
        weight = (np.random.random((self.resSize, self.resSize))) * rand_scaling
        w, vec = LA.eig(weight)
        max_w = np.max(np.abs(w))
        # max_w = np.nan

        while np.isnan(max_w):
            # weight = (np.random.random((self.resSize, self.resSize)) - 0.5) * rand_scaling
            weight = (np.random.random((self.resSize, self.resSize))) * rand_scaling
            w, vec = LA.eig(weight)
            max_w = np.max(np.abs(w))

        weight = weight * (1.25 / max_w)

        return weight

    def train_esn(self, input_data):
        H_batch = np.zeros((self.resSize + self.inSize, self.trainLen - self.initLen))
        y_target_batch = self.teacherScaling * \
                         input_data[self.initLen + 1:self.trainLen + 1, :] + self.teacherShift  # a 2-array
        # y_t_collections = np.reshape(y_t_collections, (1, self.trainLen-self.initLen))

        x_state = np.zeros((self.resSize, 1))
        self.weight_in = self.generate_input_weight(rand_scaling=1.0)
        self.weight_reservoir = self.generate_reservoir_weight(rand_scaling=1.0)

        for t in range(self.trainLen):
            u = self.inputScaling * input_data[t].reshape((self.inSize, 1)) + self.inputShift  # a 2-array
            x_state = (1 - self.leakRate) * x_state + self.leakRate * \
                      np.tanh(np.dot(self.weight_in, u) +
                              np.dot(self.weight_reservoir, x_state))  # a 2-array
            # x_state = (weight_in * u +
            #                   np.dot(weight_reservoir, x_state))
            if t >= self.initLen:  # the empty-operation execution
                H_batch[:, t - self.initLen] = np.vstack((u, x_state))[:, 0]

        # compose the X matrix (in R^{(N_i + N_r) * KQ}) and Y matrix (in R^{KQ * N_o})
        # x_matrix = [H_batch, H_batch, H_batch]
        # y_matrix = [y_target_batch, y_target_batch, y_target_batch]
        x_matrix = np.zeros((self.inSize + self.resSize, self.num_ap * self.num_samples))
        y_matrix = np.zeros((self.num_samples * self.num_ap, self.outSize))

        for k in range(self.num_ap):
            x_matrix[:, k*self.num_samples:(k+1)*self.num_samples] = H_batch
            y_matrix[k*self.num_samples:(k+1)*self.num_samples, :] = y_target_batch

        self.x_matrix = x_matrix
        self.y_matrix = y_matrix

        weight_out, errorLoss = self.run_federated_learning()  # in R^{(N_i + N_r) * N_o}
        return weight_out, x_state, self.x_matrix, errorLoss

    def run_federated_learning(self):
        # initialize akt_matrix and vat_matrix
        akt_matrix = np.zeros((self.num_samples * self.num_ap, self.outSize))
        vat_matrix = np.zeros((self.outSize, self.inSize + self.resSize))

        # should check the convergence
        sum_delta_at = []
        error_loss = 0
        for t in range(self.T):
            sum_delta_vkt_matrix = np.zeros((self.outSize, self.inSize + self.resSize))

            sum_delta_akt = []
            for k in range(self.num_ap):
                zx_matrix = self.generate_Zk_matrix(k) + self.kappa / (self.ksi * self.num_ap * self.num_samples) * \
                            np.dot(self.generate_Xk_matrix(k, self.x_matrix).transpose(),
                                   self.generate_Xk_matrix(k, self.x_matrix))
                inv_k_matrix = LA.inv(zx_matrix[k*self.num_samples:(k+1)*self.num_samples,
                                    k*self.num_samples:(k+1)*self.num_samples])
                zx_matrix[k*self.num_samples:(k+1)*self.num_samples, k*self.num_samples:(k+1)*self.num_samples] = inv_k_matrix
                inv_matrix = zx_matrix

                if t == 0:
                    ykak_matrix = self.generate_Yk_matrix(k, self.y_matrix) - \
                                  self.initialize_Ak_matrix(k, self.generate_A_matrix()) - \
                                  1/2 * np.dot(self.generate_Xk_matrix(k, self.x_matrix).transpose(),
                                               self.initialize_V_matrix(self.x_matrix).transpose())
                    delta_akt_matrix = np.dot(inv_matrix, ykak_matrix)

                    # update akt_matrix
                    akt_matrix = self.initialize_Ak_matrix(k, self.generate_A_matrix()) + 1/(t+1) * delta_akt_matrix
                else:
                    ykak_matrix = self.generate_Yk_matrix(k, self.y_matrix) - akt_matrix - \
                                  1/2 * np.dot(self.generate_Xk_matrix(k, self.x_matrix).transpose(), vat_matrix.transpose())
                    delta_akt_matrix = np.dot(inv_matrix, ykak_matrix)

                    # update akt_matrix
                    akt_matrix = akt_matrix + 1/(t+1) * delta_akt_matrix

                sum_delta_akt.append(np.sum(delta_akt_matrix))

                # update delta_vkt_matrix
                delta_vkt_matrix = 1/(self.ksi*self.num_ap*self.num_samples) * \
                                   np.dot(self.generate_Xk_matrix(k, self.x_matrix), delta_akt_matrix).transpose()

                # calculate the summation of delta_vkt_matrix
                sum_delta_vkt_matrix = sum_delta_vkt_matrix + delta_vkt_matrix

            # update vat_matrix
            if t == 0:
                vat_matrix = self.initialize_V_matrix(self.x_matrix) + sum_delta_vkt_matrix
            else:
                vat_matrix = vat_matrix + sum_delta_vkt_matrix

            # check the convergence of the method
            sum_delta_at.append(sum_delta_akt)

        # check the loss
        sum_a_list_t2 = [np.sum(i) for i in sum_delta_at]
        sum_a_list_t1 = np.hstack(([0], sum_a_list_t2)).tolist()
        sum_a_list_t1.pop()
        error_loss = np.array(sum_a_list_t2) - np.array(sum_a_list_t1)

        # output the output weight matrix
        weight_output = 1/2 * vat_matrix.transpose()

        return weight_output, error_loss

    def predict_esn(self, u_start_index, weight_out, x_state):
        # y_hat is the evaluated output
        y_hat = np.zeros((self.outSize, self.testLen))
        u_start_index = self.inputScaling * u_start_index + self.inputShift

        for t in range(self.testLen):
            x_state = (1 - self.leakRate) * x_state + self.leakRate * \
                      np.tanh(np.dot(self.weight_in, u_start_index) + np.dot(self.weight_reservoir, x_state))
            # x_state = (weight_in * u_start_index + np.dot(weight_reservoir, x_state))
            y = np.dot(weight_out.transpose(), np.vstack((u_start_index, x_state)))  # a 2-array
            y_hat[:, t] = y[:, 0]
            u_start_index = y

        return (y_hat - self.teacherShift) / self.teacherScaling


