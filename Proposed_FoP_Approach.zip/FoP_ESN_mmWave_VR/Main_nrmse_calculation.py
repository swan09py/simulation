"""
Implementation of DDPG - Deep Deterministic Policy Gradient
Algorithm and hyperparameter details can be found here:
    http://arxiv.org/pdf/1509.02971v2.pdf
The algorithm is tested on the Pendulum-v0 OpenAI gym task
and developed with tflearn + Tensorflow
Author: Patrick Emami
"""

import numpy as np
import pprint as pp
import argparse
import scipy.io as sio
import matplotlib.pyplot as plt

from comput_nrmse import ComputeNRMSE


def main(args):
    # load the original data
    prediction_nrmse = []
    for num_user in range(int(args['number_user'])):
        path_true = 'C:/Users/swan/PycharmProjects/Federated_ESN_VR/original_data_sets/Pedestrian_Trajectory_Cartesian_' + \
               str(num_user + 1) + '.mat'
        data_true = sio.loadmat(path_true)
        # print(data.keys())
        ori_data_true = data_true['userInterpLocations']
        input_data_true = ori_data_true

        path_predict = 'C:/Users/swan/PycharmProjects/Federated_ESN_VR/original_data_sets/Predicted_Trajectory_' + \
                    str(num_user + 1) + '.mat'
        data_predict = sio.loadmat(path_predict)
        # print(data.keys())
        ori_data_predict = data_predict['predicted_trajectory']
        input_data_predict = np.transpose(ori_data_predict)

        # Initialize the NRMSE computation class
        compute_nrmse = ComputeNRMSE()
        nrmse_x = compute_nrmse.compute_nrmse(input_data_predict[:, 0],
                                            input_data_true[int(args['train_len']) + 1:, 0])
        nrmse_y = compute_nrmse.compute_nrmse(input_data_predict[:, 1],
                                            input_data_true[int(args['train_len']) + 1:, 1])

        print('NRMSE = {0}'.format(str((nrmse_x + nrmse_y)/2)))
        prediction_nrmse.append((nrmse_x + nrmse_y)/2)

        # plot the figure to verify the prediction accuracy
        plt.figure(1).clear()
        plt.plot(input_data_predict[:, 0], input_data_predict[:, 1], "g-", label="Free-running predicted signal")
        plt.plot(input_data_true[:, 0], input_data_true[:, 1], "r-.", label="Target signal", linewidth=2)
        plt.title("Target and generated signals y(n) starting at n=0")
        plt.grid(True)
        plt.legend()
        plt.show()
    # save the predicted nrmse of each user's Trajectory
    prediction_save_path = \
        'C:/Users/swan/PycharmProjects/Federated_ESN_VR/original_data_sets/NRMSE_of_Predicted_Trajectory.mat'
    sio.savemat(prediction_save_path, {'predicted_nrmse': np.array(prediction_nrmse)})


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Verifying the accuracy of the ESN method!')

    # ESN parameters
    parser.add_argument('--input-len', help='input length of the ESN network', default=2)
    parser.add_argument('--train-len', help='length of the training samples', default=110)  # 109
    parser.add_argument('--number-user', help='the number of users', default=16)

    args = vars(parser.parse_args())

    pp.pprint(args)

    main(args)
