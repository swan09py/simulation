import mosek
import sys
import numpy as np
import scipy.io as sio

# Since the value of infinity is ignored, we define it solely
# for symbolic purposes
inf = 0.0
pi = 3.1415926


# Define a stream printer to grab output from MOSEK
def stream_printer(text):
    sys.stdout.write(text)
    sys.stdout.flush()


def dis_calculate_ij(user_index, ap_index, user_location, ap_location):
    distance_ij = np.sqrt(np.sum(list(map(lambda x: (x[0]-x[1]) ** 2, zip(user_location[user_index], ap_location[ap_index])))))
    # distance = np.sqrt(np.sum(user_location[user_index][i] - ap_location[ap_index][i]
    #                           for i in range(len(user_location[user_index]))))
    return distance_ij


def calculate_path_loss(num_user, num_ap, user_location_input, ap_location_input, eta_los, eta_nlos,
                        sigma_los, sigma_nlos, light_speed, frequency, num_antenna):
    # initialize the H_ij LoS matrix and h_ij NLoS matrix
    H_ij_los_matrix = np.zeros((num_antenna, num_user * num_ap * num_antenna))
    H_ij_nlos_matrix = np.zeros((num_antenna, num_user * num_ap * num_antenna))
    # user_location and ap_location are two-dimensional arrays
    for i_index in range(num_user):
        for j_index in range(num_ap):
            distance_ij = dis_calculate_ij(i_index, j_index, user_location_input, ap_location_input)
            # calculate the LoS path loss (1-array in R^{K})
            h_ij_los = np.sqrt(10 ** (- (10 * eta_los * np.log10(distance_ij) +
                                 20 * np.log10(4 * pi * frequency/light_speed) +
                                 np.random.normal(0.0, sigma_los, num_antenna))/10.0))
            # calculate the NLoS path loss (1-array in R^{K})
            h_ij_nlos = np.sqrt(10 ** (- (10 * eta_nlos * np.log10(distance_ij) +
                                  20 * np.log10(4 * pi * frequency/light_speed) +
                                  np.random.normal(0.0, sigma_nlos, num_antenna))/10.0))
            H_ij_los_matrix[:, range((i_index*num_ap+j_index)*num_antenna+0,
                                     (i_index*num_ap+j_index)*num_antenna+num_antenna)] = \
                np.dot(h_ij_los.reshape(num_antenna, 1), h_ij_los.reshape(1, num_antenna))
            H_ij_nlos_matrix[:, range((i_index * num_ap + j_index) * num_antenna + 0,
                                     (i_index * num_ap + j_index) * num_antenna + num_antenna)] = \
                np.dot(h_ij_nlos.reshape(num_antenna, 1), h_ij_nlos.reshape(1, num_antenna))
    return H_ij_los_matrix, H_ij_nlos_matrix


def downlink_beamformer_optimization():
    # make a mosek environment
    with mosek.Env() as env:
        # create mosek task
        with env.Task(0, 0) as task:
            task.set_Stream(mosek.streamtype.log, stream_printer)

            # (Awaiting) Initialize the parameters
            num_user = 4
            num_ap = 3
            num_antenna = 2
            single_noise_power = 2e-19  # in mW/Hz
            gamma_th = 2
            band_dl = 2e+9  # in MHz
            alpha = 2
            power_ap_total = [530.0, 530.0, 530.0]
            power_ap_inst = [30.0, 30.0, 30.0]
            antenna_gain = np.ones((num_user, num_ap))
            eta_los = 2.0
            eta_nlos = 2.4
            sigma_los = 5.3
            sigma_nlos = 5.27
            light_speed = 3e+8
            frequency = 2.8e+10

            # (Awaiting) load the original data
            path = 'C:/Users/swan/PycharmProjects/Federated_ESN_VR/original_data_sets/locationInterpCartesian_64.mat'
            data = sio.loadmat(path)
            print(data.keys())
            ori_data = data['userInterpLocations']

            # user_location = ori_data[:, [0, 1]]  # it is an array
            user_location = np.array([[0, 0], [150, 150], [600, 200], [300, 360]])
            ap_location = np.array([[100.0, 200.0], [400.0, 600.0], [330.0, 460.0]])  # it is a list

            # obtain the h_matrix in R^{num_antenna, num_antenna * num_user * num_ap}
            h_matrix, h_nlos_matrix = calculate_path_loss(num_user, num_ap, user_location, ap_location,
                                                          eta_los, eta_nlos, sigma_los, sigma_nlos, light_speed,
                                                          frequency, num_antenna)
            # h_matrix = np.array(num_antenna, num_antenna * num_user * num_ap)

            # (Awaiting) obtain a_ij_ul, it should be a two-dimensional array
            a_ij_dl = np.zeros((num_user, num_ap))
            for i_user in range(num_user):
                # j_index = np.mod(i_user, num_ap)
                # a_ij_dl[i_user][j_index] = 1
                a_ij_dl[i_user][0] = 1
            # a_ij_dl[1][0] = 0  # in this way, for instance the 1st user cannot access any AP
            # a_ij_dl[3][0] = 0
            # a_ij_dl[2][0] = 0

            # calculate the number of non-zero element in a_ij_dl
            num_none_zero = int(np.sum([np.sum(i) for i in a_ij_dl]))
            num_cons = num_none_zero * 3 + num_ap
            offset_theta = 0
            offset_ksi = num_user * num_ap
            offset_mu = 2 * num_user * num_ap
            offset_lambda = 3 * num_user * num_ap
            offset_nu = 4 * num_user * num_ap

            # obtain the index of users that can be served by APs
            i_star_collection = []
            for i_user in range(num_user):
                for j_ap in range(num_ap):
                    if a_ij_dl[i_user][j_ap] == 1:
                        i_star_collection.append(i_user)
            assert len(i_star_collection) == num_none_zero, "the number of served users not equals to num_none_zero"

            # constraints
            task.appendcons(num_cons)

            for j in range(0, num_none_zero):
                task.putconbound(j, mosek.boundkey.lo, 0.0, +inf)
                task.putconname(j, "SNR[%d]" % j)

            for j in range(0, num_none_zero):
                task.putconbound(num_none_zero * 1 + j, mosek.boundkey.fx, 1.0, 1.0)
                task.putconname(num_none_zero + j, "mu-theta[%d]" % (num_none_zero + j))

            for j in range(0, num_none_zero):
                task.putconbound(num_none_zero * 2 + j, mosek.boundkey.fx, 0.0, 0.0)
                task.putconname(num_none_zero * 2 + j, "nu-ksi[%d]" % (num_none_zero * 2 + j))

            for j in range(0, num_ap):
                task.putconbound(num_none_zero * 3 + j, mosek.boundkey.ra, 0.0, 10**(power_ap_total[j]/10) - 10**(power_ap_inst[j]/10))
                # task.putconbound(num_none_zero * 3 + j, mosek.boundkey.lo, 0.0, +inf)
                task.putconname(num_none_zero * 3 + j, "power[%d]" % (num_none_zero * 3 + j))

            # variables
            task.appendvars(5 * num_user * num_ap)

            # theta variables
            # task.putclist(range(offset_theta + 0, offset_theta + num_user * num_ap), [0.0] * num_user * num_ap)
            for j in range(0, num_none_zero):
                real_i_index = i_star_collection[j]
                column_index = real_i_index * num_ap + a_ij_dl[real_i_index].tolist().index(1)
                task.putaij(j, offset_theta + column_index,
                            -a_ij_dl[real_i_index][a_ij_dl[real_i_index].tolist().index(1)] *
                            single_noise_power * band_dl /
                            (antenna_gain[real_i_index][a_ij_dl[real_i_index].tolist().index(1)] ** 2))
                task.putaij(num_none_zero + j, offset_theta + column_index, -1.0)

            task.putvarboundlist(range(offset_theta + 0, offset_theta + num_user * num_ap),
                                 [mosek.boundkey.lo] * (num_user * num_ap), [i for j in a_ij_dl for i in j],
                                 [+inf] * num_user * num_ap)

            for i in range(0, num_user):
                for j in range(0, num_ap):
                    task.putvarname(offset_theta + i * num_ap + j, "theta[%d]" % (offset_theta + i * num_ap + j))

            # ksi variables
            for j in range(0, num_none_zero):
                real_i_index = i_star_collection[j]
                column_index = real_i_index * num_ap + a_ij_dl[real_i_index].tolist().index(1)
                task.putaij(2 * num_none_zero + j, offset_ksi + column_index, - np.log(2))

            task.putvarboundlist(range(offset_ksi + 0, offset_ksi + num_user * num_ap),
                                 [mosek.boundkey.lo] * num_user * num_ap,
                                 [i * gamma_th / band_dl for j in a_ij_dl for i in j], [+inf] * num_user * num_ap)

            for i in range(0, num_user):
                for j in range(0, num_ap):
                    task.putvarname(offset_ksi + i * num_ap + j, "ksi[%d]" % (offset_ksi + i * num_ap + j))

            # mu variables
            for j in range(0, num_none_zero):
                real_i_index = i_star_collection[j]
                column_index = real_i_index * num_ap + a_ij_dl[real_i_index].tolist().index(1)
                task.putaij(num_none_zero + j, offset_mu + column_index, 1.0)

            task.putvarboundlist(range(offset_mu + 0, offset_mu + num_user * num_ap),
                                 [mosek.boundkey.lo] * num_user * num_ap,
                                 [i for j in a_ij_dl for i in j],
                                 [+inf] * num_user * num_ap)

            for i in range(0, num_user):
                for j in range(0, num_ap):
                    task.putvarname(offset_mu + i * num_ap + j, "mu[%d]" % (offset_mu + i * num_ap + j))

            # lambda variables
            task.putvarboundlist(range(offset_lambda + 0, offset_lambda + num_user * num_ap),
                                 [mosek.boundkey.fx] * num_user * num_ap,
                                 [i for j in a_ij_dl for i in j],
                                 [i for j in a_ij_dl for i in j])

            for i in range(0, num_user):
                for j in range(0, num_ap):
                    task.putvarname(offset_lambda + i * num_ap + j, "lambda[%d]" % (offset_lambda + i * num_ap + j))

            # nu variables
            for j in range(0, num_none_zero):
                real_i_index = i_star_collection[j]
                column_index = real_i_index * num_ap + a_ij_dl[real_i_index].tolist().index(1)
                task.putaij(2 * num_none_zero + j, offset_nu + column_index, 1.0)

            task.putvarboundlist(range(offset_nu + 0, offset_nu + num_user * num_ap),
                                 [mosek.boundkey.lo] * num_user * num_ap,
                                 [i * gamma_th / (band_dl * np.log(2)) for j in a_ij_dl for i in j],
                                 [+inf] * num_user * num_ap)

            for i in range(0, num_user):
                for j in range(0, num_ap):
                    task.putvarname(offset_nu + i * num_ap + j, "nu[%d]" % (offset_nu + i * num_ap + j))

            # SDP cones
            task.appendbarvars([num_antenna] * num_user * num_ap)

            # the objective function
            # variable_index = []
            # aval_obj = []
            # for j in range(num_user * num_ap):
            #     for i in range(num_antenna):
            #         variable_index.append(j)
            # for i in range(num_user):
            #     for j in range(num_ap):
            #         aval_obj.append([a_ij_dl[i][j]] * num_antenna)
            #
            # task.putbarcblocktriplet(num_antenna * num_user * num_ap,
            #                          variable_index,
            #                          list(range(0, num_antenna)) * num_user * num_ap,
            #                          list(range(0, num_antenna)) * num_user * num_ap,
            #                          [i for j in aval_obj for i in j])

            # the first group of constraints
            h_matrix_len = int(num_antenna * (num_antenna + 1) / 2)
            # the objective function
            for j in range(num_ap):
                a_index = []
                aval = []
                for k in range(num_user):
                    a_index.append([j + num_ap * k] * num_antenna)
                    aval.append([a_ij_dl[k][j]] * num_antenna)
                # reshape the two dimensional into one dimensional
                task.putbarcblocktriplet(num_antenna * num_user,
                                         [i for j_1 in a_index for i in j_1],
                                         list(range(0, num_antenna)) * num_user,
                                         list(range(0, num_antenna)) * num_user,
                                         [i for j_1 in aval for i in j_1]
                                         )

            for j in range(num_none_zero):
                real_i_index = i_star_collection[j]
                # offset of the SDP variable
                offset_vij = real_i_index * num_ap
                column_index = offset_vij + a_ij_dl[real_i_index].tolist().index(1)
                # off set of the matrix V_ij
                offset_hij = column_index * num_antenna
                h_matrixij = h_matrix[:, list(range(offset_hij + 0, offset_hij + num_antenna))]
                subk = []
                subl = []
                valijkl = []

                # lower triangle matrix construction
                for h_i in range(num_antenna):
                    for h_j in range(num_antenna):
                        if h_i >= h_j:
                            subk.append(h_i)
                            subl.append(h_j)
                            valijkl.append(h_matrixij[h_i][h_j])

                task.putbarablocktriplet(h_matrix_len,
                                         [j] * h_matrix_len,
                                         [column_index] * h_matrix_len,
                                         subk,
                                         subl,
                                         valijkl)

            # the second group of constraints
            for j in range(num_ap):
                a_index = []
                aval = []
                for k in range(num_user):
                    a_index.append([j + num_ap * k] * num_antenna)
                    aval.append([a_ij_dl[k][j]] * num_antenna)
                # reshape the two dimensional into one dimensional
                task.putbarablocktriplet(num_antenna * num_user,
                                         [num_none_zero * 3 + j] * num_antenna * num_user,
                                         [i for j_1 in a_index for i in j_1],
                                         list(range(0, num_antenna)) * num_user,
                                         list(range(0, num_antenna)) * num_user,
                                         [i for j_1 in aval for i in j_1]
                                         )

            for i in range(0, num_user):
                for j in range(0, num_ap):
                    task.putbarvarname(i * num_ap + j, "X[%d]" % (i * num_ap + j))

            # the exponential cone constraints
            for j in range(num_none_zero):
                real_i_index = i_star_collection[j]
                column_index = real_i_index * num_ap + a_ij_dl[real_i_index].tolist().index(1)
                task.appendcone(mosek.conetype.pexp, 0.0, [offset_mu + column_index,
                                                           offset_lambda + column_index, offset_nu + column_index])

            # task.putobjsense(mosek.objsense.maximize)
            task.putobjsense(mosek.objsense.minimize)

            # Turn all log output off
            # task.putintparam(mosek.iparam.log, 0)

            # Dump the problem to a human readable ODF file
            task.writedata("test.ptf")

            task.optimize()

            # Display the solution summary for quick inspection of results
            task.solutionsummary(mosek.streamtype.msg)

            # get status information about the solution
            solsta = task.getsolsta(mosek.soltype.itr)

            if (solsta == mosek.solsta.optimal or
                    solsta == mosek.solsta.near_optimal):
                print("Solution (Lower-triangular part vectorized):")
                for i in range(num_user * num_ap):
                    X = [0.0] * h_matrix_len
                    task.getbarxj(mosek.soltype.itr, i, X)
                    print("X{i} = {X}".format(i=i, X=X))
                # xx = [0.] * numvars
                # task.getxx(mosek.soltype.bas, xx)
                # print("The optimal solution:")
                # for i in range(numvars):
                #     print("x[" + str(i) + "]=" + str(xx[i]))
            elif (solsta == mosek.solsta.dual_infeas_cer or
                  solsta == mosek.solsta.prim_infeas_cer or
                  solsta == mosek.solsta.near_dual_infeas_cer or
                  solsta == mosek.solsta.near_prim_infeas_cer):
                print("Primal or dual infeasibility certification found! \n")
            elif solsta == mosek.solsta.unknown:
                print("Unknown solution status! \n")
            else:
                print("Other solution status!")


# call the main function
try:
    downlink_beamformer_optimization()
except mosek.Error as e:
    print("ERROR: %s" % str(e.errno))
    if e.msg is not None:
        print("\t %s" % e.msg)
        sys.exit(-1)
except:
    import traceback
    traceback.print_exc()
    sys.exit(-1)


