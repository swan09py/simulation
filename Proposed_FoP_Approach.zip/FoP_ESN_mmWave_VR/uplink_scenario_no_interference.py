import numpy as np
import math
import mosek
import sys

pi = 3.1415926925
inf = 0.0


# Define a stream printer to grab output from MOSEK
def stream_printer(text):
    sys.stdout.write(text)
    sys.stdout.flush()


# scenario identify function
class UplinkScenarioNoInterference(object):
    """
    Input to the deployment scene is the action, output is (s2, r, terminal, info).
    The action must be obtained from the output of the Actor network.
    """

    def __init__(self, env_task, noise_power, uplink_bandwidth, ap_number,
                 uplink_QoS, alpha, user_number, interfering_user_list, interfering_user_array, num_groups,
                 instant_max_power, rayleigh_gain
                 ):
        self.env = env_task
        self.noise_power = noise_power
        self.uplink_bandwidth = uplink_bandwidth
        self.ap_number = ap_number
        self.uplink_QoS = uplink_QoS
        self.user_number = user_number
        self.alpha = alpha
        self.interfering_user_list = interfering_user_list
        self.interfering_user_array = interfering_user_array
        self.num_groups = num_groups
        self.interfering_a_matrix = 0
        self.instant_max_power = instant_max_power
        self.rayleigh_gain = rayleigh_gain
        # initialize the 3-D locations of UAVs, the number of UAVs, power, we assume that the users in the coverage,...
        # ...of the UAV will be covered by the UAV

        # initialize the locations of users, the heterogeneous QoS of users

        # some hyperparameters of air-to-ground channel model, or we should adopt them like the above program

    def initialize_interfering_indicator_matrix(self):
        interfering_a_matrix = np.zeros((self.user_number, self.user_number))
        for user_i in range(self.user_number):
            # user i belongs to which group
            user_group_index = int(self.interfering_user_list.index(user_i) // (self.user_number/self.num_groups))
            sg_users_index = self.interfering_user_array[user_group_index, :]  # 1-array
            for j in range(len(sg_users_index)):
                interfering_a_matrix[user_i, sg_users_index[j]] = 1
        self.interfering_a_matrix = interfering_a_matrix
        return 0

    def dis_calculate(self, user_index, ap_index, user_location, ap_location, user_height, ap_height):
        distance_hori = (
            np.sum(list(map(lambda x: (x[0] - x[1]) ** 2, zip(user_location[user_index], ap_location[ap_index])))))
        # distance = np.sqrt(np.sum(user_location[user_index][i] - ap_location[ap_index][i]
        #                           for i in range(len(user_location[user_index]))))
        distance_vert = (ap_height - user_height[user_index]) ** 2

        distance = np.sqrt(distance_hori + distance_vert)

        return distance

    def pathloss_calculate(self, user_location, ap_location, user_height, ap_height):
        hij_array = []
        for i_user in range(self.user_number):
            for j_ap in range(self.ap_number):
                # calculate the path loss
                dis_ij = self.dis_calculate(i_user, j_ap, user_location, ap_location, user_height, ap_height)
                hij_array.append(self.rayleigh_gain * dis_ij ** (-self.alpha))
        hij_array = np.array(hij_array)

        return hij_array  # a 1D-array

    def qos_violance_check(self, a_ij_ul, i_star, j_star, user_power, distance_ij_matrix):
        qos_violance = True
        receiving_power = user_power[i_star] * distance_ij_matrix[i_star][j_star] ** (-self.alpha)
        distance_j_star = np.tile(distance_ij_matrix[:, j_star].reshape(len(distance_ij_matrix[:, j_star]), 1),
                                  len(distance_ij_matrix[0]))
        interfere_pathloss = np.multiply(np.sum(np.multiply(a_ij_ul, np.power(distance_j_star, -self.alpha)), 1),
                                        self.interfering_a_matrix[i_star, :])
        interference = np.dot(user_power, interfere_pathloss) - receiving_power
        if receiving_power - self.uplink_QoS * ((10 ** (self.noise_power/10))
                                                * (self.uplink_bandwidth * 1e+6) + interference) >= 0:
            qos_violance = False
        return qos_violance

    def uplink_optimization(self, a_ij_ul, user_location, ap_location, q_plus, user_height, ap_height):
        xx = np.zeros((self.user_number, ))
        pro_feasibility = True

        for i_user in range(self.user_number):
            for j_ap in range(self.ap_number):
                if a_ij_ul[i_user][j_ap] == 1:  # user i is active
                    j_star = np.where(a_ij_ul[i_user] == 1)[0]
                    # calculate the path loss
                    dis_ij = self.dis_calculate(i_user, j_star, user_location, ap_location, user_height, ap_height)
                    xx[i_user] = (self.uplink_QoS * (10 ** (self.noise_power / 10)) * self.uplink_bandwidth) / \
                                 (self.user_number * self.rayleigh_gain * dis_ij ** (-self.alpha))
                    if xx[i_user] > self.instant_max_power:
                        xx[i_user] = self.instant_max_power
                        pro_feasibility = False
        return xx, pro_feasibility

    def uplink_power(self, user_location, ap_location, user_height, ap_height):
        power_matrix = np.zeros((self.user_number, self.ap_number))

        for i_user in range(self.user_number):
            for j_ap in range(self.ap_number):
                # calculate the path loss
                dis_ij = self.dis_calculate(i_user, j_ap, user_location, ap_location, user_height, ap_height)
                power_matrix[i_user][j_ap] = min((self.uplink_QoS * (10 ** (self.noise_power / 10)) * self.uplink_bandwidth) / \
                             (self.user_number * self.rayleigh_gain * dis_ij ** (-self.alpha)), self.instant_max_power + 0.1)

        return power_matrix
        # with self.env.Task(0, 0) as task:
        #     # task.set_Stream(mosek.streamtype.log, stream_printer)
        #     # for testing the A matrix
        #     # a_ij_ul = np.zeros((12, 3))
        #     # a_ij_ul[:, 1] = 1
        #     # q_plus = np.ones((self.user_number, )) * 500
        #
        #     # obtain all active user indexes
        #     # i_star = []
        #     i_star = np.where(np.sum(np.array(a_ij_ul), 1) == 1)[0]
        #
        #     # bound keys for constraints and variables
        #     bkc = []
        #     for i_user in range(self.user_number):
        #         for j_ap in range(self.ap_number):
        #             if a_ij_ul[i_user][j_ap] == 1:
        #                 bkc.append(mosek.boundkey.lo)
        #
        #     bkx = [mosek.boundkey.ra] * self.user_number
        #     # bkx = np.tile(bkx, self.user_number)
        #
        #     # bound value for constraints and variables
        #     blc = []
        #     buc = []
        #     for i_user in range(self.user_number):
        #         for j_ap in range(self.ap_number):
        #             if a_ij_ul[i_user][j_ap] == 1:
        #                 blc.append(self.uplink_QoS * (10 ** (self.noise_power/10)) * (self.uplink_bandwidth * 1e+6))
        #                 buc.append(+inf)
        #
        #     blx = [0.0000] * self.user_number
        #     bux = [self.instant_max_power] * self.user_number
        #
        #     # objective coefficients
        #     c = []
        #     aq_plus = np.multiply(q_plus, np.sum(np.array(a_ij_ul), 1))  # q_plus, 1-array
        #     for i_user in range(self.user_number):
        #         c.append(aq_plus[i_user])
        #
        #     # # -------- obtain the value of A  ------------ # #
        #     # calculate the number of constraints
        #     numcons = len(bkc)
        #     numvars = len(bkx)
        #     asub = np.tile(range(numcons), (self.user_number, 1))
        #     aval = np.zeros((self.user_number, numcons))
        #
        #     # obtain the ap index connecting to each active user
        #     j_star_cons = []
        #     for i_user in range(self.user_number):
        #         for j_ap in range(self.ap_number):
        #             if a_ij_ul[i_user][j_ap] == 1:
        #                 j_star_cons.append(j_ap)  # the connected ap index of each constraint
        #
        #     assert len(j_star_cons) == numcons, "the length of j_star corresponding to constraints must be numcons"
        #
        #     # for i_user in range(self.user_number):
        #     #     for j_ap in range(self.ap_number):
        #     #         if a_ij_ul[i_user][j_ap] == 1:
        #     #             i_star.append(i_user)
        #
        #     index_unaccess = []
        #     for i_user in range(self.user_number):
        #         j_star_exist = None
        #         for j_ap in range(self.ap_number):
        #             if a_ij_ul[i_user][j_ap] == 1:
        #                 j_star_exist = 1  # j_ap
        #
        #         if j_star_exist is None:  # means i_user is inactive
        #             index_unaccess.append(i_user)  # record the index of a user cannot access to an AP
        #             aval[i_user] = [0.] * numcons
        #         else:  # indicate that i_user is active
        #             num_unaccess = len(index_unaccess)  # accumulated users cannot access to an AP
        #             for cons_index in range(numcons):
        #
        #                 disval = self.dis_calculate(i_user,
        #                                        j_star_cons[cons_index], user_location, ap_location,
        #                                             user_height, ap_height)
        #                 if cons_index == i_user - num_unaccess:
        #                     # disval = dis_calculate(i_user,
        #                     #                        a_ij_ul[i_user].tolist().index(1), user_location, ap_location)
        #                     # aval[i_user][cons_index] = self.interfering_a_matrix[i_star[cons_index], i_user] * \
        #                     #                            disval ** (-self.alpha)
        #                     aval[i_user][cons_index] = disval ** (-self.alpha)
        #                 else:
        #                     # disval = dis_calculate(i_user,
        #                     #                        j_star_cons[cons_index], user_location, ap_location)
        #                     # the sum(a_ij) is not needed
        #                     aval[i_user][cons_index] = - self.interfering_a_matrix[i_star[cons_index], i_user] * \
        #                                                self.uplink_QoS * disval ** (-self.alpha)
        #                     # because if i is active, then it must be an interference user to other active users
        #
        #     # enlarge the coefficient matrix A and the corresponding blu, buc
        #     aval = aval * 1e5
        #     blc = (np.array(blc) * 1e5).tolist()
        #     # Append 'numcons' empty constraints
        #     task.appendcons(numcons)
        #
        #     # Append 'numvars' variables
        #     task.appendvars(numvars)
        #
        #     for j in range(numvars):
        #         # set the objective function
        #         task.putcj(j, c[j])
        #
        #         # set the bounds on variables
        #         task.putvarbound(j, bkx[j], blx[j], bux[j])
        #
        #         # set the expression of A
        #         task.putacol(j, asub[j], aval[j])
        #
        #     # set the bounds on constraints
        #     for i in range(numcons):
        #         task.putconbound(i, bkc[i], blc[i], buc[i])
        #
        #     # input the objective sense
        #     task.putobjsense(mosek.objsense.minimize)
        #
        #     # solve the optimization problem
        #     task.optimize()
        #
        #     # print a summary of containing information
        #     # task.solutionsummary(mosek.streamtype.msg)
        #
        #     # get state information about the solution
        #     solsta = task.getsolsta(mosek.soltype.bas)
        #
        #     pro_feasibility = False
        #     xx = [0.] * numvars
        #     if solsta == mosek.solsta.optimal:
        #         print("The optimal solution is found! \n")
        #         task.getxx(mosek.soltype.bas, xx)
        #         # print("The optimal solution:")
        #         for i in range(numvars):
        #             print("x[" + str(i) + "]=" + str(xx[i]))
        #         pro_feasibility = True
        #     elif (solsta == mosek.solsta.dual_infeas_cer or
        #           solsta == mosek.solsta.prim_infeas_cer or
        #           solsta == mosek.solsta.near_dual_infeas_cer or
        #           solsta == mosek.solsta.near_prim_infeas_cer):
        #         t = True
        #         print("Primal or dual infeasibility certification found! \n")
        #     elif solsta == mosek.solsta.unknown:
        #         print("Unknown solution status! \n")
        #     else:
        #         print("Other solution status!")
        #
        #     return xx, pro_feasibility  # it is a list including p_{i}: user_number