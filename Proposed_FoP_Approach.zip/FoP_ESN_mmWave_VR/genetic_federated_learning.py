
import numpy as np
from numpy import linalg as LA


class GeneticFederatedLearning:
    def __init__(self, num_ap, num_samples, federated_episode, outSize, inSize, resSize, trainLen, initLen, testLen,
                 leak_rate, teacher_scaling, teacher_shift, input_scaling, input_shift, ksi, kappa):
        self.num_ap = num_ap  # K
        self.outSize = outSize  # N_o
        self.num_samples = num_samples  # Q
        self.inSize = inSize  # N_i
        self.resSize = resSize  # N_r
        self.trainLen = trainLen
        self.initLen = initLen
        self.testLen = testLen
        self.leakRate = leak_rate
        self.teacherScaling = teacher_scaling
        self.teacherShift = teacher_shift
        self.inputScaling = input_scaling
        self.inputShift = input_shift
        self.ksi = ksi
        self.kappa = kappa
        self.T = federated_episode
        self.weight_in = 0
        self.weight_reservoir = 0
        self.x_matrix = 0
        self.y_matrix = 0

        # given the desired output matrix Y

    def initialize_W_matrix(self):
        # np.random.seed(4)
        w_matrix = np.random.random((self.inSize + self.resSize, self.outSize))

        return w_matrix

    def generate_Xk_matrix(self, k_index, x_matrix):
        # x_matrix in R^{(N_i + N_r) * KQ}
        # however, xk_matrix should be in R^{Q * (N_i + N_r)}
        xk_matrix = x_matrix[:, k_index*self.num_samples:(k_index+1)*self.num_samples].transpose()

        return xk_matrix

    def generate_Yk_matrix(self, k_index, y_matrix):
        # yk_matrix in R^{Q * N_o}
        yk_matrix = y_matrix[k_index*self.num_samples:(k_index+1)*self.num_samples, :]

        return yk_matrix

    # # Generate the input and reservior weight matrix
    def generate_input_weight(self, rand_scaling):
        # return (np.random.random((self.resSize, self.inSize)) - 0.5) * rand_scaling
        # np.random.seed(66)
        return (np.random.random((self.resSize, self.inSize))) * rand_scaling

    def generate_reservoir_weight(self, rand_scaling):
        # np.random.seed(77)
        # weight = (np.random.random((self.resSize, self.resSize)) - 0.5) * rand_scaling
        weight = (np.random.random((self.resSize, self.resSize))) * rand_scaling
        w, vec = LA.eig(weight)
        max_w = np.max(np.abs(w))
        # max_w = np.nan

        while np.isnan(max_w):
            # weight = (np.random.random((self.resSize, self.resSize)) - 0.5) * rand_scaling
            weight = (np.random.random((self.resSize, self.resSize))) * rand_scaling
            w, vec = LA.eig(weight)
            max_w = np.max(np.abs(w))

        weight = weight * (1.25 / max_w)

        return weight

    def train_esn(self, input_data):
        H_batch = np.zeros((self.resSize + self.inSize, self.trainLen - self.initLen))
        y_target_batch = self.teacherScaling * \
                         input_data[self.initLen + 1:self.trainLen + 1, :] + self.teacherShift  # a 2-array
        # y_t_collections = np.reshape(y_t_collections, (1, self.trainLen-self.initLen))

        x_state = np.zeros((self.resSize, 1))
        self.weight_in = self.generate_input_weight(rand_scaling=1.0)
        self.weight_reservoir = self.generate_reservoir_weight(rand_scaling=1.0)

        for t in range(self.trainLen):
            u = self.inputScaling * input_data[t].reshape((self.inSize, 1)) + self.inputShift  # a 2-array
            x_state = (1 - self.leakRate) * x_state + self.leakRate * \
                      np.tanh(np.dot(self.weight_in, u) +
                              np.dot(self.weight_reservoir, x_state))  # a 2-array
            # x_state = (weight_in * u +
            #                   np.dot(weight_reservoir, x_state))
            if t >= self.initLen:  # the empty-operation execution
                H_batch[:, t - self.initLen] = np.vstack((u, x_state))[:, 0]

        # compose the X matrix (in R^{(N_i + N_r) * KQ}) and Y matrix (in R^{KQ * N_o})
        # x_matrix = [H_batch, H_batch, H_batch]
        # y_matrix = [y_target_batch, y_target_batch, y_target_batch]
        x_matrix = np.zeros((self.inSize + self.resSize, self.num_ap * self.num_samples))
        y_matrix = np.zeros((self.num_samples * self.num_ap, self.outSize))

        for k in range(self.num_ap):
            x_matrix[:, k*self.num_samples:(k+1)*self.num_samples] = H_batch
            y_matrix[k*self.num_samples:(k+1)*self.num_samples, :] = y_target_batch

        self.x_matrix = x_matrix
        self.y_matrix = y_matrix

        weight_out, errorLoss = self.run_federated_learning()  # in R^{(N_i + N_r) * N_o}
        return weight_out, x_state, self.x_matrix, errorLoss

    def run_federated_learning(self):
        # initialize w0_matrix
        w0_matrix = self.initialize_W_matrix()

        # should check the convergence
        sum_wt = []
        error_loss = 0
        wkt_matrix_collection = []
        for t in range(self.T):
            sum_weighted_wkt_matrix = np.zeros((self.inSize + self.resSize, self.outSize))
            for k in range(self.num_ap):
                xk_matrix = self.generate_Xk_matrix(k, self.x_matrix)
                yk_matrix = self.generate_Yk_matrix(k, self.y_matrix)
                if t == 0:
                    # update wkt_matrix
                    wkt_matrix = w0_matrix - 1/(self.num_samples*(t+1)) * (np.dot(np.dot(xk_matrix.transpose(), xk_matrix), w0_matrix) -
                                                        np.dot(xk_matrix.transpose(), yk_matrix) + w0_matrix)
                    # wkt_matrix_collection.append(wkt_matrix)
                else:
                    # update wkt_matrix
                    wkt_matrix = wt_matrix - \
                                 1/(self.num_samples*(t+1)) * (np.dot(np.dot(xk_matrix.transpose(), xk_matrix), wt_matrix -
                                                                np.dot(xk_matrix.transpose(), yk_matrix) + wt_matrix))
                    # wkt_matrix_collection.append(wkt_matrix)

                # sum the K W_t^k matrices
                weighted_wkt_matrix = self.num_samples/(self.num_ap*self.num_samples) * wkt_matrix
                # weighted_wkt_matrix = 1 / (self.num_ap * self.num_samples) * wkt_matrix
                sum_weighted_wkt_matrix = sum_weighted_wkt_matrix + weighted_wkt_matrix

            # update xt_matrix
            wt_matrix = sum_weighted_wkt_matrix

            # check the convergence of the method
            sum_wt.append(np.sum(wt_matrix))

        # check the loss
        sum_a_list_t2 = sum_wt
        sum_a_list_t1 = np.hstack(([0], sum_wt)).tolist()
        sum_a_list_t1.pop()
        error_loss = np.array(sum_a_list_t2) - np.array(sum_a_list_t1)

        # output the output weight matrix
        weight_output = wt_matrix

        return weight_output, error_loss

    def predict_esn(self, u_start_index, weight_out, x_state):
        # y_hat is the evaluated output
        y_hat = np.zeros((self.outSize, self.testLen))
        u_start_index = self.inputScaling * u_start_index + self.inputShift

        for t in range(self.testLen):
            x_state = (1 - self.leakRate) * x_state + self.leakRate * \
                      np.tanh(np.dot(self.weight_in, u_start_index) + np.dot(self.weight_reservoir, x_state))
            # x_state = (weight_in * u_start_index + np.dot(weight_reservoir, x_state))
            y = np.dot(weight_out.transpose(), np.vstack((u_start_index, x_state)))  # a 2-array
            y_hat[:, t] = y[:, 0]
            u_start_index = y

        return (y_hat - self.teacherShift) / self.teacherScaling


