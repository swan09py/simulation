
import numpy as np
from numpy import linalg as LA


class EchoStateNetwork:
    def __init__(self, forget_len, train_len, predict_size, in_size, out_size, res_size, leak_rate, teacher_scaling,
                 teacher_shift, input_scaling, input_shift):
        """
                self.edges is a dict of all possible next nodes
                e.g. {'X': ['A', 'B', 'C', 'E'], ...}
                self.weights has all the weights between two nodes,
                with the two nodes as a tuple as the key
                e.g. {('X', 'A'): 7, ('X', 'B'): 2, ...}
                """
        self.initLen = forget_len
        self.trainLen = train_len
        self.testLen = predict_size
        self.inSize = in_size
        self.outSize = out_size
        self.resSize = res_size
        self.leakRate = leak_rate
        self.teacherScaling = teacher_scaling
        self.teacherShift = teacher_shift
        self.inputScaling = input_scaling
        self.inputShift = input_shift
        self.weight_in = 0
        self.weight_reservoir = 0

    def generate_input_weight(self, rand_scaling):
        # return (np.random.random((self.resSize, self.inSize)) - 0.5) * rand_scaling
        return (np.random.random((self.resSize, self.inSize))) * rand_scaling

    def generate_reservoir_weight(self, rand_scaling):
        # weight = (np.random.random((self.resSize, self.resSize)) - 0.5) * rand_scaling
        weight = (np.random.random((self.resSize, self.resSize))) * rand_scaling
        w, vec = LA.eig(weight)
        max_w = np.max(np.abs(w))
        # max_w = np.nan

        while np.isnan(max_w):
            # weight = (np.random.random((self.resSize, self.resSize)) - 0.5) * rand_scaling
            weight = (np.random.random((self.resSize, self.resSize))) * rand_scaling
            w, vec = LA.eig(weight)
            max_w = np.max(np.abs(w))

        weight = weight * (1.25 / max_w)

        return weight

    def train_esn(self, input_data):
        H_batch = np.zeros((self.resSize + self.inSize, self.trainLen - self.initLen))
        y_target_batch = self.teacherScaling * \
              input_data[self.initLen+1:self.trainLen+1, :] + self.teacherShift  # a 2-array
        # y_t_collections = np.reshape(y_t_collections, (1, self.trainLen-self.initLen))

        x_state = np.zeros((self.resSize, 1))
        self.weight_in = self.generate_input_weight(rand_scaling=1.0)
        self.weight_reservoir = self.generate_reservoir_weight(rand_scaling=1.0)

        for t in range(self.trainLen):
            u = self.inputScaling * input_data[t].reshape((self.inSize, 1)) + self.inputShift  # a 2-array
            x_state = (1 - self.leakRate) * x_state + self.leakRate * \
                      np.tanh(np.dot(self.weight_in, u) +
                              np.dot(self.weight_reservoir, x_state))  # a 2-array
            # x_state = (weight_in * u +
            #                   np.dot(weight_reservoir, x_state))
            if t >= self.initLen:  # the empty-operation execution
                H_batch[:, t - self.initLen] = np.vstack((u, x_state))[:, 0]

        reg = 1e-8
        H_batch_transpose = H_batch.transpose()
        inv_x = LA.inv(np.dot(H_batch, H_batch_transpose) +
                       reg * np.identity(self.resSize + self.inSize))
        weight_out = np.dot(np.dot(y_target_batch.T, H_batch_transpose), inv_x)  # in N_o * (N_i + N_r)
        return weight_out, x_state

    def predict_esn(self, u_start_index, weight_out, x_state):
        # y_hat is the evaluated output
        y_hat = np.zeros((self.outSize, self.testLen))
        u_start_index = self.inputScaling * u_start_index + self.inputShift

        for t in range(self.testLen):
            x_state = (1 - self.leakRate) * x_state + self.leakRate * \
                      np.tanh(np.dot(self.weight_in, u_start_index) + np.dot(self.weight_reservoir, x_state))
            # x_state = (weight_in * u_start_index + np.dot(weight_reservoir, x_state))
            y = np.dot(weight_out, np.vstack((u_start_index, x_state)))  # a 2-array
            y_hat[:, t] = y[:, 0]
            u_start_index = y

        return (y_hat - self.teacherShift) / self.teacherScaling




