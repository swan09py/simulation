import numpy as np
import math
import mosek
import sys

pi = 3.1415926925
inf = 0.0


# Define a stream printer to grab output from MOSEK
def stream_printer(text):
    sys.stdout.write(text)
    sys.stdout.flush()


# scenario identify function
class DownlinkScenario(object):
    """
    Input to the deployment scene is the action, output is (s2, r, terminal, info).
    The action must be obtained from the output of the Actor network.
    """

    def __init__(self, env, ap_power, noise_power, downlink_bandwidth, ap_number, antenna_number, downlink_QoS,
                 ap_circuit_power, eta_LoS, eta_NLoS, sigma_LoS, sigma_NLoS, light_speed, carrier_frequency,
                 user_number, find_neighbor_dist, vartheta, small_gain, great_gain, theta, phi, ap_height, user_height):
        self.env = env
        self.ap_power = ap_power
        self.noise_power = noise_power  # in dBm
        self.downlink_bandwidth = downlink_bandwidth  # in MHz
        self.ap_number = ap_number
        self.antenna_number = antenna_number
        self.downlink_QoS = downlink_QoS
        self.ap_circuit_power = ap_circuit_power
        self.eta_LoS = eta_LoS
        self.eta_NLoS = eta_NLoS
        self.sigma_LoS = sigma_LoS
        self.sigma_NLoS = sigma_NLoS
        self.light_speed = light_speed
        self.carrier_frequency = carrier_frequency
        self.user_number = user_number
        self.find_neighbor_dist = find_neighbor_dist   # it is the geometric interference model parameter
        self.vartheta = vartheta
        self.small_gain = small_gain
        self.great_gain = great_gain
        self.theta = theta  # it is the antenna downtilt angle
        self.phi = phi
        self.ap_height = ap_height
        self.user_height = user_height
        # self.x_l = x_l
        # self.x_u = x_u
        # self.y_l = y_l
        # self.y_u = y_u

        # initialize the 3-D locations of UAVs, the number of UAVs, power, we assume that the users in the coverage,...
        # ...of the UAV will be covered by the UAV

        # initialize the locations of users, the heterogeneous QoS of users

        # some hyperparameters of air-to-ground channel model, or we should adopt them like the above program

    def dis_calculate_ij(self, user_index, ap_index, user_location, ap_location, user_height, ap_height):
        distance_ij_hori = (
            np.sum(list(map(lambda x: (x[0] - x[1]) ** 2, zip(user_location[user_index], ap_location[ap_index])))))
        # distance = np.sqrt(np.sum(user_location[user_index][i] - ap_location[ap_index][i]
        #                           for i in range(len(user_location[user_index]))))
        distance_ij_vert = (ap_height - user_height[user_index]) ** 2

        distance_ij = np.sqrt(distance_ij_hori + distance_ij_vert)

        return distance_ij

    def neighbor_finding(self, user_index, action_dl_1d_array, user_location):
        user_neighbor = []
        for i_index in range(self.user_number):
            if (user_index != i_index) & (action_dl_1d_array[i_index] == 1):
                distance_ij_hori = (
                    np.sum(
                        list(map(lambda x: (x[0] - x[1]) ** 2, zip(user_location[user_index], user_location[i_index])))))
                if distance_ij_hori <= self.find_neighbor_dist:
                    user_neighbor.append(i_index)

        user_neighbor.insert(0, int(user_index))

        return np.array(user_neighbor)  # return a 1d array

    def calculate_path_loss(self, user_location_input, past_user_location_input,
                            ap_location_input, ref_center_location_input, user_height, ap_height):
        # initialize the H_ij LoS matrix and h_ij NLoS matrix
        h_ijt_matrix = []
        # Step 1: check the LoS status of users towards aps
        b_ijt_matrix = self.los_checking(user_location_input, past_user_location_input, ap_location_input)
        # Step 2: obtain the antenna gain matrix
        antenna_gain_matrix = self.antenna_gain(user_location_input, ap_location_input, ref_center_location_input)
        h_it_vec_collection = []

        # user_location and ap_location are two-dimensional arrays
        for i_index in range(self.user_number):
            h_it_vec = []
            for j_index in range(self.ap_number):
                distance_ij = self.dis_calculate_ij(i_index, j_index, user_location_input, ap_location_input,
                                                    user_height, ap_height)
                if b_ijt_matrix[i_index, j_index]:
                    # calculate the NLoS path loss (1-array in R^{K})
                    # np.random.seed(12339)
                    h_it_vec.append(np.sqrt(antenna_gain_matrix[i_index, j_index]) *
                                    np.sqrt(10 ** (- (10 * self.eta_NLoS * np.log10(distance_ij) +
                                                20 * np.log10(4 * pi * self.carrier_frequency / self.light_speed) +
                                                np.random.normal(0.0, self.sigma_NLoS, self.antenna_number)) / 10.0)))
                    # h_ijt_matrix[range(j_index * self.ap_number), range((i_index * self.ap_number + j_index) * self.antenna_number + 0,
                    #                       (i_index * self.ap_number + j_index) * self.antenna_number +
                    #                       self.antenna_number)] = \
                    #     np.dot(h_ij_nlos.reshape(self.antenna_number, 1), h_ij_nlos.reshape(1, self.antenna_number))
                else:
                    # calculate the LoS path loss (1-array in R^{K})
                    # np.random.seed(12341)
                    h_it_vec.append(np.sqrt(antenna_gain_matrix[i_index, j_index]) *
                                    np.sqrt(10 ** (- (10 * self.eta_LoS * np.log10(distance_ij) +
                                                 20 * np.log10(4 * pi * self.carrier_frequency / self.light_speed) +
                                                 np.random.normal(0.0, self.sigma_LoS, self.antenna_number)) / 10.0)))
                    # h_ijt_matrix[:, range((i_index * self.ap_number + j_index) *
                    #                       self.antenna_number + 0, (i_index * self.ap_number + j_index) *
                    #                       self.antenna_number + self.antenna_number)] = \
                    #     np.dot(h_ij_los.reshape(self.antenna_number, 1), h_ij_los.reshape(1, self.antenna_number))
            # compose the JK * JK matrix, given user i
            h_it_vec = np.array(h_it_vec)
            h_ijt_matrix.append(np.dot(h_it_vec.reshape(self.antenna_number * self.ap_number, 1),
                                           h_it_vec.reshape(1, self.antenna_number * self.ap_number)))
            h_it_vec_collection.append(h_it_vec.reshape(self.antenna_number * self.ap_number, ))  # a list including some 1-d arrays

        return h_ijt_matrix, h_it_vec_collection

    def los_checking(self, user_loc, past_user_loc, ap_loc):
        # Check the LoS status of the user i (for all i) towards j (for all j) at each time slot: 2D coordinate is OK
        b_ijt_matrix = np.zeros((self.user_number, self.ap_number))
        for i_index in range(self.user_number):
            for j_index in range(self.ap_number):
                a_jit = np.array([ap_loc[j_index, 0] - user_loc[i_index, 0], ap_loc[j_index, 1] - user_loc[i_index, 1]])
                x_it = np.array([user_loc[i_index, 0] - past_user_loc[i_index, 0],
                                 user_loc[i_index, 1] - past_user_loc[i_index, 1]])
                # obtain the angle in arc unit
                angle_aji_xi_t = np.arccos(np.dot(a_jit, x_it) / (np.linalg.norm(a_jit) * np.linalg.norm(x_it) + 0.0001))
                if angle_aji_xi_t > self.vartheta:
                    b_ijt_matrix[i_index, j_index] = 1

        return b_ijt_matrix

    def antenna_gain(self, user_loc, ap_loc, ref_center_loc):
        # Obtain the antenna gain between the user i (for all i) and j (for all j) at each time slot: need 3D coordinate
        antenna_gain_matrix = np.ones((self.user_number, self.ap_number)) * 10 ** (self.small_gain/10)
        x_bj_vec3d = np.zeros((self.ap_number, 3))
        for j_index in range(self.ap_number):

            x_oj_vec2d = np.array([ref_center_loc[0, 0] - ap_loc[j_index, 0], ref_center_loc[0, 1] -
                                   ap_loc[j_index, 1]])
            dj_dis = self.ap_height / np.tan(self.theta)
            rj_dis = np.linalg.norm(x_oj_vec2d)
            x_bj_vec3d[j_index, 0] = dj_dis / rj_dis * (ref_center_loc[0, 0] - ap_loc[j_index, 0]) + ap_loc[j_index, 0]
            x_bj_vec3d[j_index, 1] = dj_dis / rj_dis * (ref_center_loc[0, 1] - ap_loc[j_index, 1]) + ap_loc[j_index, 1]

        for i_index in range(self.user_number):
            for j_index in range(self.ap_number):
                cbj_vec = np.array([x_bj_vec3d[j_index, 0] - ap_loc[j_index, 0],
                                    x_bj_vec3d[j_index, 1] - ap_loc[j_index, 1],
                                    x_bj_vec3d[j_index, 2] - self.ap_height])
                cjdi_vec = np.array([user_loc[i_index, 0] - ap_loc[j_index, 0],
                                    user_loc[i_index, 1] - ap_loc[j_index, 1],
                                    self.user_height[i_index] - self.ap_height])
                # obtain the angle BCD in arc
                angle_bcd_t = np.arccos(np.dot(cbj_vec, cjdi_vec) / (np.linalg.norm(cbj_vec) * np.linalg.norm(cjdi_vec) + 0.0001))
                if angle_bcd_t <= self.phi / 2:
                    antenna_gain_matrix[i_index, j_index] = 10 ** (self.great_gain/10)

        return antenna_gain_matrix  # in the unit of times

    def downlink_optimization(self, a_i_dl, user_location, past_user_location, ap_location, ref_center_location, user_height, ap_height):
        with self.env.Task(0, 0) as task:
            task.set_Stream(mosek.streamtype.log, stream_printer)

            # calculate the path loss # it should be a list including I 2D-array
            h_matrix_collection, _ = self.calculate_path_loss(user_location, past_user_location, ap_location, ref_center_location, user_height, ap_height)
            # calculate the number of non-zero element in a_i_dl
            num_none_zero = int(np.sum([np.sum(i) for i in a_i_dl]))
            num_cons = num_none_zero + self.ap_number

            bi = 2 ** (self.downlink_QoS/self.downlink_bandwidth) - 1

            # # obtain the index of users that can be served by APs
            # i_star_collection = []
            # for i_user in range(self.user_number):
            #     for j_ap in range(self.ap_number):
            #         if a_i_dl[i_user][j_ap] == 1:
            #             i_star_collection.append(i_user)
            # assert len(i_star_collection) == num_none_zero, "the number of served users not equals to num_none_zero"

            # constraints; including the semidefinite variables related expressions
            task.appendcons(num_cons)

            for j in range(0, num_none_zero):
                # the first 1e+6 is imposed for MOSEK successful running
                # the second 1e+6 is involved due to the unit of W^{dl} is MHz
                task.putconbound(j, mosek.boundkey.lo, 1e+6 * bi *
                                 (10 ** (self.noise_power/10)) * (self.downlink_bandwidth * 1e+6), +inf)
                task.putconname(j, "SINR[%d]" % j)

            for j in range(0, self.ap_number):
                task.putconbound(num_none_zero * 1 + j, mosek.boundkey.ra, 0.0,
                                 10**(self.ap_power/10) - 10**(self.ap_circuit_power/10))
                # task.putconbound(num_none_zero * 3 + j, mosek.boundkey.lo, 0.0, +inf)
                task.putconname(num_none_zero * 1 + j, "power[%d]" % (num_none_zero * 1 + j))

            # # variables
            # task.appendvars(5 * self.user_number * self.ap_number)

            # # theta variables
            # # task.putclist(range(offset_theta + 0, offset_theta + self.user_number * self.ap_number), [0.0] * self.user_number * self.ap_number)
            # for j in range(0, num_none_zero):
            #     real_i_index = i_star_collection[j]
            #     column_index = real_i_index * self.ap_number + a_i_dl[real_i_index].tolist().index(1)
            #     task.putaij(j, offset_theta + column_index,
            #                 -a_i_dl[real_i_index][a_i_dl[real_i_index].tolist().index(1)] *
            #                 (10 ** (self.noise_power/10)) * (self.downlink_bandwidth * 1e+6) /
            #                 (antenna_gain[real_i_index][a_i_dl[real_i_index].tolist().index(1)] ** 2))
            #     task.putaij(num_none_zero + j, offset_theta + column_index, -1.0)
            #
            # task.putvarboundlist(range(offset_theta + 0, offset_theta + self.user_number * self.ap_number),
            #                      [mosek.boundkey.lo] * (self.user_number * self.ap_number), [i for j in a_i_dl for i in j],
            #                      [+inf] * self.user_number * self.ap_number)
            #
            # for i in range(0, self.user_number):
            #     for j in range(0, self.ap_number):
            #         task.putvarname(offset_theta + i * self.ap_number + j, "theta[%d]" % (offset_theta + i * self.ap_number + j))
            #
            # # ksi variables
            # for j in range(0, num_none_zero):
            #     real_i_index = i_star_collection[j]
            #     column_index = real_i_index * self.ap_number + a_i_dl[real_i_index].tolist().index(1)
            #     task.putaij(2 * num_none_zero + j, offset_ksi + column_index, - np.log(2))
            #
            # task.putvarboundlist(range(offset_ksi + 0, offset_ksi + self.user_number * self.ap_number),
            #                      [mosek.boundkey.lo] * self.user_number * self.ap_number,
            #                      [i * self.downlink_QoS / self.downlink_bandwidth for j in a_i_dl for i in j], [+inf] * self.user_number * self.ap_number)
            #
            # for i in range(0, self.user_number):
            #     for j in range(0, self.ap_number):
            #         task.putvarname(offset_ksi + i * self.ap_number + j, "ksi[%d]" % (offset_ksi + i * self.ap_number + j))
            #
            # # mu variables
            # for j in range(0, num_none_zero):
            #     real_i_index = i_star_collection[j]
            #     column_index = real_i_index * self.ap_number + a_i_dl[real_i_index].tolist().index(1)
            #     task.putaij(num_none_zero + j, offset_mu + column_index, 1.0)
            #
            # task.putvarboundlist(range(offset_mu + 0, offset_mu + self.user_number * self.ap_number),
            #                      [mosek.boundkey.lo] * self.user_number * self.ap_number,
            #                      [i for j in a_i_dl for i in j],
            #                      [+inf] * self.user_number * self.ap_number)
            #
            # for i in range(0, self.user_number):
            #     for j in range(0, self.ap_number):
            #         task.putvarname(offset_mu + i * self.ap_number + j, "mu[%d]" % (offset_mu + i * self.ap_number + j))
            #
            # # lambda variables
            # task.putvarboundlist(range(offset_lambda + 0, offset_lambda + self.user_number * self.ap_number),
            #                      [mosek.boundkey.fx] * self.user_number * self.ap_number,
            #                      [i for j in a_i_dl for i in j],
            #                      [i for j in a_i_dl for i in j])
            #
            # for i in range(0, self.user_number):
            #     for j in range(0, self.ap_number):
            #         task.putvarname(offset_lambda + i * self.ap_number + j, "lambda[%d]" % (offset_lambda + i * self.ap_number + j))
            #
            # # nu variables
            # for j in range(0, num_none_zero):
            #     real_i_index = i_star_collection[j]
            #     column_index = real_i_index * self.ap_number + a_i_dl[real_i_index].tolist().index(1)
            #     task.putaij(2 * num_none_zero + j, offset_nu + column_index, 1.0)
            #
            # task.putvarboundlist(range(offset_nu + 0, offset_nu + self.user_number * self.ap_number),
            #                      [mosek.boundkey.lo] * self.user_number * self.ap_number,
            #                      [i * self.downlink_QoS / (self.downlink_bandwidth * np.log(2)) for j in a_i_dl for i in j],
            #                      [+inf] * self.user_number * self.ap_number)
            #
            # for i in range(0, self.user_number):
            #     for j in range(0, self.ap_number):
            #         task.putvarname(offset_nu + i * self.ap_number + j, "nu[%d]" % (offset_nu + i * self.ap_number + j))

            # SDP cones
            task.appendbarvars([self.antenna_number * self.ap_number] * self.user_number)

            # the first group of constraints
            h_matrix_len = int(self.antenna_number * self.ap_number * (self.antenna_number * self.ap_number + 1) / 2)
            real_constraint_num = 0
            for i_index in range(self.user_number):
                if a_i_dl[i_index][0]:
                    # Step 1: find the index collection of the interference nodes of user i
                    active_i_dl = np.sum(a_i_dl, 1)
                    i_neighbor = self.neighbor_finding(i_index, active_i_dl.reshape((self.user_number, )),
                                                       user_location)
                    active_interfer_node_collection = []
                    for i_neighbor_index in range(i_neighbor.size):
                        if (i_neighbor[i_neighbor_index] != i_index) & (a_i_dl[i_neighbor[i_neighbor_index]][0] != 0):
                            active_interfer_node_collection.append(i_neighbor[i_neighbor_index])

                    if active_interfer_node_collection:  # i.e., a_i' = 1
                        # there exist some interference nodes
                        ele_num = (1 + active_interfer_node_collection.__len__()) * h_matrix_len
                        # initialize with the user i's location index
                        subi = [real_constraint_num] * h_matrix_len
                        subj = [i_index] * h_matrix_len
                        subk = []
                        subl = []
                        valijkl = []
                        # lower triangle matrix construction; the multiplied 1e+6 is a trick for MOSEK's successful run
                        h_matrixij = h_matrix_collection[i_index] * 1e+6
                        for h_i in range(self.antenna_number * self.ap_number):
                            for h_j in range(self.antenna_number * self.ap_number):
                                if h_i >= h_j:
                                    subk.append(h_i)
                                    subl.append(h_j)
                                    valijkl.append(h_matrixij[h_i][h_j])

                        # Specify the interfering nodes' location indexes
                        for interfer_index in range(active_interfer_node_collection.__len__()):
                            actual_interfer_index = active_interfer_node_collection[interfer_index]
                            subi = subi + [real_constraint_num] * h_matrix_len
                            subj = subj + [actual_interfer_index] * h_matrix_len

                            h_matrix_interfer_i = h_matrix_collection[actual_interfer_index] * 1e+6
                            for h_i in range(self.antenna_number * self.ap_number):
                                for h_j in range(self.antenna_number * self.ap_number):
                                    if h_i >= h_j:
                                        subk.append(h_i)
                                        subl.append(h_j)
                                        valijkl.append(-bi * h_matrix_interfer_i[h_i][h_j])
                        assert subi.__len__() == ele_num, "The SINR related element number should be compatible!"
                        task.putbarablocktriplet(ele_num,
                                                 subi,
                                                 subj,
                                                 subk,
                                                 subl,
                                                 valijkl)
                    else:
                        # there are no interference nodes
                        # lower triangle matrix construction
                        h_matrixij = h_matrix_collection[i_index] * 1e+6
                        subk = []
                        subl = []
                        valijkl = []
                        for h_i in range(self.antenna_number * self.ap_number):
                            for h_j in range(self.antenna_number * self.ap_number):
                                if h_i >= h_j:
                                    subk.append(h_i)
                                    subl.append(h_j)
                                    valijkl.append(h_matrixij[h_i][h_j])
                        task.putbarablocktriplet(h_matrix_len,
                                                 [real_constraint_num] * h_matrix_len,
                                                 [i_index] * h_matrix_len,
                                                 subk,
                                                 subl,
                                                 valijkl)

                    real_constraint_num = real_constraint_num + 1

                # real_i_index = i_star_collection[j]
                # # offset of the SDP variable
                # offset_vij = real_i_index * self.ap_number
                # column_index = offset_vij + a_i_dl[real_i_index].tolist().index(1)
                # # off set of the matrix V_ij
                # offset_hij = column_index * self.antenna_number
                # h_matrixij = h_matrix[:, list(range(offset_hij + 0, offset_hij + self.antenna_number))]
                # subk = []
                # subl = []
                # valijkl = []
                #
                # # lower triangle matrix construction
                # for h_i in range(self.antenna_number):
                #     for h_j in range(self.antenna_number):
                #         if h_i >= h_j:
                #             subk.append(h_i)
                #             subl.append(h_j)
                #             valijkl.append(h_matrixij[h_i][h_j])
                #
                # task.putbarablocktriplet(h_matrix_len,
                #                          [j] * h_matrix_len,
                #                          [column_index] * h_matrix_len,
                #                          subk,
                #                          subl,
                #                          valijkl)

            # the second group of constraints
            for j in range(self.ap_number):
                for i_index in range(self.user_number):
                    if a_i_dl[i_index][0]:
                        task.putbarablocktriplet(self.antenna_number,
                                                 [num_none_zero * 1 + j] * self.antenna_number,
                                                 [i_index] * self.antenna_number,
                                                 list(range(j * self.antenna_number,
                                                            j * self.antenna_number + self.antenna_number)),
                                                 list(range(j * self.antenna_number,
                                                            j * self.antenna_number + self.antenna_number)),
                                                 [1] * self.antenna_number
                                                 )

            for i in range(0, self.user_number):
                task.putbarvarname(i, "X[%d]" % i)

            # task.putobjsense(mosek.objsense.maximize)
            task.putobjsense(mosek.objsense.minimize)

            # Turn all log output off
            task.putintparam(mosek.iparam.log, 0)

            # Dump the problem to a human readable ODF file
            # task.writedata("test.ptf")

            task.optimize()

            # Display the solution summary for quick inspection of results
            task.solutionsummary(mosek.streamtype.msg)

            # get status information about the solution
            solsta = task.getsolsta(mosek.soltype.itr)

            X_matrix_collection = []  # list of shape user_number * ap_number
            if solsta == mosek.solsta.optimal:  # mosek.solsta.near_optimal is not supported
                # print("Solution (Lower-triangular part vectorized):")
                # print("Optimal solution is found! \n")
                for i in range(self.user_number):
                    X = [0.0] * h_matrix_len
                    X_matrix = np.zeros((self.antenna_number * self.ap_number, self.antenna_number * self.ap_number))
                    task.getbarxj(mosek.soltype.itr, i, X)
                    # print("X{i} = {X}".format(i=i, X=X))

                    # generate the symmetric matrix
                    count_sym = 0
                    for sym_index_i in range(self.antenna_number*self.ap_number):
                        for sym_index_j in range(self.antenna_number*self.ap_number):
                            if sym_index_i >= sym_index_j:
                                X_matrix[sym_index_i][sym_index_j] = X[count_sym]
                                count_sym = count_sym + 1
                    X_matrix = X_matrix + np.tril(X_matrix, -1).transpose()
                    X_matrix_collection.append(X_matrix)
                pro_feasibility = True
            elif (solsta == mosek.solsta.dual_infeas_cer or
                  solsta == mosek.solsta.prim_infeas_cer):
                # mosek.solsta.near_dual_infeas_cer and mosek.solsta.near_prim_infeas_cer are not supported
                # print("Primal or dual infeasibility certification found! \n")
                pro_feasibility = False
                X_matrix_collection = [np.zeros((self.antenna_number*self.ap_number, self.antenna_number*self.ap_number))] * \
                                      self.user_number
            elif solsta == mosek.solsta.unknown:
                print("Unknown solution status! \n")
                pro_feasibility = False
                X_matrix_collection = [np.zeros((self.antenna_number*self.ap_number, self.antenna_number*self.ap_number))] * \
                                      self.user_number
            else:
                print("Other solution status!")
                pro_feasibility = False
                X_matrix_collection = [np.zeros((self.antenna_number*self.ap_number, self.antenna_number*self.ap_number))] * \
                                      self.user_number

            return X_matrix_collection, pro_feasibility  # it is a list including V_{ij}: user_number * ap_number 2-d arrays

    def modify_power_matrix(self, ori_pw_matrix, u_star_index, rnd_num, user_location, a_i_dl, past_user_location,
                            ap_location, ref_center_location, user_height, ap_height):

        pow_ref = 1e+9
        record_ind = 0
        record_ind_ori = 0

        eig_val, eig_matrix = np.linalg.eig(ori_pw_matrix[u_star_index])

        if np.sum(np.abs(eig_val) >= 1e-3) <= 1:  # it means that rank(Pow_mat) <= 1
            return eig_val, eig_matrix
        else:
            print('Start modifying the power matrix!')

            # step 1: some eigenvalues may be negative
            eig_val[np.abs(eig_val) <= 1e-3] = 0
            eig_val_sign = np.ones((eig_val.size,))
            eig_val_sign[eig_val < 0] = -1
            eig_val_plus_sqrt = np.sqrt(np.abs(eig_val))
            eig_val_sqrt_2d = np.diag(np.multiply(eig_val_plus_sqrt, eig_val_sign))

            z = np.zeros((rnd_num, self.antenna_number * self.ap_number))
            for rnd_i in range(rnd_num):
                z[rnd_i] = np.random.randn(self.antenna_number * self.ap_number)
            z_collection = np.matmul(np.matmul(eig_matrix, eig_val_sqrt_2d), z.transpose())

            # calculate the path loss # it should be a list including I 2D-array
            h_matrix_collection, _ = self.calculate_path_loss(user_location, past_user_location, ap_location,
                                                              ref_center_location, user_height, ap_height)
            bi = 2 ** (self.downlink_QoS / self.downlink_bandwidth) - 1

            for rnd_i in range(rnd_num):
                qos_indicator = 1  # 1 denotes satisfy; 0 denotes unsatisfied

                # randomly generate a power matrix, and check the feasibility of the power matrix
                pow_i_matrix = np.matmul(np.reshape(z_collection[:, rnd_i], (np.size(z_collection[:, rnd_i]), 1)),
                                    np.reshape(z_collection[:, rnd_i], (1, np.size(z_collection[:, rnd_i]))))
                active_i_dl = np.sum(a_i_dl, 1)
                # Step 1: check whether the total power consumption can be satisfied
                pw_indicator = 1  # denotes that the power consumption can be satisfied
                for j_ap in range(self.ap_number):
                    identify_matrix = np.zeros((self.ap_number * self.antenna_number, self.ap_number * self.antenna_number))
                    for k_ap in range(self.antenna_number):
                        identify_matrix[j_ap*self.antenna_number+k_ap][j_ap*self.antenna_number+k_ap] = 1
                    updated_pow = np.trace(np.matmul(identify_matrix, pow_i_matrix))
                    trace_vec = np.zeros((self.user_number, 1))
                    for i_user in range(self.user_number):
                        trace_vec[i_user] = np.trace(np.matmul(identify_matrix, ori_pw_matrix[i_user]))
                    trace_vec[u_star_index] = updated_pow
                    pw_consum = np.matmul(active_i_dl.reshape((1, self.user_number)), trace_vec)
                    if pw_consum[0][0] > 10**(self.ap_power/10) - 10**(self.ap_circuit_power/10):
                        pw_indicator = 0
                # Step 2: check whether the QoS can be satisfied
                if pw_indicator:
                    i_neighbor = self.neighbor_finding(u_star_index, active_i_dl.reshape((self.user_number,)),
                                                       user_location)  # find the interfering neighbors of user star
                    active_interfer_node_collection = []
                    for i_neighbor_index in range(i_neighbor.size):
                        if (i_neighbor[i_neighbor_index] != u_star_index) & (
                                a_i_dl[i_neighbor[i_neighbor_index]][0] != 0):
                            active_interfer_node_collection.append(i_neighbor[i_neighbor_index])

                    if active_interfer_node_collection:
                        # there exist some interference nodes
                        # calculate the interference value
                        interference_val = 0
                        for interfer_index in range(active_interfer_node_collection.__len__()):
                            actual_interfer_index = active_interfer_node_collection[interfer_index]
                            h_matrix_interfer_i = h_matrix_collection[actual_interfer_index]
                            power_matrix_interfer_i = ori_pw_matrix[actual_interfer_index]
                            interference_val += a_i_dl[actual_interfer_index][0] * \
                                                np.trace(np.matmul(h_matrix_interfer_i, power_matrix_interfer_i))
                        actu_qos_val = np.trace(np.matmul(h_matrix_collection[u_star_index], pow_i_matrix)) - \
                                       bi * interference_val
                        if actu_qos_val <= bi * (10 ** (self.noise_power / 10)) * (self.downlink_bandwidth * 1e+6):
                            # QoS is unsatisfied
                            qos_indicator = 0
                    else:
                        # no interference
                        actu_qos_val = np.trace(np.matmul(h_matrix_collection[u_star_index], pow_i_matrix))
                        if actu_qos_val <= bi * (10 ** (self.noise_power / 10)) * (self.downlink_bandwidth * 1e+6):
                            # QoS is unsatisfied
                            qos_indicator = 0

                    if qos_indicator:  # QoS is satisfied
                        if np.trace(pow_i_matrix) <= pow_ref:
                            pow_ref = np.trace(pow_i_matrix)
                            if not rnd_i:
                                record_ind = rnd_i
                                record_ind_ori = 1  # rnd_i = 0, i.e., the first generated matrix will be okay
                            else:
                                record_ind = rnd_i
                                record_ind_ori = 0

            if record_ind or record_ind_ori:  # found the feasible power matrix
                sel_pw_matrix = np.dot(np.reshape(z_collection[:, record_ind], (np.size(z_collection[:, record_ind]), 1)),
                                      np.reshape(z_collection[:, record_ind], (1, np.size(z_collection[:, record_ind]))))
                eig_val, eig_matrix = np.linalg.eig(sel_pw_matrix)
                print('Found a feasible modified power matrix!')
                return eig_val, eig_matrix
            else:  # cannot find the modified matrix such that rank(pw_mat) <= 1; return the original power matrix
                print('Oops! Cannot find a feasible modified power matrix!')
                return eig_val, eig_matrix

