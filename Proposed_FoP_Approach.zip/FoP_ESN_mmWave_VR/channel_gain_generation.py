import numpy as np
import math
import mosek
import sys

pi = 3.1415926925
inf = 0.0


from ap_location_generation import ApLocationGeneration


class ChannelGain(object):
    """
    Input to the deployment scene is the action, output is (s2, r, terminal, info).
    The action must be obtained from the output of the Actor network.
    """

    def __init__(self, env, ap_power, noise_power, downlink_bandwidth, ap_number, antenna_number, downlink_QoS,
                 ap_circuit_power, eta_LoS, eta_NLoS, sigma_LoS, sigma_NLoS, light_speed, carrier_frequency, user_number,
                 find_neighbor_dist, gamma, radius, ap_height, phi, big_gain, small_gain, vartheta):
        self.env = env
        self.ap_power = ap_power
        self.noise_power = noise_power  # in dBm
        self.downlink_bandwidth = downlink_bandwidth  # in MHz
        self.ap_number = ap_number
        self.antenna_number = antenna_number
        self.downlink_QoS = downlink_QoS
        self.ap_circuit_power = ap_circuit_power
        self.eta_LoS = eta_LoS
        self.eta_NLoS = eta_NLoS
        self.sigma_LoS = sigma_LoS
        self.sigma_NLoS = sigma_NLoS
        self.light_speed = light_speed
        self.carrier_frequency = carrier_frequency
        self.user_number = user_number
        self.find_neighbor_dist = find_neighbor_dist
        self.gamma = gamma
        self.phi = phi
        self.big_gain = big_gain
        self.small_gain = small_gain
        self.vartheta = vartheta

        self.ap_location_generation = ApLocationGeneration(radius, ap_number, ap_height)
        self.ap_locations = self.ap_location_generation.generate_ap_locations()

        # self.x_l = x_l
        # self.x_u = x_u
        # self.y_l = y_l
        # self.y_u = y_u

        # initialize the 3-D locations of UAVs, the number of UAVs, power, we assume that the users in the coverage,...
        # ...of the UAV will be covered by the UAV

        # initialize the locations of users, the heterogeneous QoS of users

        # some hyperparameters of air-to-ground channel model, or we should adopt them like the above program

    def dis_calculate_two_point(self, point1_location, point2_location):
        # point1 and point2 are 2d array
        distance_hori = (
            np.sum(list(map(lambda x: (x[0] - x[1]) ** 2, zip(point1_location, point2_location)))))

        distance = np.sqrt(distance_hori)

        return distance

    def dis_calculate_ij(self, user_index, ap_index, user_location, ap_location, user_height, ap_height):
        distance_ij_hori = (
            np.sum(list(map(lambda x: (x[0] - x[1]) ** 2, zip(user_location[user_index], ap_location[ap_index])))))
        # distance = np.sqrt(np.sum(user_location[user_index][i] - ap_location[ap_index][i]
        #                           for i in range(len(user_location[user_index]))))
        distance_ij_vert = (ap_height - user_height[user_index]) ** 2

        distance_ij = np.sqrt(distance_ij_hori + distance_ij_vert)

        return distance_ij

    def determine_b_location(self, theta_collection):
        # determine the location of B_j, for all j
        # step 1: get ap's locations
        # ap_locations = self.ap_location_generation.generate_ap_locations()
        # step 2: get the reference center point locations
        center_locations = self.ap_location_generation.generate_ap_center_point_locations()
        # step 3: calculate the distance, r
        distance_collection = []
        for j in range(self.ap_number):
            distance_collection.append(self.dis_calculate_two_point(self.ap_locations[j], center_locations[j]))

        # step 4: calculate the distance, d
        d_distance = []
        for j in range(self.ap_number):
            d_distance.append(self.ap_locations[0][2] / np.tan(theta_collection[j] * np.pi/180))

        # step 5: obtain the B_j's location
        b_location_collection = []
        for j in range(self.ap_number):
            x_b = d_distance[j]/distance_collection[j]*(center_locations[j][0]-self.ap_locations[j][0]) + \
                  self.ap_locations[j][0]
            y_b = d_distance[j]/distance_collection[j]*(center_locations[j][1]-self.ap_locations[j][1]) + \
                  self.ap_locations[j][1]
            b_location_collection.append([x_b, y_b, 0])

        b_location_collection = np.array(b_location_collection)  # a 2D array, R^{J * 3}

        return b_location_collection

    def determine_user_tilt_angle(self, theta_collection, user_locations):
        # step 1: get all B_j's locations
        b_location_collection = self.determine_b_location(theta_collection)
        # step 2: calculate the vector CjBj
        vec_cb = b_location_collection - self.ap_locations
        # step 3: calculate the user tilt angles
        user_tilt_angle_collection = []
        for j in range(self.ap_number):
            angle_bcd_j = []
            for i_index in range(self.user_number):
                vec_cd_ij = user_locations[i_index] - self.ap_locations[j]
                angle_bcd_j.append(np.dot(vec_cd_ij, vec_cb[j]) /
                                   np.sqrt(np.dot(vec_cd_ij, vec_cd_ij)) * np.sqrt(np.dot(vec_cb[j], vec_cb[j])))

            user_tilt_angle_collection.append(angle_bcd_j)

        user_tilt_angle_collection = np.array(user_tilt_angle_collection)  # in 2d array R^{J * I}

        return user_tilt_angle_collection

    def antenna_gain_matrix(self, theta_collection, user_locations):
        antenna_gain_matrix = np.zeros((self.user_number, self.ap_number))
        user_tilt_angle = self.determine_user_tilt_angle(theta_collection, user_locations)
        for j in range(self.ap_number):
            for i_index in range(self.user_number):
                if user_tilt_angle[j, i_index] <= 1/2 * self.phi:
                    antenna_gain_matrix[i_index, j] = self.big_gain
                else:
                    antenna_gain_matrix[i_index, j] = self.small_gain

        return antenna_gain_matrix  # in 2d array, R^{I * J}

    def blockage_matrix(self, orientation, user_locations):
        # orientation is a 1d array
        blockage_matrix = np.zeros((self.user_number, self.ap_number))
        # calculate the directional vector
        for i_index in range(self.user_number):
            vec_i = np.array([np.cos(orientation[i_index] * np.pi / 180), np.sin(orientation[i_index] * np.pi / 180)])
            for j in range(self.ap_number):
                vec_ji = np.array([user_locations[i_index, 0] - self.ap_number[j, 0],
                                   user_locations[i_index, 1] - self.ap_number[j, 1]])
                angle = np.dot(vec_i, vec_ji) / (np.sqrt(np.dot(vec_i, vec_i)) * np.sqrt(np.dot(vec_ji, vec_ji)))
                if angle < self.vartheta:
                    blockage_matrix[i_index, j] = 1

        return blockage_matrix

    def calculate_path_loss(self, user_locations, ap_locations, orientation, user_height, ap_height):
        # initialize the H_ij LoS matrix and h_ij NLoS matrix
        blockage_matrix = self.blockage_matrix(self, orientation, user_locations)

        # user_location and ap_location are two-dimensional arrays
        h_matrix = []
        for i_index in range(self.user_number):
            h_i_vec = []
            for j_index in range(self.ap_number):
                distance_ij = self.dis_calculate_ij(i_index, j_index, user_locations, ap_locations,
                                                    user_height, ap_height)
                # calculate the LoS path loss (1-array in R^{K})
                if not blockage_matrix[i_index, j_index]:
                    np.random.seed(12341)
                    h_ij_loss = np.sqrt(10 ** (- (10 * self.eta_LoS * np.log10(distance_ij) +
                                                  20 * np.log10(4 * pi * self.carrier_frequency / self.light_speed) +
                                                  np.random.normal(0.0, self.sigma_LoS, self.antenna_number)) / 10.0))
                else:
                    # calculate the NLoS path loss (1-array in R^{K})
                    np.random.seed(12339)
                    h_ij_loss = np.sqrt(10 ** (- (10 * self.eta_NLoS * np.log10(distance_ij) +
                                                  20 * np.log10(4 * pi * self.carrier_frequency / self.light_speed) +
                                                  np.random.normal(0.0, self.sigma_NLoS, self.antenna_number)) / 10.0))

                h_i_vec.append(h_ij_loss.tolist())  # collect the channel related to user i

            h_i_matrix = np.dot(np.array(h_i_vec).reshape(self.antenna_number*self.ap_number, 1), np.array(h_i_vec).reshape(1, self.antenna_number*self.ap_number))
            h_matrix.append(h_i_matrix)

        return h_matrix  # a list (R^I) with each element being a 2D array (JK * JK)

