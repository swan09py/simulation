import numpy as np


# scenario identify function
class ApLocationGeneration(object):
    """
    Input to the deployment scene is the action, output is (s2, r, terminal, info).
    The action must be obtained from the output of the Actor network.
    """

    def __init__(self, radius, ap_number, ap_height):
        self.radius = radius
        self.ap_number = ap_number
        self.ap_height = ap_height

    def generate_ap_locations(self):
        ap_locations = []

        for j in range(self.ap_number):
            ap_locations.append([self.radius * np.sin(j/self.ap_number * 2 * np.pi) + self.radius,
                                 self.radius * np.cos(j/self.ap_number * 2 * np.pi) + self.radius, self.ap_height])

        ap_locations = np.array(ap_locations)

        return ap_locations  # a 2D array, R^{J * 3}:

    def generate_ap_center_point_locations(self):
        ap_center_point_locations = []
        ap_locations = self.generate_ap_locations()  # in a 2D array

        for j in range(self.ap_number):
            x_c = 1/2 * (self.radius + ap_locations[j][0])
            y_c = 1/2 * (self.radius + ap_locations[j][1])

            ap_center_point_locations.append([x_c, y_c, 0])

        ap_center_point_locations = np.array(ap_center_point_locations)

        return ap_center_point_locations   # a 2D array, R^{J * 3}

