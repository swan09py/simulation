
import numpy as np


class ComputeNRMSE:
    def __init__(self):
        self.forgetPoint = 0

    def compute_nrmse(self, estimated_output_para, correct_output_para):
        num_estimated_point = len(estimated_output_para)
        num_correct_point = len(correct_output_para)
        num_forget_point = num_correct_point - num_estimated_point

        correct_output = correct_output_para[num_forget_point:]
        correct_variance = np.var(correct_output_para)
        mean_error = np.sum((estimated_output_para - correct_output)**2) / num_estimated_point
        # print(id(correct_output_para))
        # print(id(correct_output))
        if correct_variance:
            return np.sqrt(mean_error / correct_variance)
        else:
            return np.sqrt(mean_error)



