clear;
clc;
close all;

Epoch_len = 10000;
epoch = 1:Epoch_len;
average_interval = 50;

%% The proposed algorithm's performance self verification
%   %  UPlink  scenario
% vs. learning rate
UL_vs_lr_loss = [];
UL_vs_lr_reward = [];
lr_count = 1;
lr_collection = [10000, 1000, 100, 10, 1]/1e+5;
for lr = [10000, 1000, 100, 10, 1]
Prop_up_reward_char = ...
    ['C:\Users\swan\PycharmProjects\Federated_ESN_VR\Simulation_results_collection\DNN_Self_Verification_Results\OP_UL_reward_t_value_MiniBatchSize_64_TrainInterv_20_LearnRate_', num2str(lr), '.mat'];
Prop_up_loss_char = ...
    ['C:\Users\swan\PycharmProjects\Federated_ESN_VR\Simulation_results_collection\DNN_Self_Verification_Results\OP_uplink_critic_loss_MiniBatchSize_64_TrainInterv_20_LearnRate_', num2str(lr), '.mat'];

Prop_up_reward_val = load(Prop_up_reward_char);
Prop_up_loss_val = load(Prop_up_loss_char);
UL_vs_lr_loss{lr_count} = Prop_up_loss_val.uplink_critic_loss;  % they have the same column length

len_reward = length(Prop_up_reward_val.reward_t_value);
aver_proposed_reward = [];
for aver = (average_interval+1):len_reward
    aver_proposed_reward = [aver_proposed_reward, mean(Prop_up_reward_val.reward_t_value(aver - average_interval : aver))];
end
UL_vs_lr_reward{lr_count} = aver_proposed_reward;

lr_count = lr_count + 1;
end

figure(1);
for lr_len = 1:length(lr_collection)
plot(1 : length(UL_vs_lr_loss{1, lr_len}), UL_vs_lr_loss{1, lr_len});
hold on;
end
figure(2);
for lr_len = 1:length(lr_collection)
plot(1 : length(UL_vs_lr_reward{1, lr_len}), UL_vs_lr_reward{1, lr_len});
hold on;
end

% vs. batch size
UL_vs_bats_loss = {};
UL_vs_bats_reward = {};
count_bats = 1;
batchsize_collection = [64, 128, 256, 512, 1024, 2048];
for bats = [64, 128, 256, 512, 1024, 2048]
Prop_up_reward_char = ...
    ['C:\Users\swan\PycharmProjects\Federated_ESN_VR\Simulation_results_collection\DNN_Self_Verification_Results\OP_UL_reward_t_value_MiniBatchSize_', num2str(bats), '_TrainInterv_20_LearnRate_10000.mat'];
Prop_up_loss_char = ...
    ['C:\Users\swan\PycharmProjects\Federated_ESN_VR\Simulation_results_collection\DNN_Self_Verification_Results\OP_uplink_critic_loss_MiniBatchSize_', num2str(bats) '_TrainInterv_20_LearnRate_10000.mat'];

Prop_up_reward_val = load(Prop_up_reward_char);
Prop_up_loss_val = load(Prop_up_loss_char);
UL_vs_bats_loss{count_bats} = Prop_up_loss_val.uplink_critic_loss;

% UL_vs_bats_reward{count_bats} = Prop_up_reward_val.reward_t_value;
len_reward = length(Prop_up_reward_val.reward_t_value);
aver_proposed_reward = [];
for aver = (average_interval+1):len_reward
    aver_proposed_reward = [aver_proposed_reward, mean(Prop_up_reward_val.reward_t_value(aver - average_interval : aver))];
end
UL_vs_bats_reward{count_bats} = aver_proposed_reward;

count_bats = count_bats + 1;
end

figure(3);
for bats_len = 1:length(batchsize_collection)
plot(1 : length(UL_vs_bats_loss{1, bats_len}), UL_vs_bats_loss{1, bats_len});
hold on;
end

% figure(4);
% subplot(1, 2, 1);
% plot(1 : length(UL_vs_bats_loss{1, 1}), UL_vs_bats_loss{1, 1});
% subplot(1, 2, 2);
% plot(1 : length(UL_vs_bats_loss{1, 4}), UL_vs_bats_loss{1, 4});


figure(4);
for bats_len = 1:length(batchsize_collection)
plot(1 : length(UL_vs_bats_reward{1, bats_len}), UL_vs_bats_reward{1, bats_len});
hold on;
end

% vs. training interval
UL_vs_tri_loss = {};
UL_vs_tri_reward = {};
tri_count = 1;
training_interval_collection = [5, 10, 20, 50, 100];
for tri = [5, 10, 20, 50, 100]
Prop_up_reward_char = ...
    ['C:\Users\swan\PycharmProjects\Federated_ESN_VR\Simulation_results_collection\DNN_Self_Verification_Results\OP_UL_reward_t_value_MiniBatchSize_64_TrainInterv_', num2str(tri), '_LearnRate_10000.mat'];
Prop_up_loss_char = ...
    ['C:\Users\swan\PycharmProjects\Federated_ESN_VR\Simulation_results_collection\DNN_Self_Verification_Results\OP_uplink_critic_loss_MiniBatchSize_64_TrainInterv_', num2str(tri), '_LearnRate_10000.mat'];

Prop_up_reward_val = load(Prop_up_reward_char);
Prop_up_loss_val = load(Prop_up_loss_char);
UL_vs_tri_loss{tri_count} = Prop_up_loss_val.uplink_critic_loss;  % using the cell because they have different column length

% UL_vs_tri_reward{tri_count} = Prop_up_reward_val.reward_t_value;
len_reward = length(Prop_up_reward_val.reward_t_value);
aver_proposed_reward = [];
for aver = (average_interval+1):len_reward
    aver_proposed_reward = [aver_proposed_reward, mean(Prop_up_reward_val.reward_t_value(aver - average_interval : aver))];
end
UL_vs_tri_reward{tri_count} = aver_proposed_reward;

tri_count = tri_count + 1;
end

figure(5);
for tri_len = 1:length(training_interval_collection)
plot(1 : length(UL_vs_tri_loss{1, tri_len}), UL_vs_tri_loss{1, tri_len});
hold on;
end
figure(6);
for tri_len = 1:length(training_interval_collection)
plot(1 : length(UL_vs_tri_reward{1, tri_len}), UL_vs_tri_reward{1, tri_len});
hold on;
end

%   %   Downlink scenario
% vs. learning rate
DL_vs_lr_loss = [];
DL_vs_lr_reward = [];
lr_count = 1;
lr_collection = [10000, 1000, 100, 10, 1]/1e+5;
for lr = [10000, 1000, 100, 10, 1]
Prop_dl_reward_char = ...
    ['C:\Users\swan\PycharmProjects\Federated_ESN_VR\Simulation_results_collection\DNN_Self_Verification_Results\OP_DL_reward_t_value_MiniBatchSize_64_TrainInterv_20_LearnRate_', num2str(lr), '.mat'];
Prop_dl_loss_char = ...
    ['C:\Users\swan\PycharmProjects\Federated_ESN_VR\Simulation_results_collection\DNN_Self_Verification_Results\OP_downlink_critic_loss_MiniBatchSize_64_TrainInterv_20_LearnRate_', num2str(lr), '.mat'];

Prop_dl_reward_val = load(Prop_dl_reward_char);
Prop_dl_loss_val = load(Prop_dl_loss_char);
DL_vs_lr_loss{lr_count} = Prop_dl_loss_val.downlink_critic_loss;  % they have the same column length
% DL_vs_lr_reward{lr_count} = Prop_dl_reward_val.reward_t_value;

len_reward = length(Prop_dl_reward_val.reward_t_value);
aver_proposed_reward = [];
for aver = (average_interval+1):len_reward
    aver_proposed_reward = [aver_proposed_reward, mean(Prop_dl_reward_val.reward_t_value(aver - average_interval : aver))];
end
DL_vs_lr_reward{lr_count} = aver_proposed_reward;

lr_count = lr_count + 1;
end



figure(7);
for lr_len = 1:length(lr_collection)
plot(1 : length(DL_vs_lr_loss{1, lr_len}), log(DL_vs_lr_loss{1, lr_len}));
hold on;
end
figure(8);
for lr_len = 1:length(lr_collection)
plot(1 : length(DL_vs_lr_reward{1, lr_len}), DL_vs_lr_reward{1, lr_len});
hold on;
end

% vs. batch size
DL_vs_bats_loss = [];
DL_vs_bats_reward = [];
bats_count = 1;
batchsize_collection = [64, 128, 256, 512, 1024, 2048];
for bats = [64, 128, 256, 512, 1024, 2048]
Prop_dl_reward_char = ...
    ['C:\Users\swan\PycharmProjects\Federated_ESN_VR\Simulation_results_collection\DNN_Self_Verification_Results\OP_DL_reward_t_value_MiniBatchSize_', num2str(bats), '_TrainInterv_20_LearnRate_1000.mat'];
Prop_dl_loss_char = ...
    ['C:\Users\swan\PycharmProjects\Federated_ESN_VR\Simulation_results_collection\DNN_Self_Verification_Results\OP_downlink_critic_loss_MiniBatchSize_', num2str(bats) '_TrainInterv_20_LearnRate_1000.mat'];

Prop_dl_reward_val = load(Prop_dl_reward_char);
Prop_dl_loss_val = load(Prop_dl_loss_char);
DL_vs_bats_loss{bats_count} = Prop_dl_loss_val.downlink_critic_loss;
% DL_vs_bats_reward{bats_count} = Prop_dl_reward_val.reward_t_value;

len_reward = length(Prop_dl_reward_val.reward_t_value);
aver_proposed_reward = [];
for aver = (average_interval+1):len_reward
    aver_proposed_reward = [aver_proposed_reward, mean(Prop_dl_reward_val.reward_t_value(aver - average_interval : aver))];
end
DL_vs_bats_reward{bats_count} = aver_proposed_reward;

bats_count = bats_count + 1;
end

figure(9);
for bats_len = 1:length(batchsize_collection)
plot(1 : length(DL_vs_bats_loss{1, bats_len}), DL_vs_bats_loss{1, bats_len});
hold on;
end
figure(10);
for bats_len = 1:length(batchsize_collection)
plot(1 : length(DL_vs_bats_reward{1, bats_len}), DL_vs_bats_reward{1, bats_len});
hold on;
end

% vs. training interval
DL_vs_tri_loss = {};
DL_vs_tri_reward = {};
tri_count = 1;
training_interval_collection = [5, 10, 20, 50, 100];
for tri = [5, 10, 20, 50, 100]
Prop_dl_reward_char = ...
    ['C:\Users\swan\PycharmProjects\Federated_ESN_VR\Simulation_results_collection\DNN_Self_Verification_Results\OP_DL_reward_t_value_MiniBatchSize_64_TrainInterv_', num2str(tri), '_LearnRate_1000.mat'];
Prop_dl_loss_char = ...
    ['C:\Users\swan\PycharmProjects\Federated_ESN_VR\Simulation_results_collection\DNN_Self_Verification_Results\OP_downlink_critic_loss_MiniBatchSize_64_TrainInterv_', num2str(tri), '_LearnRate_1000.mat'];

Prop_dl_reward_val = load(Prop_dl_reward_char);
Prop_dl_loss_val = load(Prop_dl_loss_char);
DL_vs_tri_loss{tri_count} = Prop_dl_loss_val.downlink_critic_loss;  % using the cell because they have different column length
% DL_vs_tri_reward{tri_count} = Prop_dl_reward_val.reward_t_value;

len_reward = length(Prop_dl_reward_val.reward_t_value);
aver_proposed_reward = [];
for aver = (average_interval+1):len_reward
    aver_proposed_reward = [aver_proposed_reward, mean(Prop_dl_reward_val.reward_t_value(aver - average_interval : aver))];
end
DL_vs_tri_reward{tri_count} = aver_proposed_reward;

tri_count = tri_count + 1;
end

figure(11);
for tri_len = 1:length(training_interval_collection)
plot(1 : length(DL_vs_tri_loss{1, tri_len}), DL_vs_tri_loss{1, tri_len});
hold on;
end
figure(12);
for tri_len = 1:length(training_interval_collection)
plot(1 : length(DL_vs_tri_reward{1, tri_len}), DL_vs_tri_reward{1, tri_len});
hold on;
end


%% Compare with other algorithms
% uplink results
UL_pro_vs_Num_reward = [];
user_num_collction = [8, 12, 16, 20];
for user_num = [8, 12, 16, 20]
Prop_ul_reward_char = ...
    ['C:\Users\swan\PycharmProjects\Federated_ESN_VR\Simulation_results_collection\Comparison_simulation_results\Test_OP_UL_reward_t_value_', num2str(user_num), '.mat'];
Prop_ul_reward_val = load(Prop_ul_reward_char);
Prop_ul_reward_val.reward_t_value = max(Prop_ul_reward_val.reward_t_value, 0);
% Prop_dl_reward_val.reward_t_value(find(Prop_dl_reward_val.reward_t_value <0)) = 0;
UL_pro_vs_Num_reward = [UL_pro_vs_Num_reward; Prop_ul_reward_val.reward_t_value];
end
UL_pro_vs_Num_aver_reward = mean(UL_pro_vs_Num_reward, 2);

UL_Best_vs_Num_reward = [];
user_num_collction = [8, 12, 16, 20];
for user_num = [8, 12, 16, 20]
Best_ul_reward_char = ...
    ['C:\Users\swan\PycharmProjects\Federated_ESN_VR\Simulation_results_collection\Comparison_simulation_results\Test_BEST_OP_UL_reward_t_value_', num2str(user_num), '.mat'];
Best_ul_reward_val = load(Best_ul_reward_char);
Best_ul_reward_val.reward_t_value = max(Best_ul_reward_val.reward_t_value, 0);
% Prop_dl_reward_val.reward_t_value(find(Prop_dl_reward_val.reward_t_value <0)) = 0;
UL_Best_vs_Num_reward = [UL_Best_vs_Num_reward; Best_ul_reward_val.reward_t_value];
end
UL_Best_vs_Num_aver_reward = mean(UL_Best_vs_Num_reward, 2);

UL_QL_vs_Num_reward = [];
user_num_collction = [8, 12, 16, 20];
for user_num = [8, 12, 16, 20]
QL_ul_reward_char = ...
    ['C:\Users\swan\PycharmProjects\Federated_ESN_VR\Simulation_results_collection\Comparison_simulation_results\Test_QL_OP_UL_reward_t_value_', num2str(user_num), '.mat'];
QL_ul_reward_val = load(QL_ul_reward_char);
QL_ul_reward_val.reward_t_value = max(QL_ul_reward_val.reward_t_value, 0);
% Prop_dl_reward_val.reward_t_value(find(Prop_dl_reward_val.reward_t_value <0)) = 0;
UL_QL_vs_Num_reward = [UL_QL_vs_Num_reward; QL_ul_reward_val.reward_t_value];
end
UL_QL_vs_Num_aver_reward = mean(UL_QL_vs_Num_reward, 2);

UL_OneAP_vs_Num_reward = [];
user_num_collction = [8, 12, 16, 20];
for user_num = [8, 12, 16, 20]
OneAP_ul_reward_char = ...
    ['C:\Users\swan\PycharmProjects\Federated_ESN_VR\Simulation_results_collection\Comparison_simulation_results\Test_SingAP_OP_UL_reward_t_value_', num2str(user_num), '.mat'];
OneAP_ul_reward_val = load(OneAP_ul_reward_char);
OneAP_ul_reward_val.reward_t_value = max(OneAP_ul_reward_val.reward_t_value, 0);
% Prop_dl_reward_val.reward_t_value(find(Prop_dl_reward_val.reward_t_value <0)) = 0;
UL_OneAP_vs_Num_reward = [UL_OneAP_vs_Num_reward; OneAP_ul_reward_val.reward_t_value];
end
UL_OneAP_vs_Num_aver_reward = mean(UL_OneAP_vs_Num_reward, 2);

UL_KNN_vs_Num_reward = [];
user_num_collction = [8, 12, 16, 20];
for user_num = [8, 12, 16, 20]
KNN_ul_reward_char = ...
    ['C:\Users\swan\PycharmProjects\Federated_ESN_VR\Simulation_results_collection\Comparison_simulation_results\Test_KNN_UL_reward_t_value_', num2str(user_num), '.mat'];
KNN_ul_reward_val = load(KNN_ul_reward_char);
KNN_ul_reward_val.reward_t_value = max(KNN_ul_reward_val.reward_t_value, 0);
% Prop_dl_reward_val.reward_t_value(find(Prop_dl_reward_val.reward_t_value <0)) = 0;
UL_KNN_vs_Num_reward = [UL_KNN_vs_Num_reward; KNN_ul_reward_val.reward_t_value];
end
UL_KNN_vs_Num_aver_reward = mean(UL_KNN_vs_Num_reward, 2);

UL_TMC_vs_Num_reward = [];
user_num_collction = [8, 12, 16, 20];
for user_num = [8, 12, 16, 20]
TMC_ul_reward_char = ...
    ['C:\Users\swan\PycharmProjects\Federated_ESN_VR\Simulation_results_collection\Comparison_simulation_results\Test_TMC_UL_reward_t_value_', num2str(user_num), '.mat'];
TMC_ul_reward_val = load(TMC_ul_reward_char);
TMC_ul_reward_val.reward_t_value = max(TMC_ul_reward_val.reward_t_value, 0);
% Prop_dl_reward_val.reward_t_value(find(Prop_dl_reward_val.reward_t_value <0)) = 0;
UL_TMC_vs_Num_reward = [UL_TMC_vs_Num_reward; TMC_ul_reward_val.reward_t_value];
end
UL_TMC_vs_Num_aver_reward = mean(UL_TMC_vs_Num_reward, 2);

UL_heuri_vs_Num_reward = [];
user_num_collction = [8, 12, 16, 20];
for user_num = [8, 12, 16, 20]
heuri_ul_reward_char = ...
    ['C:\Users\swan\PycharmProjects\Federated_ESN_VR\Simulation_results_collection\Comparison_simulation_results\Heuristic_uplink_reward_t_value_', num2str(user_num), '.mat'];
heuri_ul_reward_val = load(heuri_ul_reward_char);
heuri_ul_reward_val.reward_t_value = max(heuri_ul_reward_val.reward_t_value, 0);
% Prop_dl_reward_val.reward_t_value(find(Prop_dl_reward_val.reward_t_value <0)) = 0;
UL_heuri_vs_Num_reward = [UL_heuri_vs_Num_reward; heuri_ul_reward_val.reward_t_value];
end
UL_heuri_vs_Num_aver_reward = mean(UL_heuri_vs_Num_reward, 2);

% figure(13);
% plot(user_num_collction, UL_pro_vs_Num_aver_reward)
% hold on;
% plot(user_num_collction, UL_KNN_vs_Num_aver_reward)
% hold on;
% plot(user_num_collction, UL_TMC_vs_Num_aver_reward)
% hold on;
% plot(user_num_collction, UL_heuri_vs_Num_aver_reward)


% downlink results
DL_pro_vs_Num_reward = [];
user_num_collction = [8, 12, 16, 20];
for user_num = [8, 12, 16, 20]
Prop_dl_reward_char = ...
    ['C:\Users\swan\PycharmProjects\Federated_ESN_VR\Simulation_results_collection\Comparison_simulation_results\Test_OP_DL_reward_t_value_', num2str(user_num), '.mat'];
Prop_dl_reward_val = load(Prop_dl_reward_char);
Prop_dl_reward_val.reward_t_value = max(Prop_dl_reward_val.reward_t_value, 0);
% Prop_dl_reward_val.reward_t_value(find(Prop_dl_reward_val.reward_t_value <0)) = 0;
DL_pro_vs_Num_reward = [DL_pro_vs_Num_reward; Prop_dl_reward_val.reward_t_value];
end
DL_pro_vs_Num_aver_reward = mean(DL_pro_vs_Num_reward, 2);

DL_Best_vs_Num_reward = [];
user_num_collction = [8, 12, 16, 20];
for user_num = [8, 12, 16, 20]
Best_dl_reward_char = ...
    ['C:\Users\swan\PycharmProjects\Federated_ESN_VR\Simulation_results_collection\Comparison_simulation_results\Test_BEST_OP_DL_reward_t_value_', num2str(user_num), '.mat'];
Best_dl_reward_val = load(Best_dl_reward_char);
Best_dl_reward_val.reward_t_value = max(Best_dl_reward_val.reward_t_value, 0);
% Prop_dl_reward_val.reward_t_value(find(Prop_dl_reward_val.reward_t_value <0)) = 0;
DL_Best_vs_Num_reward = [DL_Best_vs_Num_reward; Best_dl_reward_val.reward_t_value];
end
DL_Best_vs_Num_aver_reward = mean(DL_Best_vs_Num_reward, 2);

DL_QL_vs_Num_reward = [];
user_num_collction = [8, 12, 16, 20];
for user_num = [8, 12, 16, 20]
QL_dl_reward_char = ...
    ['C:\Users\swan\PycharmProjects\Federated_ESN_VR\Simulation_results_collection\Comparison_simulation_results\Test_QL_OP_DL_reward_t_value_', num2str(user_num), '.mat'];
QL_dl_reward_val = load(QL_dl_reward_char);
QL_dl_reward_val.reward_t_value = max(QL_dl_reward_val.reward_t_value, 0);
% Prop_dl_reward_val.reward_t_value(find(Prop_dl_reward_val.reward_t_value <0)) = 0;
DL_QL_vs_Num_reward = [DL_QL_vs_Num_reward; QL_dl_reward_val.reward_t_value];
end
DL_QL_vs_Num_aver_reward = mean(DL_QL_vs_Num_reward, 2);

DL_OneAP_vs_Num_reward = [];
user_num_collction = [8, 12, 16, 20];
for user_num = [8, 12, 16, 20]
OneAP_dl_reward_char = ...
    ['C:\Users\swan\PycharmProjects\Federated_ESN_VR\Simulation_results_collection\Comparison_simulation_results\Test_SingAP_OP_DL_reward_t_value_', num2str(user_num), '.mat'];
OneAP_dl_reward_val = load(OneAP_dl_reward_char);
OneAP_dl_reward_val.reward_t_value = max(OneAP_dl_reward_val.reward_t_value, 0);
% Prop_dl_reward_val.reward_t_value(find(Prop_dl_reward_val.reward_t_value <0)) = 0;
DL_OneAP_vs_Num_reward = [DL_OneAP_vs_Num_reward; OneAP_dl_reward_val.reward_t_value];
end
DL_OneAP_vs_Num_aver_reward = mean(DL_OneAP_vs_Num_reward, 2);

DL_KNN_vs_Num_reward = [];
user_num_collction = [8, 12, 16, 20];
for user_num = [8, 12, 16, 20]
KNN_dl_reward_char = ...
    ['C:\Users\swan\PycharmProjects\Federated_ESN_VR\Simulation_results_collection\Comparison_simulation_results\Test_KNN_DL_reward_t_value_', num2str(user_num), '.mat'];
KNN_dl_reward_val = load(KNN_dl_reward_char);
KNN_dl_reward_val.reward_t_value = max(KNN_dl_reward_val.reward_t_value, 0);
% Prop_dl_reward_val.reward_t_value(find(Prop_dl_reward_val.reward_t_value <0)) = 0;
DL_KNN_vs_Num_reward = [DL_KNN_vs_Num_reward; KNN_dl_reward_val.reward_t_value];
end
DL_KNN_vs_Num_aver_reward = mean(DL_KNN_vs_Num_reward, 2);

DL_TMC_vs_Num_reward = [];
user_num_collction = [8, 12, 16, 20];
for user_num = [8, 12, 16, 20]
TMC_dl_reward_char = ...
    ['C:\Users\swan\PycharmProjects\Federated_ESN_VR\Simulation_results_collection\Comparison_simulation_results\Test_TMC_DL_reward_t_value_', num2str(user_num), '.mat'];
TMC_dl_reward_val = load(TMC_dl_reward_char);
TMC_dl_reward_val.reward_t_value = max(TMC_dl_reward_val.reward_t_value, 0);
% Prop_dl_reward_val.reward_t_value(find(Prop_dl_reward_val.reward_t_value <0)) = 0;
DL_TMC_vs_Num_reward = [DL_TMC_vs_Num_reward; TMC_dl_reward_val.reward_t_value];
end
DL_TMC_vs_Num_aver_reward = mean(DL_TMC_vs_Num_reward, 2);

DL_heuri_vs_Num_reward = [];
user_num_collction = [8, 12, 16, 20];
for user_num = [8, 12, 16, 20]
heuri_dl_reward_char = ...
    ['C:\Users\swan\PycharmProjects\Federated_ESN_VR\Simulation_results_collection\Comparison_simulation_results\Heuristic_downlink_reward_t_value_', num2str(user_num), '.mat'];
heuri_dl_reward_val = load(heuri_dl_reward_char);
heuri_dl_reward_val.reward_t_value = max(heuri_dl_reward_val.reward_t_value, 0);
% Prop_dl_reward_val.reward_t_value(find(Prop_dl_reward_val.reward_t_value <0)) = 0;
DL_heuri_vs_Num_reward = [DL_heuri_vs_Num_reward; heuri_dl_reward_val.reward_t_value];
end
DL_heuri_vs_Num_aver_reward = mean(DL_heuri_vs_Num_reward, 2);

% figure(14);
% plot(user_num_collction, DL_pro_vs_Num_aver_reward)
% hold on;
% plot(user_num_collction, DL_KNN_vs_Num_aver_reward)
% hold on;
% plot(user_num_collction, DL_TMC_vs_Num_aver_reward)
% hold on;
% plot(user_num_collction, DL_heuri_vs_Num_aver_reward)

figure(15);
plot(user_num_collction, UL_Best_vs_Num_aver_reward + DL_Best_vs_Num_aver_reward)
hold on;
plot(user_num_collction, UL_pro_vs_Num_aver_reward + DL_pro_vs_Num_aver_reward)
hold on;
plot(user_num_collction, UL_TMC_vs_Num_aver_reward + DL_TMC_vs_Num_aver_reward)
hold on;
plot(user_num_collction, UL_KNN_vs_Num_aver_reward + DL_KNN_vs_Num_aver_reward)
hold on;
plot(user_num_collction, UL_heuri_vs_Num_aver_reward + DL_heuri_vs_Num_aver_reward)
hold on;
plot(user_num_collction, UL_QL_vs_Num_aver_reward + DL_QL_vs_Num_aver_reward)
hold on;
plot(user_num_collction, UL_OneAP_vs_Num_aver_reward + DL_OneAP_vs_Num_aver_reward)

%% Plot users' location prediction
user_pre_location_char = 'C:/Users/swan/PycharmProjects/Federated_ESN_VR/original_data_sets/Predicted_Trajectory_10.mat';
user_pre_loc_data = load(user_pre_location_char);
pre_loc = user_pre_loc_data.predicted_trajectory';
user_true_location_char = 'C:/Users/swan/PycharmProjects/Federated_ESN_VR/original_data_sets/Pedestrian_Trajectory_Cartesian_10';
user_true_loc_data = load(user_true_location_char);
% start from the forget len + training len + 2 = 110 + 2 because there 111
% points before the starting point
true_loc = user_true_loc_data.userInterpLocations;

figure(14);
plot([true_loc(1:111, 1);pre_loc(:, 1)], [true_loc(1:111, 2); pre_loc(:, 2)]);
hold on;
plot(true_loc(:, 1), true_loc(:, 2));

predicted_location_nrmse = 'C:/Users/swan/PycharmProjects/Federated_ESN_VR/original_data_sets/NRMSE_of_Predicted_Trajectory.mat';
nrmse_loc_data = load(predicted_location_nrmse);
nrmse = nrmse_loc_data.predicted_nrmse;
figure(16);
plot(1: 16, nrmse);
t = 1;

%% The KNN-based action decision algorithm's performance self verification
% KNN_up_reward_char = 'C:\Users\swan\PycharmProjects\Federated_ESN_VR\Simulation_results_collection\KNN_UL_reward_t_value.mat';
% KNN_up_loss_char = 'C:\Users\swan\PycharmProjects\Federated_ESN_VR\Simulation_results_collection\KNN_uplink_critic_loss.mat';
% KNN_up_reward_val = load(KNN_up_reward_char);
% KNN_up_loss_val = load(KNN_up_loss_char);
% 
% KNN_dl_reward_char = 'C:\Users\swan\PycharmProjects\Federated_ESN_VR\Simulation_results_collection\KNN_DL_reward_t_value.mat';
% KNN_dl_loss_char = 'C:\Users\swan\PycharmProjects\Federated_ESN_VR\Simulation_results_collection\KNN_downlink_critic_loss.mat';
% KNN_ul_reward_val = load(KNN_dl_reward_char);
% KNN_dl_loss_val = load(KNN_dl_loss_char);


%% plot the results
% % the uplink simulation results
% figure (1);  % the obtained reward value
% % reward_plus = find(KNN_up_reward_val.reward_t_value > 0);
% average_interval = 100;
% aver_count = 0;
% aver_proposed_reward = zeros(Epoch_len-800, 1);
% aver_KNN_reward = zeros(Epoch_len-800, 1);
% for aver = 800:Epoch_len
%     aver_count = aver_count + 1;
%     aver_proposed_reward(aver_count) = mean(Prop_up_reward_val.reward_t_value(aver - average_interval : aver));
%     aver_KNN_reward(aver_count) = mean(KNN_up_reward_val.reward_t_value(aver - average_interval : aver));
% end
% plot(epoch(800:end), aver_proposed_reward);
% hold on;
% plot(epoch(800:end), aver_KNN_reward);
% 
% figure (2);  % the obtained critic loss tendency
% plot(1:length(Prop_up_loss_val.uplink_critic_loss), Prop_up_loss_val.uplink_critic_loss);
% hold on;
% plot(1:length(KNN_up_loss_val.uplink_critic_loss), KNN_up_loss_val.uplink_critic_loss);
% 
% % the downlink simulation results
% figure (3);  % the obtained reward value
% average_interval = 100;
% aver_count = 0;
% aver_dl_proposed_reward = zeros(Epoch_len-800, 1);
% aver_dl_KNN_reward = zeros(Epoch_len-800, 1);
% for aver = 800:Epoch_len
%     aver_count = aver_count + 1;
%     aver_dl_proposed_reward(aver_count) = mean(Prop_dl_reward_val.reward_t_value(aver - average_interval : aver));
%     aver_dl_KNN_reward(aver_count) = mean(KNN_ul_reward_val.reward_t_value(aver - average_interval : aver));
% end
% plot(epoch(800:end), aver_dl_proposed_reward);
% hold on;
% plot(epoch(800:end), aver_dl_KNN_reward);
% 
% figure (4);  % the obtained critic loss tendency
% plot(1:length(Prop_dl_loss_val.downlink_critic_loss), Prop_dl_loss_val.downlink_critic_loss);
% hold on;
% plot(1:length(KNN_dl_loss_val.downlink_critic_loss), KNN_dl_loss_val.downlink_critic_loss);















