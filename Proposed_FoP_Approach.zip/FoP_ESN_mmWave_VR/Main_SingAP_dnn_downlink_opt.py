"""
Implementation of DDPG - Deep Deterministic Policy Gradient
Algorithm and hyperparameter details can be found here:
    http://arxiv.org/pdf/1509.02971v2.pdf
The algorithm is tested on the Pendulum-v0 OpenAI gym task
and developed with tflearn + Tensorflow
Author: Patrick Emami
"""
import tensorflow as tf
import numpy as np
import gym
from gym import wrappers
import tflearn
import argparse
import pprint as pp
from scipy import io
import math
import matplotlib.pyplot as plt
import time
import random
import scipy.io as sio
import mosek
import sys
import copy
import operator
import os
import itertools

from replay_buffer import ReplayBuffer
from downlink_scenario import DownlinkScenario

pi = 3.1415926925
inf = 1e+9


# Define a stream printer to grab output from MOSEK
def stream_printer(text):
    sys.stdout.write(text)
    sys.stdout.flush()


def mkdir(path):
    """
    this function is used to create a path for saving results
    generated during the process of running the program !
    :param path:
    :return: True if it creates a dictionary; otherwise, False if the dictionary already exists
    """
    import os

    path = path.strip()
    path = path.rstrip("\\")

    isExists = os.path.exists(path)

    if not isExists:
        os.makedirs(path)

        print(path + ' Successfully Created!')

        return True
    else:
        print(path + ' Document has Existed!')

        return False


# ===========================
#   Uplink Actor and Critic DNNs
# ===========================

class ActorNetworkDownlink(object):
    """
    Input to the network is the state, output is the action
    under a deterministic policy.
    The output layer activation is a tanh to keep the action
    between -action_bound and action_bound
    """

    def __init__(self, sess, state_dim, action_dim, ap_number, learning_rate,
                 batch_size):
        self.sess = sess
        self.s_dim = state_dim
        self.a_dim = action_dim
        self.ap_number = ap_number
        # self.action_theta_bound = action_theta_bound
        # self.action_phi_bound = action_phi_bound
        # self.action_move_dis_bound = action_move_dis_bound
        self.learning_rate = learning_rate
        self.batch_size = batch_size

        # Actor Network
        self.inputs, self.out, = self.create_actor_network()

        self.network_params = tf.trainable_variables()

        # Network target action (a_{star})
        self.target_action = tf.placeholder(tf.float32, [None, self.a_dim])

        # Define loss and optimization Op
        self.loss = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(labels=self.target_action, logits=self.out))

        # Optimization Op
        self.optimize = tf.train.AdamOptimizer(self.learning_rate, 0.09).minimize(self.loss)

        # self.num_trainable_vars = len(
        #     self.network_params) + len(self.target_network_params)
        self.num_trainable_vars = len(
            self.network_params)

    def create_actor_network(self):
        # tflearn.input_data is used to input data to a network by creating a placeholder or use a existing holder
        # we should check whether the inputs is got from outside, i.e., s_t, or created by the DNN itself at t
        # IMO: this configuration does not accept outside input value, so it may be wrong !!!
        inputs = tflearn.input_data(shape=[None, self.s_dim])

        net = tflearn.fully_connected(inputs, 120)
        net = tflearn.layers.normalization.batch_normalization(net)
        net = tflearn.activations.relu(net)
        net = tflearn.fully_connected(net, 80)
        net = tflearn.layers.normalization.batch_normalization(net)
        net = tflearn.activations.relu(net)
        # Final layer weights are init to Uniform[-3e-3, 3e-3]
        w_init = tflearn.initializations.uniform(minval=-0.003, maxval=0.003)
        # out = tflearn.fully_connected(
        #     net, self.a_dim, activation='tanh', weights_init=w_init)
        # using sigmoid to ensure that the output is in (0, 1)
        out = tflearn.fully_connected(
            net, self.a_dim, activation='linear', weights_init=w_init)

        # Scale output to -action_bound to action_bound
        # Scale the output value
        return inputs, out

    def train(self, inputs, target_action):
        return self.sess.run([self.optimize, self.loss], feed_dict={
            self.inputs: inputs,
            self.target_action: target_action
        })

    def predict(self, inputs):
        return self.sess.run(self.out, feed_dict={
            self.inputs: inputs
        })

    # def predict_target(self, inputs):
    #     return self.sess.run(self.target_scaled_out, feed_dict={
    #         self.target_inputs: inputs
    #     })

    # def update_target_network(self):
    #     self.sess.run(self.update_target_network_params)

    def get_num_trainable_vars(self):
        return self.num_trainable_vars


# Taken from https://github.com/openai/baselines/blob/master/baselines/ddpg/noise.py, which is
# based on http://math.stackexchange.com/questions/1287634/implementing-ornstein-uhlenbeck-in-matlab
class OrnsteinUhlenbeckActionNoise:
    def __init__(self, mu, sigma=0.3, theta=.15, dt=1e-2, x0=None):
        self.theta = theta
        self.mu = mu
        self.sigma = sigma
        self.dt = dt
        self.x0 = x0
        self.reset()

    def __call__(self):
        x = self.x_prev + self.theta * (self.mu - self.x_prev) * self.dt + \
            self.sigma * np.sqrt(self.dt) * np.random.normal(size=self.mu.shape)
        self.x_prev = x
        return x

    def reset(self):
        self.x_prev = self.x0 if self.x0 is not None else np.zeros_like(self.mu)

    def __repr__(self):
        return 'OrnsteinUhlenbeckActionNoise(mu={}, sigma={})'.format(self.mu, self.sigma)


# ===========================
#   Tensorflow Summary Ops
# ===========================

def build_summaries():
    episode_reward = tf.Variable(0.)
    tf.summary.scalar("Reward", episode_reward)
    episode_ave_max_q = tf.Variable(0.)
    tf.summary.scalar("Qmax Value", episode_ave_max_q)

    summary_vars = [episode_reward, episode_ave_max_q]
    summary_ops = tf.summary.merge_all()

    return summary_ops, summary_vars


# ===========================
#   Agent Training
# ===========================

def train_downlink(sess, env_task, args, actor, path, ap_location, user_location_collection, seq_len_min_index,
                   user_height, mode):
    # Set up summary Ops
    summary_ops, summary_vars = build_summaries()
    # create a folder
    if mode is 'OP':
        path = path + '/OP_SingAP_DNN_DL_training_' + str(int(args['user_number']))
        mkdir(path)
    elif mode is 'KNN':
        path = path + '/KNN_SingAP_DNN_DL_training_' + str(int(args['user_number']))
        mkdir(path)
    else:
        print('The mode must be OP or KNN!')

    # saver = tf.train.Saver(max_to_keep=int(args['max_episodes']))
    saver = tf.train.Saver(max_to_keep=1)  # the maximum number of recent checkpoints to save is 1
    # LOAD = True
    LOAD = False
    if LOAD:
        saver.restore(sess, tf.train.latest_checkpoint(''))
    else:
        sess.run(tf.global_variables_initializer())

    writer = tf.summary.FileWriter(args['summary_dir'], sess.graph)

    # Initialize replay memory
    replay_buffer = ReplayBuffer(int(args['buffer_size']), int(args['random_seed']))

    # Initialize the downlink scenario
    downlink_scenario = DownlinkScenario(env_task, float(args['ap_power']),
                                         float(args['noise_power']),
                                         float(args['downlink_bandwidth']),
                                         int(args['ap_number']),
                                         int(args['antenna_number']),
                                         float(args['downlink_QoS']),
                                         float(args['ap_circuit_power']),
                                         float(args['eta_LoS']),
                                         float(args['eta_NLoS']),
                                         float(args['sigma_LoS']),
                                         float(args['sigma_NLoS']),
                                         np.int32(args['light_speed']),
                                         np.int64(args['carrier_frequency']),
                                         int(args['user_number']),
                                         float(args['find_neighbor_dist']),
                                         float(args['vartheta']),
                                         float(args['small_gain']),
                                         float(args['great_gain']),
                                         float(args['theta']),
                                         float(args['phi']),
                                         float(args['ap_height']),
                                         user_height)

    # obtain a user's location
    user_location = []
    for num_user in range(int(args['user_number'])):
        user_i_loc = user_location_collection[num_user]  # a 2-array in R^{T * 2}
        # get the user location at time slot t = 10
        user_location.append(user_i_loc[:, 0].tolist())

    user_location = np.array(user_location)  # all users' locations at t = 1
    ref_center_location = np.array([[float(args['ref_loc_x']), float(args['ref_loc_y']), 0]])
    past_user_location = np.zeros((int(args['user_number']), 2))
    # user_location = np.array([[0, 0], [150, 150], [600, 200], [300, 360]])
    # ap_location = np.array([[100.0, 200.0], [400.0, 600.0], [330.0, 460.0]])  # it is a list

    # obtain the antenna_gain
    # service_ability = np.ones((int(args['ap_number']),)) * int(args['ap_downlink_serving_users'])
    # # obtain the h_matrix in R^{num_antenna, num_antenna * num_user * num_ap}
    # # h_matrix, h_nlos_matrix = uplink_scenario.calculate_path_loss(user_location, ap_location)
    # distance_ij_matrix = np.zeros((int(args['user_number']), int(args['ap_number'])))

    initial_forgotten_len = 0
    downlink_critic_loss = []
    reward_train_interval_collection = []
    reward_t_collection = []
    past_reward = 1.0
    t_count = 0
    former_user_location = np.zeros((int(args['user_number']), 2))
    train_count = 0
    total_time = time.time()
    for i in range(int(args['max_episodes'])):
        # ==========================
        #    S     initialize  state 1;  it is an one-dimensional array | 1-d array
        # ==========================
        s_dim = int(args['ap_number']) + int(args['user_number']) * (int(args['user_number'])) + \
                2 * int(args['user_number']) * (int(args['ap_number'])) * int(args['antenna_number'])
        state = np.zeros((s_dim,)) + 0.0001
        ap_offset = int(args['ap_number'])
        interfer_offset = int(args['user_number']) * int(args['user_number'])
        channelgain_offset = int(args['user_number']) * (int(args['ap_number'])) * int(args['antenna_number'])
        state[ap_offset + np.random.randint(0, interfer_offset-1, int(interfer_offset/2))] = 1

        for ap_index in range(int(args['ap_number'])):
            state[ap_index] = 1
        _, h_ijkt_collection = downlink_scenario.calculate_path_loss(user_location, past_user_location, ap_location,
                                                                  ref_center_location, user_height,
                                                                  float(args['ap_height']))
        for i_user_index in range(int(args['user_number'])):
            h_ijkt = h_ijkt_collection[i_user_index]
            h_ijkt -= h_ijkt.mean()
            assert h_ijkt.std() > 0
            h_ijkt /= h_ijkt.std()
            s_index = ap_offset + interfer_offset + i_user_index * int(args['ap_number']) * int(args['antenna_number'])
            state[range(s_index, s_index + int(args['ap_number']) * int(args['antenna_number']))] = h_ijkt
        for i_user_index in range(int(args['user_number'])):
            g_ijkt = np.random.rand(int(args['ap_number']) * int(args['antenna_number'])) * 10
            g_ijkt -= g_ijkt.mean()
            assert g_ijkt.std() > 0
            g_ijkt /= (g_ijkt.std()+0.0001)
            s_index = ap_offset + interfer_offset + channelgain_offset + \
                      i_user_index * int(args['ap_number']) * int(args['antenna_number'])
            state[range(s_index, s_index + int(args['ap_number']) * int(args['antenna_number']))] = g_ijkt

        ep_reward = 0
        ep_ave_max_q = 0
        epsilon = 0.9995

        ep_time = time.time()

        # # initialize the data structure for training, save in row format
        # state_s2 = np.zeros((int(args['ap_number']) + int(args['user_number']) * int(args['ap_number']) + 1,))

        for j in range(int(args['max_episode_len'])):
            # update the users' locations every x times
            if int(train_count % int(np.ceil(int(args['max_episode_len']) * int(args['max_episodes']) /
                                             len(user_location_collection[seq_len_min_index][:, 0])))) == 0:
                # obtain a user's location
                user_location = []
                for num_user in range(int(args['user_number'])):
                    user_i_loc = user_location_collection[num_user]  # a 2-array in R^{T * 2}
                    # get the user location at time slot t = 10
                    user_location.append(user_i_loc[:, t_count].tolist())
                user_location = np.array(user_location)  # all users' locations

                # obtain the past user locations
                if not t_count:
                    past_user_location = np.zeros((int(args['user_number']), 2))
                else:
                    past_user_location = former_user_location

                # user_location = np.array([[0, 0], [150, 150], [600, 200], [300, 360]])
                # ap_location = np.array([[100.0, 200.0], [400.0, 600.0], [330.0, 460.0]])  # it is a list

                # obtain the antenna_gain
                # antenna_gain = np.ones((int(args['user_number']), int(args['ap_number'])))
                # service_ability = np.ones((int(args['ap_number']),)) * int(args['ap_downlink_serving_users'])
                # obtain the h_matrix in R^{num_antenna, num_antenna * num_user * num_ap}
                # h_matrix, h_nlos_matrix = uplink_scenario.calculate_path_loss(user_location, ap_location)
                distance_ij_matrix = np.zeros((int(args['user_number']), int(args['ap_number'])))
                for user_index in range(int(args['user_number'])):
                    for ap_index in range(int(args['ap_number'])):
                        distance_ij_matrix[user_index][ap_index] = \
                            downlink_scenario.dis_calculate_ij(user_index, ap_index, user_location, ap_location,
                                                               user_height, float(args['ap_height']))
                t_count += 1

            # save the user location at time slot t-1
            former_user_location = copy.deepcopy(user_location)
            
            # initialize the data structure for training, save in row format
            state_s2 = np.zeros((s_dim,)) + 0.0001
            # if args['render_env']:
            #     env.render()

            # ========================
            #           state 2
            # ========================
            # Calculate the sample action a = \mu(s|\theta^{\mu}), add exploration noise by using the EE scheme
            # a_ori = actor.predict(np.reshape(state, (1, actor.s_dim))) + actor_noise()
            actor_ori_noise = np.random.normal(0, 0.6, int(args['user_number']))
            a_ori = actor.predict(np.reshape(state, (1, actor.s_dim))) + np.power(epsilon, j) * actor_ori_noise
            # a_ori = np.clip(a_ori, 0, 1)

            a_collection = []  # list, R^{i <= a_base_len}, each element is a 2d array
            a_base_collection = []  # it includes the objective function value of each candidate action by summing a row

            # Quantize the original action to K <= N action vectors, 2-d array, R^{user_number, ap_number}
            a_ori_2array = np.array(a_ori).reshape((int(args['user_number']), 1))

            # step one: order the original action
            a_ori_user = np.max(a_ori_2array, 1)  # 1-d array, R^{user_number}, the maximum action

            # as the element in a_ori_user may be negative (-M, M), we should conduct the abs
            a_base_ascend_index = np.argsort(np.abs(a_ori_user))
            assert len(a_base_ascend_index) == int(args['user_number']), \
                "The utilization of the list operator is wrong!"

            # a_base_ascend_1 = [x for x in a_base_ascend.tolist() if 1 > x > 0]  # list, R^{i < user_number}
            a_base_len = len(a_base_ascend_index)
            a_intermed_collection_2array = np.ones((int(args['user_number']), int(args['user_number'])))

            cons_violation = True  # an indicator indicates whether the constraint is violated
            feasible = False

            # # # # # # ----  Case I:  -----  # # # # # # #
            # Two methods of generating the candidate actions
            if mode is 'OP':
                # obtain all the reference base actions
                # step two: generate the 1st candidate action
                # set the reference base be 0.5; as sigmoid(0) = 0.5, and we did not activate the output with sigmoid
                a_base_collection.append(1 * (a_ori_user > 0))
                if int(args['user_number']) > 1:
                    # step three: generate other candidate actions
                    idx_list = a_base_ascend_index[:int(args['user_number']) - 1]
                    for base_index in range(int(args['user_number']) - 1):
                        if a_ori_user[idx_list[base_index]] > 0:
                            # set a positive user to 0
                            a_base_collection.append(1 * (a_ori_user - a_ori_user[idx_list[base_index]] > 0))
                        else:
                            # set a negtive user to 1
                            a_base_collection.append(1 * (a_ori_user - a_ori_user[idx_list[base_index]] >= 0))
                    a_intermed_collection_2array = np.array(a_base_collection)
                    # for i_index in range(int(args['user_number'])):
                    #     # change the reference base
                    #     if a_ori_user[i_index] > a_base_ascend_1[len_base - 1]:
                    #         a_base_collection.append(1)
                    #     else:
                    #         a_base_collection.append(0)
            elif mode is 'KNN':
                # list all 2^N binary offloading actions
                enumerate_actions = np.array(
                    list(map(list, itertools.product([0, 1], repeat=int(args['user_number'])))))

                # the 2-norm
                sqd = ((enumerate_actions - a_ori_user) ** 2).sum(1)
                idx = np.argsort(sqd)
                a_intermed_collection_2array = enumerate_actions[idx[:int(args['user_number'])]]
            else:
                print("The action selection must be 'OP' or 'KNN'")

            # for len_base in range(a_base_len):

            # recover the quantized action set according to the ref base actions

            # a_intermed_collection_2array, all intermediate candidate actions, 2d array,R^{a_base_len, user_number}
            # a_intermed_collection_2array = np.array(a_base_collection).reshape((a_base_len, int(args['user_number'])))

            for a_base_len_index in range(a_base_len):
                immed_action = copy.deepcopy(a_ori_2array)  # 2d array, R^{user_number, ap_number}
                for user_index in range(int(args['user_number'])):
                    immed_action[user_index] = np.zeros((1, ))
                    if a_intermed_collection_2array[a_base_len_index][user_index] == 1:
                        # obtain the index of the maximum value in a[i]
                        max_index, max_value = max(enumerate(a_ori_2array[user_index].tolist()),
                                                   key=operator.itemgetter(1))
                        immed_action[user_index][max_index] = 1
                # collect the candidate actions, the length is a_base_len
                a_collection.append(immed_action)  # list, R^{a_base_len}, each element is a 2d array

            # copy the a_collection
            a_collection_copy = copy.deepcopy(a_collection)

            # choose the best one action from all candidate actions
            reward_dl_collection = np.ones((a_base_len,)) * (-inf)
            power_matrix_collection = []
            for a_base_len_index in range(a_base_len):
                action_check = a_collection[a_base_len_index]

                # check the feasibility of the final obtained action a
                power_matrix_collection_final, pro_feasibility_final = \
                    downlink_scenario.downlink_optimization(action_check, user_location, past_user_location,
                                                            ap_location, ref_center_location, user_height,
                                                            float(args['ap_height']))
                if pro_feasibility_final:
                    reward_dl_collection[a_base_len_index] = float(args['tradeoff_coefficient_v']) / \
                                                             int(args['user_number']) * \
                                                             int(np.sum(np.max(action_check, 1)))
                power_matrix_collection.append(power_matrix_collection_final)

            # # # # # # #  Choose one action from the action set
            # # # ---------------------   find the action such that the reward is minimized
            max_index_dl, max_value_dl = max(enumerate(reward_dl_collection), key=operator.itemgetter(1))
            pro_feasibility_final = False
            if max_value_dl != -inf:
                pro_feasibility_final = True

            # obtain the best action
            a_dl = a_collection_copy[max_index_dl]
            # power_matrix_collection_dl is a list with each element being a 2d array
            power_matrix_collection_dl = power_matrix_collection[max_index_dl]

            if pro_feasibility_final:
                feasible = True
            else:
                feasible = False

            # obtain the corresponding state s_{t+1} given the generated action a_{t}
            # step one (1):
            for state_index in range(int(args['ap_number'])):
                # we divide by int(args['user_number']) to make the value in s_2 be close to 1 for better learning,
                # which is widely applied in mechine learning
                state_s2[state_index] = int(np.sum(a_dl)) / int(args['ap_number'])

            # step two (2):
            ap_offset = int(args['ap_number'])
            # here, check whether user m is the interfering node of user i
            i_user_neighbor_collection = []
            for i_user_index in range(int(args['user_number'])):
                i_user_neighbor = downlink_scenario.neighbor_finding(i_user_index,
                                                                     a_dl.reshape((int(args['user_number']))),
                                                                     user_location)
                i_user_neighbor_collection.append(i_user_neighbor)  # a list including multiple 1-d array
                if i_user_neighbor.size > 1:
                    for inter_index in range(i_user_neighbor.size-1):
                        s2_index = ap_offset + i_user_index * int(args['user_number']) + \
                                   i_user_neighbor[inter_index + 1]
                        state_s2[s2_index] = 1

            # step three (3):
            interfer_offset = ap_offset + int(args['user_number']) * int(args['user_number'])
            _, h_ijkt_collection = downlink_scenario.calculate_path_loss(user_location, past_user_location, ap_location,
                                                                      ref_center_location, user_height,
                                                                      float(args['ap_height']))
            for i_user_index in range(int(args['user_number'])):
                h_ijkt = h_ijkt_collection[i_user_index]
                h_ijkt -= h_ijkt.mean()
                assert h_ijkt.std() > 0
                h_ijkt /= h_ijkt.std()
                s2_index = interfer_offset + i_user_index * int(args['ap_number']) * int(args['antenna_number'])
                state_s2[range(s2_index, s2_index + int(args['ap_number']) * int(args['antenna_number']))] = h_ijkt

            # step four (4):
            channelgain_offset = interfer_offset + int(args['user_number']) * int(args['ap_number']) * \
                                 int(args['antenna_number'])
            rnd_num = 1
            for i_user_index in range(int(args['user_number'])):
                if not a_dl[i_user_index][0]:
                    # Method 1: equal to the setting of rnd_num = 1
                    eig_val, eig_matrix = np.linalg.eig(power_matrix_collection_dl[i_user_index])
                    # Method 2: modify the power_matrix if rank(Power_matrix) > 1
                    # eig_val, eig_matrix = \
                    #     downlink_scenario.modify_power_matrix(power_matrix_collection_dl, i_user_index, rnd_num,
                    #                                           user_location, a_dl, past_user_location,
                    #                                         ap_location, ref_center_location, user_height,
                    #                                         float(args['ap_height']))

                    max_eig_indices, max_val = max(enumerate(eig_val.tolist()), key=operator.itemgetter(1))
                    eig_vec = eig_matrix[:, max_eig_indices]
                    s2_index = channelgain_offset + i_user_index * int(args['ap_number']) * int(args['antenna_number'])
                    eig_vec -= eig_vec.mean()
                    assert eig_vec.std() > 0
                    eig_vec /= eig_vec.std()
                    state_s2[range(s2_index, s2_index+int(args['ap_number']) * int(args['antenna_number']))] = eig_vec

            if feasible: #and not qos_violate_count:
                if max_value_dl != -inf:
                    r = max_value_dl
                else:
                    r = 0
            else:
                r = past_reward - 10 * np.abs(past_reward)
                # if max_value_dl != -inf:
                #     r = max_value_dl - 10 * np.abs(max_value_dl)
                # else:
                #     r = -10
            past_reward = r
            print("r[" + str(train_count) + "]=" + str(r))

            # s2, r, terminal, info = env.step(a[0])
            initial_forgotten_len = initial_forgotten_len + 1
            if initial_forgotten_len > int(args['forgot_len']):
                replay_buffer.add(np.reshape(state, (actor.s_dim,)), np.reshape(a_dl, (actor.a_dim,)), r,
                                  np.reshape(state_s2, (actor.s_dim,)))

            # Keep adding experience to the memory until
            # there are at least minibatch size samples
            if replay_buffer.size() > int(args['minibatch_size']):
                s_batch, a_batch, r_batch, s2_batch = \
                    replay_buffer.sample_batch(int(args['minibatch_size']))

                Q_i = []
                for k in range(int(args['minibatch_size'])):
                    Q_i.append(r_batch[k])
                opt_out_batch = np.reshape(Q_i, (int(args['minibatch_size']), 1))

                ep_ave_max_q += np.amax(opt_out_batch)

                # Update the actor policy using the sampled gradient
                if replay_buffer.size() % int(args['training_interval']) == 0:
                    # train the actor network
                    _, dl_critic_loss_value = actor.train(s_batch, a_batch)
                    # save the loss value
                    downlink_critic_loss.append(dl_critic_loss_value)
                    # save the reward
                    reward_train_interval_collection.append(r)
                    print('| Epoch: {:d} | The training loss is: {:.4f}'.format(j, dl_critic_loss_value))

            state = state_s2
            ep_reward += r
            train_count += 1
            reward_t_collection.append(r)

        # statistical results collection after one episode
        summary_str = sess.run(summary_ops, feed_dict={
            summary_vars[0]: ep_reward,
            summary_vars[1]: ep_ave_max_q /
                             (float(args['max_episode_len']) - int(args['forgot_len']) - int(args['minibatch_size']))
        })

        writer.add_summary(summary_str, i)
        writer.flush()

        print('| Reward: {:d} | Episode: {:d} | Cost time this epoch: {:.4f} seconds'.format(int(ep_reward), i,
                                                                                             time.time() - ep_time))

        # save the trained model, i.e., sess parameters in each episode
        dl_save_path = saver.save(sess, path + '/SingAP_DL_DNN_model_' + 'downlink_UserNum_' + str(int(args['user_number'])) +
                                  '_' + str(i) + '.ckpt', write_meta_graph=False)
        print('Model:' + dl_save_path)

    # plot the loss value of the critic network
    # plt.figure(1)
    # plt.plot(downlink_critic_loss)
    # plt.show()
    # plt.figure(2)
    # plt.plot(reward_train_interval_collection)
    # plt.show()
    # plt.figure(3)
    # plt.plot(reward_t_collection)
    # plt.show()
    # pass
    print('Cost time of the training process: {:.4f} seconds'.format(time.time() - total_time))
    if mode is 'OP':
        file_name = 'SingAP_OP_downlink_critic_loss_' + str(int(args['user_number'])) + '.mat'
        io.savemat(file_name, {'downlink_critic_loss': downlink_critic_loss})
        file_name = 'SingAP_OP_DL_reward_interval_value_' + str(int(args['user_number'])) + '.mat'
        io.savemat(file_name, {'reward_interval_value': reward_train_interval_collection})
        file_name = 'SingAP_OP_DL_reward_t_value_' + str(int(args['user_number'])) + '.mat'
        io.savemat(file_name, {'reward_t_value': reward_t_collection})
    elif mode is 'KNN':
        file_name = 'SingAP_KNN_downlink_critic_loss_' + str(int(args['user_number'])) + '.mat'
        io.savemat(file_name, {'downlink_critic_loss': downlink_critic_loss})
        file_name = 'SingAP_KNN_DL_reward_interval_value_' + str(int(args['user_number'])) + '.mat'
        io.savemat(file_name, {'reward_interval_value': reward_train_interval_collection})
        file_name = 'SingAP_KNN_DL_reward_t_value_' + str(int(args['user_number'])) + '.mat'
        io.savemat(file_name, {'reward_t_value': reward_t_collection})
    else:
        print('The mode must be OP or KNN, the results are not saved!')

# ===========================
#   Agent Testing
# ===========================


def test_downlink(sess, env_task, args, actor, path, ap_location, user_location_collection, seq_len_min_index,
                  user_height, mode):
    # create a folder
    if mode is 'OP':
        path = path + '/OP_SingAP_DNN_DL_training_' + str(int(args['user_number']))
        mkdir(path)
    elif mode is 'KNN':
        path = path + '/KNN_SingAP_DNN_DL_training_' + str(int(args['user_number']))
        mkdir(path)
    else:
        print('The mode must be OP or KNN!')

    saver = tf.train.Saver()
    # as the actor network is initialized, we can restore the network parameters
    restore_dir = path + '/DNN_trained_para_ckpt'
    # saver.restore(sess, tf.train.latest_checkpoint(restore_dir))
    # if not os.path.exists(path + '/DL_DNN_model' + 'downlink_' + str(i) + '.ckpt.index'):
    #     continue
    saver.restore(sess, path + '/SingAP_DL_DNN_model_' + 'downlink_UserNum_' + str(int(args['user_number'])) + '_' +
                  str(int(int(args['max_episodes'])-1)) + '.ckpt')

    # Initialize the downlink scenario
    downlink_scenario = DownlinkScenario(env_task, float(args['ap_power']),
                                         float(args['noise_power']),
                                         float(args['downlink_bandwidth']),
                                         int(args['ap_number']),
                                         int(args['antenna_number']),
                                         float(args['downlink_QoS']),
                                         float(args['ap_circuit_power']),
                                         float(args['eta_LoS']),
                                         float(args['eta_NLoS']),
                                         float(args['sigma_LoS']),
                                         float(args['sigma_NLoS']),
                                         np.int32(args['light_speed']),
                                         np.int64(args['carrier_frequency']),
                                         int(args['user_number']),
                                         float(args['find_neighbor_dist']),
                                         float(args['vartheta']),
                                         float(args['small_gain']),
                                         float(args['great_gain']),
                                         float(args['theta']),
                                         float(args['phi']),
                                         float(args['ap_height']),
                                         user_height)

    epoch_time = time.time()

    # obtain a user's location
    user_location = []
    for num_user in range(int(args['user_number'])):
        user_i_loc = user_location_collection[num_user]  # a 2-array in R^{T * 2}
        # get the user location at time slot t = 10
        user_location.append(user_i_loc[:, 0].tolist())
    user_location = np.array(user_location)  # all users' locations

    user_location = np.array(user_location)  # all users' locations at t = 1
    ref_center_location = np.array([[float(args['ref_loc_x']), float(args['ref_loc_y']), 0]])
    past_user_location = np.zeros((int(args['user_number']), 2))

    # ==========================
    #       initialize  state;  it is an one-dimensional array | 1-d array
    # ==========================
    s_dim = int(args['ap_number']) + int(args['user_number']) * (int(args['user_number'])) + \
            2 * int(args['user_number']) * (int(args['ap_number'])) * int(args['antenna_number'])
    state = np.zeros((s_dim,)) + 0.0001
    ap_offset = int(args['ap_number'])
    interfer_offset = int(args['user_number']) * int(args['user_number'])
    channelgain_offset = int(args['user_number']) * (int(args['ap_number'])) * int(args['antenna_number'])
    state[ap_offset + np.random.randint(0, interfer_offset - 1, int(interfer_offset / 2))] = 1

    for ap_index in range(int(args['ap_number'])):
        state[ap_index] = 1
    _, h_ijkt_collection = downlink_scenario.calculate_path_loss(user_location, past_user_location, ap_location,
                                                                 ref_center_location, user_height,
                                                                 float(args['ap_height']))
    for i_user_index in range(int(args['user_number'])):
        h_ijkt = h_ijkt_collection[i_user_index]
        h_ijkt -= h_ijkt.mean()
        assert h_ijkt.std() > 0
        h_ijkt /= h_ijkt.std()
        s_index = ap_offset + interfer_offset + i_user_index * int(args['ap_number']) * int(args['antenna_number'])
        state[range(s_index, s_index + int(args['ap_number']) * int(args['antenna_number']))] = h_ijkt
    for i_user_index in range(int(args['user_number'])):
        g_ijkt = np.random.rand(int(args['ap_number']) * int(args['antenna_number'])) * 10
        g_ijkt -= g_ijkt.mean()
        assert g_ijkt.std() > 0
        g_ijkt /= (g_ijkt.std() + 0.0001)
        s_index = ap_offset + interfer_offset + channelgain_offset + \
                  i_user_index * int(args['ap_number']) * int(args['antenna_number'])
        state[range(s_index, s_index + int(args['ap_number']) * int(args['antenna_number']))] = g_ijkt

    ep_reward = 0

    # # initialize the data structure for training, save in row format
    # state_s2 = np.zeros((int(args['ap_number']) + int(args['user_number']) * int(args['ap_number']) + 1,))
    t_count = 0
    accumulated_ep_reward = []
    reward_real_time = []
    past_reward = 1.0
    former_user_location = np.zeros((int(args['user_number']), 2))
    train_count = 0
    for j in range(int(args['max_episode_len_test'])):
        # update the users' locations every x times
        if int(train_count % int(np.ceil(int(args['max_episode_len_test']) /
                                         len(user_location_collection[seq_len_min_index][0, :])))) == 0:
            # obtain a user's location
            user_location = []
            for num_user in range(int(args['user_number'])):
                user_i_loc = user_location_collection[num_user]  # a 2-array in R^{T * 2}
                # get the user location at time slot t = 10
                user_location.append(user_i_loc[:, t_count].tolist())
            user_location = np.array(user_location)  # all users' locations

            # obtain the past user locations
            if not t_count:
                past_user_location = np.zeros((int(args['user_number']), 2))
            else:
                past_user_location = former_user_location

            # user_location = np.array([[0, 0], [150, 150], [600, 200], [300, 360]])
            # ap_location = np.array([[100.0, 200.0], [400.0, 600.0], [330.0, 460.0]])  # it is a list

            # obtain the antenna_gain
            # antenna_gain = np.ones((int(args['user_number']), int(args['ap_number'])))
            # service_ability = np.ones((int(args['ap_number']),)) * int(args['ap_downlink_serving_users'])
            # obtain the h_matrix in R^{num_antenna, num_antenna * num_user * num_ap}
            # h_matrix, h_nlos_matrix = uplink_scenario.calculate_path_loss(user_location, ap_location)
            distance_ij_matrix = np.zeros((int(args['user_number']), int(args['ap_number'])))
            for user_index in range(int(args['user_number'])):
                for ap_index in range(int(args['ap_number'])):
                    distance_ij_matrix[user_index][ap_index] = \
                        downlink_scenario.dis_calculate_ij(user_index, ap_index, user_location, ap_location,
                                                           user_height, float(args['ap_height']))
            t_count += 1

        # save the user location at time slot t-1
        former_user_location = copy.deepcopy(user_location)

        # initialize the data structure for training, save in row format
        state_s2 = np.zeros((s_dim,)) + 0.0001
        # if args['render_env']:
        #     env.render()

        # ========================
        #           state 2
        # ========================
        # Calculate the sample action a = \mu(s|\theta^{\mu}), add exploration noise by using the EE scheme
        a_ori = actor.predict(np.reshape(state, (1, actor.s_dim)))

        a_collection = []  # list, R^{i <= a_base_len}, each element is a 2d array
        a_base_collection = []  # it includes the objective function value of each candidate action by summing a row

        # Quantize the original action to K <= N action vectors, 2-d array, R^{user_number, ap_number}
        a_ori_2array = np.array(a_ori).reshape((int(args['user_number']), 1))

        # step one: order the original action
        a_ori_user = np.max(a_ori_2array, 1)  # 1-d array, R^{user_number}, the maximum action

        # as the element in a_ori_user may be negative (-M, M), we should conduct the abs
        a_base_ascend_index = np.argsort(np.abs(a_ori_user))
        assert len(a_base_ascend_index) == int(args['user_number']), \
            "The utilization of the list operator is wrong!"

        # a_base_ascend_1 = [x for x in a_base_ascend.tolist() if 1 > x > 0]  # list, R^{i < user_number}
        a_base_len = len(a_base_ascend_index)
        a_intermed_collection_2array = np.ones((int(args['user_number']), int(args['user_number'])))

        cons_violation = True  # an indicator indicates whether the constraint is violated
        feasible = False

        # # # # # # ----  Case I:  -----  # # # # # # #
        # Two methods of generating the candidate actions
        if mode is 'OP':
            # obtain all the reference base actions
            # step two: generate the 1st candidate action
            # set the reference base be 0.5; as sigmoid(0) = 0.5, and we did not activate the output with sigmoid
            a_base_collection.append(1 * (a_ori_user > 0))
            if int(args['user_number']) > 1:
                # step three: generate other candidate actions
                idx_list = a_base_ascend_index[:int(args['user_number']) - 1]
                for base_index in range(int(args['user_number']) - 1):
                    if a_ori_user[idx_list[base_index]] > 0:
                        # set a positive user to 0
                        a_base_collection.append(1 * (a_ori_user - a_ori_user[idx_list[base_index]] > 0))
                    else:
                        # set a negtive user to 1
                        a_base_collection.append(1 * (a_ori_user - a_ori_user[idx_list[base_index]] >= 0))
                a_intermed_collection_2array = np.array(a_base_collection)
                # for i_index in range(int(args['user_number'])):
                #     # change the reference base
                #     if a_ori_user[i_index] > a_base_ascend_1[len_base - 1]:
                #         a_base_collection.append(1)
                #     else:
                #         a_base_collection.append(0)
        elif mode is 'KNN':
            # list all 2^N binary offloading actions
            enumerate_actions = np.array(
                list(map(list, itertools.product([0, 1], repeat=int(args['user_number'])))))

            # the 2-norm
            sqd = ((enumerate_actions - a_ori_user) ** 2).sum(1)
            idx = np.argsort(sqd)
            a_intermed_collection_2array = enumerate_actions[idx[:int(args['user_number'])]]
        else:
            print("The action selection must be 'OP' or 'KNN'")

        # for len_base in range(a_base_len):

        # recover the quantized action set according to the ref base actions

        # a_intermed_collection_2array, all intermediate candidate actions, 2d array,R^{a_base_len, user_number}
        # a_intermed_collection_2array = np.array(a_base_collection).reshape((a_base_len, int(args['user_number'])))

        for a_base_len_index in range(a_base_len):
            immed_action = copy.deepcopy(a_ori_2array)  # 2d array, R^{user_number, ap_number}
            for user_index in range(int(args['user_number'])):
                immed_action[user_index] = np.zeros((1,))
                if a_intermed_collection_2array[a_base_len_index][user_index] == 1:
                    # obtain the index of the maximum value in a[i]
                    max_index, max_value = max(enumerate(a_ori_2array[user_index].tolist()),
                                               key=operator.itemgetter(1))
                    immed_action[user_index][max_index] = 1
            # collect the candidate actions, the length is a_base_len
            a_collection.append(immed_action)  # list, R^{a_base_len}, each element is a 2d array

        # copy the a_collection
        a_collection_copy = copy.deepcopy(a_collection)

        # choose the best one action from all candidate actions
        reward_dl_collection = np.ones((a_base_len,)) * (-inf)
        power_matrix_collection = []
        for a_base_len_index in range(a_base_len):
            action_check = a_collection[a_base_len_index]

            # check the feasibility of the final obtained action a
            power_matrix_collection_final, pro_feasibility_final = \
                downlink_scenario.downlink_optimization(action_check, user_location, past_user_location,
                                                        ap_location, ref_center_location, user_height,
                                                        float(args['ap_height']))
            if pro_feasibility_final:
                reward_dl_collection[a_base_len_index] = float(args['tradeoff_coefficient_v']) / \
                                                         int(args['user_number']) * \
                                                         int(np.sum(np.max(action_check, 1)))
            power_matrix_collection.append(power_matrix_collection_final)

        # # # # # # #  Choose one action from the action set
        # # # ---------------------   find the action such that the reward is minimized
        max_index_dl, max_value_dl = max(enumerate(reward_dl_collection), key=operator.itemgetter(1))
        pro_feasibility_final = False
        if max_value_dl != -inf:
            pro_feasibility_final = True

        # obtain the best action
        a_dl = a_collection_copy[max_index_dl]
        power_matrix_collection_dl = power_matrix_collection[max_index_dl]

        if pro_feasibility_final:
            feasible = True
        else:
            feasible = False

        # obtain the corresponding state s_{t+1} given the generated action a_{t}
        # step one (1):
        for state_index in range(int(args['ap_number'])):
            # we divide by int(args['user_number']) to make the value in s_2 be close to 1 for better learning,
            # which is widely applied in mechine learning
            state_s2[state_index] = int(np.sum(a_dl)) / int(args['ap_number'])

        # step two (2):
        ap_offset = int(args['ap_number'])
        # here, check whether user m is the interfering node of user i
        i_user_neighbor_collection = []
        for i_user_index in range(int(args['user_number'])):
            i_user_neighbor = downlink_scenario.neighbor_finding(i_user_index,
                                                                 a_dl.reshape((int(args['user_number']))),
                                                                 user_location)
            i_user_neighbor_collection.append(i_user_neighbor)  # a list including multiple 1-d array
            if i_user_neighbor.size > 1:
                for inter_index in range(i_user_neighbor.size - 1):
                    s2_index = ap_offset + i_user_index * int(args['user_number']) + \
                               i_user_neighbor[inter_index + 1]
                    state_s2[s2_index] = 1

        # step three (3):
        interfer_offset = ap_offset + int(args['user_number']) * int(args['user_number'])
        _, h_ijkt_collection = downlink_scenario.calculate_path_loss(user_location, past_user_location, ap_location,
                                                                     ref_center_location, user_height,
                                                                     float(args['ap_height']))
        for i_user_index in range(int(args['user_number'])):
            h_ijkt = h_ijkt_collection[i_user_index]
            h_ijkt -= h_ijkt.mean()
            assert h_ijkt.std() > 0
            h_ijkt /= h_ijkt.std()
            s2_index = interfer_offset + i_user_index * int(args['ap_number']) * int(args['antenna_number'])
            state_s2[range(s2_index, s2_index + int(args['ap_number']) * int(args['antenna_number']))] = h_ijkt

        # step four (4):
        rnd_num = 5
        channelgain_offset = interfer_offset + int(args['user_number']) * int(args['ap_number']) * \
                             int(args['antenna_number'])
        for i_user_index in range(int(args['user_number'])):
            if not a_dl[i_user_index][0]:
                # Method 1: directly generate the eig matrix
                # eig_val, eig_matrix = np.linalg.eig(power_matrix_collection_dl[i_user_index])
                # Method 2:
                eig_val, eig_matrix = \
                    downlink_scenario.modify_power_matrix(power_matrix_collection_dl, i_user_index, rnd_num,
                                                          user_location, a_dl, past_user_location,
                                                          ap_location, ref_center_location, user_height,
                                                          float(args['ap_height']))
                max_eig_indices, max_val = max(enumerate(eig_val.tolist()), key=operator.itemgetter(1))
                eig_vec = eig_matrix[:, max_eig_indices]
                s2_index = channelgain_offset + i_user_index * int(args['ap_number']) * int(args['antenna_number'])
                eig_vec -= eig_vec.mean()
                assert eig_vec.std() > 0
                eig_vec /= eig_vec.std()
                state_s2[range(s2_index, s2_index + int(args['ap_number']) * int(args['antenna_number']))] = eig_vec

        if feasible:  # and not qos_violate_count:
            if max_value_dl != -inf:
                r = max_value_dl
            else:
                r = 0
        else:
            r = 0
            # if max_value_dl != -inf:
            #     r = max_value_dl - 10 * np.abs(max_value_dl)
            # else:
            #     r = -10
        past_reward = r
        print("r[" + str(train_count) + "]=" + str(r))

        # ======================
        # #         s = s2
        # #    for the next epoch
        # ======================
        state = state_s2
        ep_reward += r
        accumulated_ep_reward.append(ep_reward)
        reward_real_time.append(r)
        train_count += 1

    # print('| The cost time of the testing is: {:.4f} seconds'.format(time.time() - epoch_time))
    # # plot the loss value of the critic network
    # plt.figure(1)
    # plt.plot(reward_real_time)
    # plt.show()
    # pass

    if mode is 'OP':
        file_name = 'Test_SingAP_OP_DL_reward_t_value_' + str(int(args['user_number'])) + '.mat'
        io.savemat(file_name, {'reward_t_value': reward_real_time})
    elif mode is 'KNN':
        file_name = 'Test_SingAP_KNN_DL_reward_t_value_' + str(int(args['user_number'])) + '.mat'
        io.savemat(file_name, {'reward_t_value': reward_real_time})
    else:
        print('The mode must be OP or KNN, the results are not saved!')

#     # plotting the simulation results
#     plt.switch_backend('agg')
#     plt.figure(1, figsize=(9, 3))
#     plt.subplot(131)
#     plt.scatter(9, average_coverage_ratio_all_t)
#     plt.subplot(132)
#     plt.scatter(9, fairness_all_t)
#     plt.subplot(133)
#     plt.scatter(9, normalized_average_uav_energy_consumption)
#     plt.show()
#
#     plt.figure(2, figsize=(6, 3))
#     plt.subplot(121)
#     plt.scatter(9, energy_efficiency)
#     # only this sub-figure is not shown originally
#     plt.subplot(122)
#     plt.plot(profit_time)
#     plt.show()
#
#     # the x-axis is time slot t
#     plt.figure(3, figsize=(9, 3))
#     plt.subplot(131)
#     plt.plot(accumulate_reward_time)
#     plt.subplot(132)
#     plt.plot(average_coverage_ratio_time)
#     plt.subplot(133)
#     plt.plot(fairness_time)
#     plt.show()
#
#     print('| coverage_ratio_T: {:.4f} | fairness_T: {:.4f} | normalized_energy: {:.4f} | energy_efficiency: {:.4f}'
#           .format(average_coverage_ratio_all_t, fairness_all_t,
#                   normalized_average_uav_energy_consumption, energy_efficiency))
#
#     # print the times of out_of boundary and network disconnect
#     print('Network disconnect times when testing: {:d} | Out of boundary times when testing: {:d}'.format(
#         int(disconnect_test), int(out_of_boundary_counter_test)))


def main(args):
    start_time = time.time()
    # gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=0.7)
    with tf.Session() as sess:

        # env = gym.make(args['env'])
        np.random.seed(int(args['random_seed']))
        tf.set_random_seed(int(args['random_seed']))
        # env.seed(int(args['random_seed']))

        # generate user locations
        # (Awaiting) load the original data
        user_location_collection = []
        user_location_len = []
        min_x = []
        min_y = []
        max_x = []
        max_y = []
        for num_user in range(int(args['user_number'])):
            data_path = 'C:/Users/swan/PycharmProjects/Federated_ESN_VR/original_data_sets/Predicted_Trajectory_' + \
                        str(num_user+1) + '.mat'
            data = sio.loadmat(data_path)
            # print(data.keys())
            ori_data = data['predicted_trajectory']  # a 2-array in R^{T*2}

            min_x.append(np.min(ori_data[:, 0]))
            min_y.append(np.min(ori_data[:, 1]))
            max_x.append(np.max(ori_data[:, 0]))
            max_y.append(np.max(ori_data[:, 1]))

            # find the minimum sequence length of all user data
            user_location_len.append(len(ori_data[:, 0]))
            user_location_collection.append(ori_data)  # a list including 64 2-arrays

        # obtain the boundary of user locations
        min_loc_x = np.min(min_x)
        min_loc_y = np.min(min_y)
        max_loc_x = np.max(max_x)
        max_loc_y = np.max(max_y)

        # calculate the radius of a circular communication coverage region
        radius_comm = np.sqrt((max_loc_y - min_loc_y)**2 + (max_loc_x - min_loc_x)**2) / 2

        # obtain the aps' locations
        ap_location = np.zeros((int(args['ap_number']), 2))
        for j in range(int(args['ap_number'])):
            ap_location[j, 0] = radius_comm * np.cos(2*np.pi/int(args['ap_number']) * j) + radius_comm
            ap_location[j, 1] = radius_comm * np.sin(2*np.pi/int(args['ap_number']) * j) + radius_comm

        # ref_x = (max_loc_x - min_loc_x) / 4
        # ref_y = (max_loc_y - min_loc_y) / 4
        # ap_location = np.array(
        #     [[min_loc_x + ref_x * 1, min_loc_y + ref_y * 3], [min_loc_x + ref_x * 3, min_loc_y + ref_y * 3],
        #      [min_loc_x + ref_x * 2, min_loc_y + ref_y * 1]])

        seq_len_min_index = user_location_len.index(min(user_location_len))

        # Description of downlink state: 1) the number of users served by ap j for all j;
        # 2) if ap j is service ability violated, whether user i results in it;
        # 3) 1 represents whether the downlink prob is feasible.
        state_dim_downlink = int(args['ap_number']) + int(args['user_number']) * int(args['user_number']) + \
                             2 * int(args['user_number']) * int(args['ap_number']) * int(args['antenna_number'])
        # for each user i and each ap j, the value of a_{ij}^{dl}
        action_dim_downlink = int(args['user_number'])

        # generate the users' heights
        user_height = np.random.normal(float(args['user_height']),
                                       float(args['user_height_std']), int(args['user_number']))

        # # Description of the uplink state: 1) the number of users served by ap j for all j;
        # # 2) if ap j is service ability violated, whether user i results in it;
        # # 3) if the QoS constraint of user j is violated, whether user i leads to it;
        # # 4) how many interference users does user i have;
        # # 5) 1 represents whether the uplink prob is feasible under the given action.
        # state_dim_uplink = int(args['ap_number'])
        # # for each user i and each ap j, the value of a_{ij}^{dl}
        # action_dim_uplink = int(args['user_number']) * int(args['ap_number'])
        # Run = False  # False, means start to train; True, means start to test
        Run = True
        mode = 'OP'  # the quantization mode could be 'OP' (Order-preserving) or 'KNN'
        if not Run:
            actor_downlink = ActorNetworkDownlink(sess, state_dim_downlink, action_dim_downlink, int(args['ap_number']),
                                              float(args['actor_lr']), np.int16(args['minibatch_size']))
            path = 'DNN_trained_para_ckpt'
            # path = 'DNN_train_para_ckpt' + '_F_' + str(1) + '_UAV_' + str(1)
            with mosek.Env() as env_task:
            # create mosek task
                train_downlink(sess, env_task, args, actor_downlink, path,
                               ap_location, user_location_collection, seq_len_min_index, user_height, mode)
        else:
            actor_downlink = ActorNetworkDownlink(sess, state_dim_downlink, action_dim_downlink, int(args['ap_number']),
                                                  float(args['actor_lr']), np.int16(args['minibatch_size']))
            path = 'DNN_trained_para_ckpt'
            # path = 'DNN_train_para_ckpt' + '_F_' + str(1) + '_UAV_' + str(1)
            with mosek.Env() as env_task:
            # create mosek task
                test_downlink(sess, env_task, args, actor_downlink, path,
                              ap_location, user_location_collection, seq_len_min_index, user_height, mode)

        print("The running time of this program is --- %.4f seconds ---" % (time.time() - start_time))
        # if args['use_gym_monitor']:
        #     env.monitor.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='provide arguments for DDPG agent')

    # agent parameters
    parser.add_argument('--actor-lr', help='actor network learning rate', default=0.01)
    # parser.add_argument('--critic-lr', help='critic network learning rate', default=0.01)
    parser.add_argument('--gamma', help='discount factor for critic updates', default=0.99)
    parser.add_argument('--tau', help='soft target update parameter', default=0.001)
    parser.add_argument('--buffer-size', help='max size of the replay buffer', default=1000000)  # 1000000
    parser.add_argument('--minibatch-size', help='size of minibatch for minibatch-SGD', default=64)  # 1024
    parser.add_argument('--forgot-len', help='length of initial forgotten samples', default=200)  # 1024
    parser.add_argument('--training-interval', help='training interval', default=20)  # 10
    # deployment scenario parameters
    # user configuration
    parser.add_argument('--average-total-user-power', help='the average total user power', default=27.0)  # in dBm
    parser.add_argument('--inst-total-user-power', help='the total instant user power', default=27.16)  # in dBm
    parser.add_argument('--user-circuit-power', help='user circuit power', default=23.0)  # in dBm
    parser.add_argument('--noise-power', help='noise power', default=-167.0)  # 107.0
    parser.add_argument('--uplink-bandwidth', help='uplink bandwidth', default=20)  # in MHz
    parser.add_argument('--user-number', help='the number of users', default=20)  # 64
    parser.add_argument('--alpha', help='the path loss coefficient', default=2)  # 2-4
    parser.add_argument('--tradeoff-coefficient-v', help='the tradeoff coefficient value V', default=1)  # 200
    parser.add_argument('--uplink-QoS', help='the QoS of uplink transmission', default=0.2)
    parser.add_argument('--user-height', help='the height of a user', default=1.8)
    parser.add_argument('--user-height-std', help='the standard variance of the height of a user', default=0.05)
    parser.add_argument('--vartheta', help='the value of vartheta for LoS status checking', default=1.507)  # pi/2
    parser.add_argument('--theta', help='the angle value of theta for antenna downtilt', default=1.047)  # pi/3
    parser.add_argument('--phi', help='the value of phi for Channel Gain status identifying', default=1.047)  # pi/3
    parser.add_argument('--find-neighbor-dist', help='Interfering coverage radius', default=50)  # in meter
    parser.add_argument('--small-gain', help='Small channel gain', default=1)  # in dB
    parser.add_argument('--great-gain', help='Great channel gain', default=5)  # in dB
    parser.add_argument('--ref-loc-x', help='reference center x coordinate location', default=250)  # in meter
    parser.add_argument('--ref-loc-y', help='reference center y coordinate location', default=250)  # in meter

    # ap configuration
    parser.add_argument('--ap-power', help='the ap power', default=40.0)  # in dBm 37
    parser.add_argument('--ap-circuit-power', help='the ap circuit power', default=30.0)
    parser.add_argument('--downlink-bandwidth', help='the downlink bandwidth', default=800)  # in MHz
    parser.add_argument('--ap-number', help='the number of aps', default=1)
    parser.add_argument('--antenna-number', help='the number of antennas', default=2)
    parser.add_argument('--downlink-QoS', help='the QoS of downlink transmission', default=1000)
    parser.add_argument('--eta-LoS', help='max length of 1 episode for test', default=2.0)
    parser.add_argument('--eta-NLoS', help='max length of 1 episode for test', default=2.4)
    parser.add_argument('--sigma-LoS', help='max length of 1 episode for test', default=5.3)
    parser.add_argument('--sigma-NLoS', help='max length of 1 episode for test', default=5.27)
    parser.add_argument('--light-speed', help='max length of 1 episode for test', default=3e+8)
    parser.add_argument('--carrier-frequency', help='the carrier frequency of downlink transmission', default=2.8e+10)
    parser.add_argument('--ap-uplink-serving-users', help='number of uplink serving users of the ap', default=3)
    parser.add_argument('--ap-height', help='height of an ap', default=5.5)

    parser.add_argument('--max-episode-len-test', help='max length of 1 episode for test', default=5000)

    # run parameters
    parser.add_argument('--env', help='choose the gym env- tested on {Pendulum-v0}', default='Pendulum-v0')
    parser.add_argument('--random-seed', help='random seed for repeatability', default=1234)
    parser.add_argument('--max-episodes', help='max num of episodes to do while training', default=10)  # 2000
    parser.add_argument('--max-episode-len', help='max length of 1 episode', default=1000)  # 2000
    parser.add_argument('--render-env', help='render the gym env', action='store_true')
    parser.add_argument('--use-gym-monitor', help='record gym results', action='store_true')
    parser.add_argument('--monitor-dir', help='directory for storing gym results', default='./results/gym_ddpg')
    parser.add_argument('--summary-dir', help='directory for storing tensorboard info', default='./results/tf_ddpg')

    parser.set_defaults(render_env=False)
    parser.set_defaults(use_gym_monitor=True)

    args = vars(parser.parse_args())

    pp.pprint(args)

    main(args)