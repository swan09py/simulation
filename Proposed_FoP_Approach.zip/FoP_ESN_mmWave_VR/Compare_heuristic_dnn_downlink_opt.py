"""
Implementation of DDPG - Deep Deterministic Policy Gradient
Algorithm and hyperparameter details can be found here:
    http://arxiv.org/pdf/1509.02971v2.pdf
The algorithm is tested on the Pendulum-v0 OpenAI gym task
and developed with tflearn + Tensorflow
Author: Patrick Emami
"""
import tensorflow as tf
import numpy as np
import gym
from gym import wrappers
import tflearn
import argparse
import pprint as pp
from scipy import io
import math
import matplotlib.pyplot as plt
import time
import random
import scipy.io as sio
import mosek
import sys
import copy
import operator
import os
import itertools

from replay_buffer import ReplayBuffer
from downlink_scenario import DownlinkScenario

pi = 3.1415926925
inf = 1e+9


# Define a stream printer to grab output from MOSEK
def stream_printer(text):
    sys.stdout.write(text)
    sys.stdout.flush()


def mkdir(path):
    """
    this function is used to create a path for saving results
    generated during the process of running the program !
    :param path:
    :return: True if it creates a dictionary; otherwise, False if the dictionary already exists
    """
    import os

    path = path.strip()
    path = path.rstrip("\\")

    isExists = os.path.exists(path)

    if not isExists:
        os.makedirs(path)

        print(path + ' Successfully Created!')

        return True
    else:
        print(path + ' Document has Existed!')

        return False


# Taken from https://github.com/openai/baselines/blob/master/baselines/ddpg/noise.py, which is
# based on http://math.stackexchange.com/questions/1287634/implementing-ornstein-uhlenbeck-in-matlab
class OrnsteinUhlenbeckActionNoise:
    def __init__(self, mu, sigma=0.3, theta=.15, dt=1e-2, x0=None):
        self.theta = theta
        self.mu = mu
        self.sigma = sigma
        self.dt = dt
        self.x0 = x0
        self.reset()

    def __call__(self):
        x = self.x_prev + self.theta * (self.mu - self.x_prev) * self.dt + \
            self.sigma * np.sqrt(self.dt) * np.random.normal(size=self.mu.shape)
        self.x_prev = x
        return x

    def reset(self):
        self.x_prev = self.x0 if self.x0 is not None else np.zeros_like(self.mu)

    def __repr__(self):
        return 'OrnsteinUhlenbeckActionNoise(mu={}, sigma={})'.format(self.mu, self.sigma)


# ===========================
#   Agent Training
# ===========================

def train_downlink(sess, env_task, args, path, ap_location, user_location_collection, seq_len_min_index,
                   user_height):
    # create a folder
    mkdir(path)

    # Initialize the downlink scenario
    downlink_scenario = DownlinkScenario(env_task, float(args['ap_power']),
                                         float(args['noise_power']),
                                         float(args['downlink_bandwidth']),
                                         int(args['ap_number']),
                                         int(args['antenna_number']),
                                         float(args['downlink_QoS']),
                                         float(args['ap_circuit_power']),
                                         float(args['eta_LoS']),
                                         float(args['eta_NLoS']),
                                         float(args['sigma_LoS']),
                                         float(args['sigma_NLoS']),
                                         np.int32(args['light_speed']),
                                         np.int64(args['carrier_frequency']),
                                         int(args['user_number']),
                                         float(args['find_neighbor_dist']),
                                         float(args['vartheta']),
                                         float(args['small_gain']),
                                         float(args['great_gain']),
                                         float(args['theta']),
                                         float(args['phi']),
                                         float(args['ap_height']),
                                         user_height)

    # obtain a user's location
    user_location = []
    for num_user in range(int(args['user_number'])):
        user_i_loc = user_location_collection[num_user]  # a 2-array in R^{T * 2}
        # get the user location at time slot t = 10
        user_location.append(user_i_loc[:, 0].tolist())

    user_location = np.array(user_location)  # all users' locations at t = 1
    ref_center_location = np.array([[float(args['ref_loc_x']), float(args['ref_loc_y']), 0]])
    past_user_location = np.zeros((int(args['user_number']), 2))

    reward_t_collection = []

    t_count = 0
    former_user_location = np.zeros((int(args['user_number']), 2))
    train_count = 0
    total_time = time.time()
    for i in range(int(args['max_episodes'])):
        ep_reward = 0
        ep_ave_max_q = 0

        ep_time = time.time()

        for j in range(int(args['max_episode_len'])):
            # update the users' locations every x times
            if int(train_count % int(np.ceil(int(args['max_episode_len']) * int(args['max_episodes']) /
                                             len(user_location_collection[seq_len_min_index][0, :])))) == 0:
                # obtain a user's location
                user_location = []
                for num_user in range(int(args['user_number'])):
                    user_i_loc = user_location_collection[num_user]  # a 2-array in R^{T * 2}
                    # get the user location at time slot t = 10
                    user_location.append(user_i_loc[:, t_count].tolist())
                user_location = np.array(user_location)  # all users' locations

                # obtain the past user locations
                if not t_count:
                    past_user_location = np.zeros((int(args['user_number']), 2))
                else:
                    past_user_location = former_user_location

                t_count += 1

            # save the user location at time slot t-1
            former_user_location = copy.deepcopy(user_location)

            # calculate the path loss # it should be a list including I 2D-array
            h_matrix_collection, _ = downlink_scenario.calculate_path_loss(user_location, past_user_location, ap_location,
                                                              ref_center_location, user_height, float(args['ap_height']))
            sum_hit = np.zeros((int(args['user_number']), ))
            for i_user_index in range(int(args['user_number'])):
                sum_hit[i_user_index] = np.sum(h_matrix_collection[i_user_index] * 1e+8)
            candidate_action_minus = np.ones((int(args['user_number']), ))
            candidate_action_plus = np.zeros((int(args['user_number']), ))
            while np.sum(candidate_action_minus) >= 0.9:
                # step 1: find the max sum(h_it)
                max_idx = sum_hit.argmax()  # i_star
                # step 2: move the i_star from action^- to action^+
                candidate_action_plus[max_idx] = 1
                candidate_action_minus[max_idx] = 0
                sum_hit[max_idx] = -1e+9
                # step 3: verify the feasibility of the candidate action
                power_matrix_collection, action_feasibility = \
                    downlink_scenario.downlink_optimization(candidate_action_plus.reshape((int(args['user_number']), 1)),
                                                            user_location, past_user_location,
                                                            ap_location, ref_center_location, user_height,
                                                            float(args['ap_height']))
                if not action_feasibility:
                    candidate_action_plus[max_idx] = 0

            # choose the best one action from all candidate actions
            r = (float(args['tradeoff_coefficient_v']) / \
                                                     int(args['user_number']) * \
                                                     int(np.sum(candidate_action_plus)))

            print("r[" + str(train_count) + "]=" + str(r))

            ep_reward += r
            train_count += 1
            reward_t_collection.append(r)

    # plot the loss value of the critic network
    # plt.figure(3)
    # plt.plot(reward_t_collection)
    # plt.show()
    # pass
    print('Cost time of the training process: {:.4f} seconds'.format(time.time() - total_time))
    file_name = 'Heuristic_downlink_reward_t_value_' + str(int(args['user_number'])) + '.mat'
    io.savemat(file_name, {'reward_t_value': reward_t_collection})

def main(args):
    start_time = time.time()
    # gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=0.7)
    with tf.Session() as sess:

        # env = gym.make(args['env'])
        np.random.seed(int(args['random_seed']))
        tf.set_random_seed(int(args['random_seed']))
        # env.seed(int(args['random_seed']))

        # generate user locations
        # (Awaiting) load the original data
        user_location_collection = []
        user_location_len = []
        min_x = []
        min_y = []
        max_x = []
        max_y = []
        for num_user in range(int(args['user_number'])):
            data_path = 'C:/Users/swan/PycharmProjects/Federated_ESN_VR/original_data_sets/Predicted_Trajectory_' + \
                        str(num_user+1) + '.mat'
            data = sio.loadmat(data_path)
            # print(data.keys())
            ori_data = data['predicted_trajectory']  # a 2-array in R^{T*2}

            min_x.append(np.min(ori_data[:, 0]))
            min_y.append(np.min(ori_data[:, 1]))
            max_x.append(np.max(ori_data[:, 0]))
            max_y.append(np.max(ori_data[:, 1]))

            # find the minimum sequence length of all user data
            user_location_len.append(len(ori_data[:, 0]))
            user_location_collection.append(ori_data)  # a list including 64 2-arrays

        # obtain the boundary of user locations
        min_loc_x = np.min(min_x)
        min_loc_y = np.min(min_y)
        max_loc_x = np.max(max_x)
        max_loc_y = np.max(max_y)

        # calculate the radius of a circular communication coverage region
        radius_comm = np.sqrt((max_loc_y - min_loc_y)**2 + (max_loc_x - min_loc_x)**2) / 2

        # obtain the aps' locations
        ap_location = np.zeros((int(args['ap_number']), 2))
        for j in range(int(args['ap_number'])):
            ap_location[j, 0] = radius_comm * np.cos(2*np.pi/int(args['ap_number']) * j) + radius_comm
            ap_location[j, 1] = radius_comm * np.sin(2*np.pi/int(args['ap_number']) * j) + radius_comm

        # ref_x = (max_loc_x - min_loc_x) / 4
        # ref_y = (max_loc_y - min_loc_y) / 4
        # ap_location = np.array(
        #     [[min_loc_x + ref_x * 1, min_loc_y + ref_y * 3], [min_loc_x + ref_x * 3, min_loc_y + ref_y * 3],
        #      [min_loc_x + ref_x * 2, min_loc_y + ref_y * 1]])

        seq_len_min_index = user_location_len.index(min(user_location_len))

        # Description of downlink state: 1) the number of users served by ap j for all j;
        # 2) if ap j is service ability violated, whether user i results in it;
        # 3) 1 represents whether the downlink prob is feasible.
        state_dim_downlink = int(args['ap_number']) + int(args['user_number']) * int(args['user_number']) + \
                             2 * int(args['user_number']) * int(args['ap_number']) * int(args['antenna_number'])
        # for each user i and each ap j, the value of a_{ij}^{dl}
        action_dim_downlink = int(args['user_number'])

        # generate the users' heights
        user_height = np.random.normal(float(args['user_height']),
                                       float(args['user_height_std']), int(args['user_number']))

        # # Description of the uplink state: 1) the number of users served by ap j for all j;
        # # 2) if ap j is service ability violated, whether user i results in it;
        # # 3) if the QoS constraint of user j is violated, whether user i leads to it;
        # # 4) how many interference users does user i have;
        # # 5) 1 represents whether the uplink prob is feasible under the given action.
        # state_dim_uplink = int(args['ap_number'])
        # # for each user i and each ap j, the value of a_{ij}^{dl}
        # action_dim_uplink = int(args['user_number']) * int(args['ap_number'])
        Run = False  # False, means start to train; True, means start to test
        # Run = True
        if not Run:
            path = 'Simulation_results_collection'
            # path = 'DNN_train_para_ckpt' + '_F_' + str(1) + '_UAV_' + str(1)
            with mosek.Env() as env_task:
            # create mosek task
                train_downlink(sess, env_task, args, path,
                               ap_location, user_location_collection, seq_len_min_index, user_height)

        print("The running time of this program is --- %.4f seconds ---" % (time.time() - start_time))
        # if args['use_gym_monitor']:
        #     env.monitor.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='provide arguments for DDPG agent')

    # agent parameters
    parser.add_argument('--actor-lr', help='actor network learning rate', default=0.01)
    # parser.add_argument('--critic-lr', help='critic network learning rate', default=0.01)
    parser.add_argument('--gamma', help='discount factor for critic updates', default=0.99)
    parser.add_argument('--tau', help='soft target update parameter', default=0.001)
    parser.add_argument('--buffer-size', help='max size of the replay buffer', default=1000000)  # 1000000
    parser.add_argument('--minibatch-size', help='size of minibatch for minibatch-SGD', default=256)  # 1024
    parser.add_argument('--forgot-len', help='length of initial forgotten samples', default=200)  # 1024
    parser.add_argument('--training-interval', help='training interval', default=10)  # 10
    # deployment scenario parameters
    # user configuration
    parser.add_argument('--average-total-user-power', help='the average total user power', default=27.0)  # in dBm
    parser.add_argument('--inst-total-user-power', help='the total instant user power', default=27.16)  # in dBm
    parser.add_argument('--user-circuit-power', help='user circuit power', default=23.0)  # in dBm
    parser.add_argument('--noise-power', help='noise power', default=-167.0)  # 107.0
    parser.add_argument('--uplink-bandwidth', help='uplink bandwidth', default=20)  # in MHz
    parser.add_argument('--user-number', help='the number of users', default=22)  # 64
    parser.add_argument('--alpha', help='the path loss coefficient', default=2)  # 2-4
    parser.add_argument('--tradeoff-coefficient-v', help='the tradeoff coefficient value V', default=1)  # 200
    parser.add_argument('--uplink-QoS', help='the QoS of uplink transmission', default=0.2)
    parser.add_argument('--user-height', help='the height of a user', default=1.8)
    parser.add_argument('--user-height-std', help='the standard variance of the height of a user', default=0.05)
    parser.add_argument('--vartheta', help='the value of vartheta for LoS status checking', default=1.507)  # pi/2
    parser.add_argument('--theta', help='the angle value of theta for antenna downtilt', default=1.047)  # pi/3
    parser.add_argument('--phi', help='the value of phi for Channel Gain status identifying', default=1.047)  # pi/3
    parser.add_argument('--find-neighbor-dist', help='Interfering coverage radius', default=50)  # in meter
    parser.add_argument('--small-gain', help='Small channel gain', default=1)  # in dB
    parser.add_argument('--great-gain', help='Great channel gain', default=5)  # in dB
    parser.add_argument('--ref-loc-x', help='reference center x coordinate location', default=250)  # in meter
    parser.add_argument('--ref-loc-y', help='reference center y coordinate location', default=250)  # in meter

    # ap configuration
    parser.add_argument('--ap-power', help='the ap power', default=40.0)  # in dBm
    parser.add_argument('--ap-circuit-power', help='the ap circuit power', default=30.0)
    parser.add_argument('--downlink-bandwidth', help='the downlink bandwidth', default=800)  # in MHz
    parser.add_argument('--ap-number', help='the number of aps', default=3)
    parser.add_argument('--antenna-number', help='the number of antennas', default=2)
    parser.add_argument('--downlink-QoS', help='the QoS of downlink transmission', default=1000)
    parser.add_argument('--eta-LoS', help='max length of 1 episode for test', default=2.0)
    parser.add_argument('--eta-NLoS', help='max length of 1 episode for test', default=2.4)
    parser.add_argument('--sigma-LoS', help='max length of 1 episode for test', default=5.3)
    parser.add_argument('--sigma-NLoS', help='max length of 1 episode for test', default=5.27)
    parser.add_argument('--light-speed', help='max length of 1 episode for test', default=3e+8)
    parser.add_argument('--carrier-frequency', help='the carrier frequency of downlink transmission', default=2.8e+10)
    parser.add_argument('--ap-downlink-serving-users', help='number of downlink serving users of the ap', default=64)
    parser.add_argument('--ap-uplink-serving-users', help='number of uplink serving users of the ap', default=6)
    parser.add_argument('--ap-height', help='height of an ap', default=5.5)

    parser.add_argument('--max-episode-len-test', help='max length of 1 episode for test', default=5000)

    # run parameters
    parser.add_argument('--env', help='choose the gym env- tested on {Pendulum-v0}', default='Pendulum-v0')
    parser.add_argument('--random-seed', help='random seed for repeatability', default=1234)
    parser.add_argument('--max-episodes', help='max num of episodes to do while training', default=1)  # 2000
    parser.add_argument('--max-episode-len', help='max length of 1 episode', default=5000)  # 2000
    parser.add_argument('--render-env', help='render the gym env', action='store_true')
    parser.add_argument('--use-gym-monitor', help='record gym results', action='store_true')
    parser.add_argument('--monitor-dir', help='directory for storing gym results', default='./results/gym_ddpg')
    parser.add_argument('--summary-dir', help='directory for storing tensorboard info', default='./results/tf_ddpg')

    parser.set_defaults(render_env=False)
    parser.set_defaults(use_gym_monitor=True)

    args = vars(parser.parse_args())

    pp.pprint(args)

    main(args)