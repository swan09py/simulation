"""
Implementation of DDPG - Deep Deterministic Policy Gradient
Algorithm and hyperparameter details can be found here:
    http://arxiv.org/pdf/1509.02971v2.pdf
The algorithm is tested on the Pendulum-v0 OpenAI gym task
and developed with tflearn + Tensorflow
Author: Patrick Emami
"""
import tensorflow as tf
import numpy as np
import gym
from gym import wrappers
import tflearn
import argparse
import pprint as pp
from scipy import io
import math
import matplotlib.pyplot as plt
import time
import random
import scipy.io as sio
import mosek
import sys
import copy
import operator
import itertools

from replay_buffer import ReplayBuffer
from uplink_scenario_no_interference import UplinkScenarioNoInterference
# from uplink_scenario import UplinkScenario

pi = 3.1415926925
inf = 1e+9


# Define a stream printer to grab output from MOSEK
def stream_printer(text):
    sys.stdout.write(text)
    sys.stdout.flush()


def mkdir(path):
    """
    this function is used to create a path for saving results
    generated during the process of running the program !
    :param path:
    :return: True if it creates a dictionary; otherwise, False if the dictionary already exists
    """
    import os

    path = path.strip()
    path = path.rstrip("\\")

    isExists = os.path.exists(path)

    if not isExists:
        os.makedirs(path)

        print(path + ' Successfully Created!')

        return True
    else:
        print(path + ' Document has Existed!')

        return False

# ===========================
#   Uplink Actor and Critic DNNs
# ===========================

class ActorNetworkUplink(object):
    """
    Input to the network is the state, output is the action
    under a deterministic policy.
    The output layer activation is a tanh to keep the action
    between -action_bound and action_bound
    """

    def __init__(self, sess, state_dim, action_dim, learning_rate, batch_size):
        self.sess = sess
        self.s_dim = state_dim
        self.a_dim = action_dim
        self.learning_rate = learning_rate
        self.batch_size = batch_size

        # Actor Network
        self.inputs, self.out = self.create_actor_network()

        self.network_params = tf.trainable_variables()

        # # Target Network
        # self.target_inputs, self.target_out, self.target_scaled_out = self.create_actor_network()

        # self.target_network_params = tf.trainable_variables()[
        #                              len(self.network_params):]

        # Op for periodically updating target network with online network
        # weights
        # self.update_target_network_params = \
        #     [self.target_network_params[i].assign(tf.multiply(self.network_params[i], self.tau) +
        #                                           tf.multiply(self.target_network_params[i], 1. - self.tau))
        #      for i in range(len(self.target_network_params))]

        # This gradient will be provided by the critic network

        # Network target action (a_{star})
        self.target_action = tf.placeholder(tf.float32, [None, self.a_dim])

        # Define loss and optimization Op
        self.loss = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(labels=self.target_action, logits=self.out))

        # Optimization Op
        self.optimize = tf.train.AdamOptimizer(self.learning_rate, 0.09).minimize(self.loss)

        self.num_trainable_vars = len(self.network_params)

    def create_actor_network(self):
        # tflearn.input_data is used to input data to a network by creating a placeholder or use a existing holder
        # we should check whether the inputs is got from outside, i.e., s_t, or created by the DNN itself at t
        # IMO: this configuration does not accept outside input value, so it may be wrong !!!
        inputs = tflearn.input_data(shape=[None, self.s_dim])

        net = tflearn.fully_connected(inputs, 120)
        net = tflearn.layers.normalization.batch_normalization(net)
        net = tflearn.activations.relu(net)
        net = tflearn.fully_connected(net, 80)
        net = tflearn.layers.normalization.batch_normalization(net)
        net = tflearn.activations.relu(net)
        # Final layer weights are init to Uniform[-3e-3, 3e-3]
        w_init = tflearn.initializations.uniform(minval=-0.003, maxval=0.003)
        out = tflearn.fully_connected(
            net, self.a_dim, activation='linear', weights_init=w_init)

        # Scale output to -action_bound to action_bound
        # Scale the output value, should bound and change it to [0, 1] array
        # scaled_out = tf.add(tf.multiply(out, 0.5), 0.5)
        return inputs, out

    def train(self, inputs, target_action):
        return self.sess.run([self.optimize, self.loss], feed_dict={
            self.inputs: inputs,
            self.target_action: target_action
        })

    def predict(self, inputs):
        return self.sess.run(self.out, feed_dict={
            self.inputs: inputs
        })

    def get_num_trainable_vars(self):
        return self.num_trainable_vars


# ===========================
#   Tensorflow Summary Ops
# ===========================

def build_summaries():
    episode_reward = tf.Variable(0.)
    tf.summary.scalar("Reward", episode_reward)
    episode_ave_max_q = tf.Variable(0.)
    tf.summary.scalar("Qmax Value", episode_ave_max_q)

    summary_vars = [episode_reward, episode_ave_max_q]
    summary_ops = tf.summary.merge_all()

    return summary_ops, summary_vars


# ===========================
#   Agent Training
# ===========================

def train_uplink(sess, env_task, args, actor_uplink, path,
                 ap_location, user_location_collection, seq_len_min_index,
                 interfering_user_list, interfering_user_array, num_groups, user_height, mode):
    # Set up summary Ops
    summary_ops, summary_vars = build_summaries()
    if mode is 'OP':
        path = path + '/OP_DNN_UL_training_' + str(int(args['user_number']))
        mkdir(path)
    elif mode is 'KNN':
        path = path + '/KNN_DNN_UL_training_' + str(int(args['user_number']))
        mkdir(path)
    else:
        print('The mode must be OP or KNN!')

    # saver = tf.train.Saver(max_to_keep=int(args['max_episodes']))
    saver = tf.train.Saver(max_to_keep=1)  # the maximum number of recent checkpoints to save is 1
    # LOAD = True
    LOAD = False
    if LOAD:
        saver.restore(sess, tf.train.latest_checkpoint(''))
    else:
        sess.run(tf.global_variables_initializer())

    writer = tf.summary.FileWriter(args['summary_dir'], sess.graph)

    # Initialize replay memory
    replay_buffer_uplink = ReplayBuffer(int(args['buffer_size']), int(args['random_seed']))

    # Initialize the scenario
    uplink_scenario = UplinkScenarioNoInterference(env_task,
                                     float(args['noise_power']),
                                     float(args['uplink_bandwidth']),
                                     int(args['ap_number']),
                                     float(args['uplink_QoS']),
                                     float(args['alpha']),
                                     int(args['user_number']),
                                     interfering_user_list,
                                     interfering_user_array,
                                     num_groups,
                                     10**(float(args['inst_total_user_power'])/10) -
                                     10**(float(args['user_circuit_power'])/10),
                                     float(args['rayleigh_gain'])
                                     )
    # Initialize the interfering indicator matrix
    uplink_scenario.initialize_interfering_indicator_matrix()

    # (Awaiting) should call a function to obtain [Q]^+ vector
    q_plus = np.ones((int(args['user_number']),))
    q_collection = []
    for i_q in range(int(args['user_number'])):
        q_collection.append([100.])
    # tradeoff_coefficient_v = 200

    initial_forgot_count = 0
    critic_loss_collection_up = []
    reward_train_interval_collection = []
    reward_t_collection = []
    past_reward = 1.0
    count_t = 0
    train_iter = 0
    sum_time = time.time()

    # update the users' locations every x times
    # obtain a user's location
    user_location = []
    for num_user in range(int(args['user_number'])):
        user_i_loc = user_location_collection[num_user]  # a 2-array in R^{T * 2}
        # get the user location at time slot t = 10
        user_location.append(user_i_loc[:, 0].tolist())
    user_location = np.array(user_location)  # all users' locations

    # user_location = np.array([[0, 0], [150, 150], [600, 200], [300, 360]])
    # ap_location = np.array([[100.0, 200.0], [400.0, 600.0], [330.0, 460.0]])  # it is a list

    # antenna_gain = np.ones((int(args['user_number']), int(args['ap_number'])))
    service_ability_up = np.ones((int(args['ap_number']),)) * int(args['ap_uplink_serving_users'])
    # obtain the h_matrix in R^{num_antenna, num_antenna * num_user * num_ap}
    distance_ij_matrix_up = np.zeros((int(args['user_number']), int(args['ap_number'])))

    for i in range(int(args['max_episodes'])):
        # ==========================
        #       initialize  state;  it is an one-dimensional array | 1-d array
        # ==========================
        s_dim = int(args['ap_number']) + int(args['user_number']) * int(args['ap_number']) + int(args['user_number'])
        state_uplink = np.zeros((s_dim, ))
        # specify the number of users served by each ap, using the nearest principle
        # update the distance_ij_matrix
        for user_index in range(int(args['user_number'])):
            for ap_index in range(int(args['ap_number'])):
                distance_ij_matrix_up[user_index][ap_index] = \
                    uplink_scenario.dis_calculate(user_index, ap_index, user_location, ap_location,
                                                  user_height, float(args['ap_height']))

        init_j_star = []  # the index of j_star for each user i
        init_aij = np.zeros((int(args['user_number']), int(args['ap_number'])))
        for user_index in range(int(args['user_number'])):
            dis_list = distance_ij_matrix_up[user_index].tolist()
            init_j_star.append(dis_list.index(np.min(distance_ij_matrix_up[user_index])))
            init_aij[user_index, init_j_star[user_index]] = 1

        for ap_index in range(int(args['ap_number'])):
            state_uplink[ap_index] = np.sum(init_aij[:, ap_index])/service_ability_up[0]

        # specify the channel gain coefficients
        ap_offset = int(args['ap_number'])
        channelgain_offset = int(args['user_number']) * int(args['ap_number'])

        hijt = uplink_scenario.pathloss_calculate(user_location, ap_location, user_height, float(args['ap_height']))
        hijt -= hijt.mean()
        assert hijt.std() > 0
        hijt /= hijt.std()
        state_uplink[range(ap_offset, ap_offset + channelgain_offset)] = hijt

        # specify the user power
        user_power = np.random.rand((int(args['user_number']))) * 20
        user_power -= user_power.mean()
        assert user_power.std() > 0
        user_power /= user_power.std()
        state_uplink[range(ap_offset+channelgain_offset, ap_offset+channelgain_offset+int(args['user_number']))] = user_power

        ep_reward_up = 0
        ep_ave_max_q_up = 0
        epsilon_up = 0.9995

        # #  ----------  start the epoch  --------------
        #         each episode include J epoch
        # # --------------------------------------------

        for j in range(int(args['max_episode_len'])):
            # update the users' locations every x times
            if int(train_iter % int(np.ceil(int(args['max_episode_len']) * int(args['max_episodes']) /
                                             len(user_location_collection[seq_len_min_index][:, 0])))) == 0:
                # obtain a user's location
                user_location = []
                for num_user in range(int(args['user_number'])):
                    user_i_loc = user_location_collection[num_user]  # a 2-array in R^{T * 2}
                    # get the user location at time slot t = 10
                    user_location.append(user_i_loc[:, count_t].tolist())
                user_location = np.array(user_location)  # all users' locations

                # user_location = np.array([[0, 0], [150, 150], [600, 200], [300, 360]])
                # ap_location = np.array([[100.0, 200.0], [400.0, 600.0], [330.0, 460.0]])  # it is a list

                # antenna_gain = np.ones((int(args['user_number']), int(args['ap_number'])))
                service_ability_up = np.ones((int(args['ap_number']),)) * int(args['ap_uplink_serving_users'])
                # obtain the h_matrix in R^{num_antenna, num_antenna * num_user * num_ap}
                distance_ij_matrix_up = np.zeros((int(args['user_number']), int(args['ap_number'])))
                for user_index in range(int(args['user_number'])):
                    for ap_index in range(int(args['ap_number'])):
                        distance_ij_matrix_up[user_index][ap_index] = \
                            uplink_scenario.dis_calculate(user_index, ap_index, user_location, ap_location,
                                                          user_height, float(args['ap_height']))
                count_t += 1
            # initialize the data structure for training, save in row format
            state_uplink_s2 = np.zeros((s_dim, )) + 0.0001

            # ========================
            #           state 2
            # ========================
            # Calculate the sample action a = \mu(s|\theta^{\mu}), add exploration noise using the EE scheme
            # a_ori_up = actor_uplink.predict(np.reshape(state_uplink, (1, actor_uplink.s_dim))) + actor_noise()
            actor_ori_up_noise = np.random.normal(0, 0.6, int(args['ap_number']) * int(args['user_number']))
            a_ori_up = actor_uplink.predict(np.reshape(state_uplink, (1, actor_uplink.s_dim))) + \
                       np.power(epsilon_up, j) * actor_ori_up_noise
            # a_ori_up = np.clip(a_ori_up, 0, 1)

            a_collection_up = []  # list, R^{i <= a_base_len}, each element is a 2d array
            a_base_collection_up = []  # it includes the objective function value of each candidate action by summing a row

            # # # # # # # # # # # # -------------------------------- # # # # # # # #
            # # # ------ Quantize the original action to K <= N action vectors, 2-d array, R^{user_number, ap_number}
            a_ori_2array_up = np.array(a_ori_up).reshape((int(args['user_number']), int(args['ap_number'])))

            # step one: order the original action
            a_ori_user_up = np.max(a_ori_2array_up, 1)  # 1-d array, R^{user_number}, the maximum action

            a_base_ascend_up = np.argsort(np.abs(a_ori_user_up))
            assert len(a_base_ascend_up.tolist()) == int(args['user_number']), \
                "The utilization of the list operator is wrong!"

            ability_violation_up = True  # an indicator indicates whether the service ability constraint is violated

            a_base_len_up = len(a_base_ascend_up)
            a_intermed_collection_2array_up = np.ones((int(args['user_number']), int(args['user_number'])))
            # # # # # # ----  Case II:  -----  # # # # # # #
            # obtain all the reference base actions

            # Two methods of generating the candidate actions
            if mode is 'OP':
                # step two: generate the 1st candidate action
                # set the reference base be 0.5; as sigmoid(0) = 0.5, and we did not activate the output with sigmoid
                a_base_collection_up.append(1 * (a_ori_user_up > 0))
                if int(args['user_number']) > 1:
                    # step three: generate other candidate actions
                    idx_array = a_base_ascend_up[:int(args['user_number']) - 1]
                    for base_index in range(int(args['user_number']) - 1):
                        if a_ori_user_up[idx_array[base_index]] > 0:
                            # set a positive user to 0
                            a_base_collection_up.append(1 * (a_ori_user_up - a_ori_user_up[idx_array[base_index]] > 0))
                        else:
                            # set a negtive user to 1
                            a_base_collection_up.append(1 * (a_ori_user_up - a_ori_user_up[idx_array[base_index]] >= 0))
                a_intermed_collection_2array_up = np.array(a_base_collection_up)
            elif mode is 'KNN':
                # list all 2^N binary offloading actions
                enumerate_actions = np.array(list(map(list, itertools.product([0, 1], repeat=int(args['user_number'])))))

                # the 2-norm
                sqd = ((enumerate_actions - a_ori_user_up) ** 2).sum(1)
                idx = np.argsort(sqd)
                a_intermed_collection_2array_up = enumerate_actions[idx[:int(args['user_number'])]]
            else:
                print("The action selection must be 'OP' or 'KNN'")

            # recover the quantized action set according to the ref base actions
            # a_intermed_collection_2array, all intermediate candidate actions, 2d array,R^{a_base_len, user_number}
            for a_base_len_index in range(a_base_len_up):
                immed_action_up = copy.deepcopy(a_ori_2array_up)  # 2d array, R^{user_number, ap_number}
                for user_index in range(int(args['user_number'])):
                    immed_action_up[user_index] = np.zeros((int(args['ap_number']),))
                    if a_intermed_collection_2array_up[a_base_len_index][user_index] == 1:
                        # obtain the index of the maximum value in a[i]
                        max_index, max_value = max(enumerate(a_ori_2array_up[user_index].tolist()),
                                                   key=operator.itemgetter(1))
                        immed_action_up[user_index][max_index] = int(1)
                # collect the candidate actions, the length is a_base_len
                # a_base_len: the number of candidate actions
                a_collection_up.append(immed_action_up)  # list, R^{a_base_len}, each element is a 2d array

            # copy the a_collection
            a_collection_copy_up = copy.deepcopy(a_collection_up)

            # # # # # # # #   ------------------------------------   # # # # # # # #
            # # # # # Verify the effectiveness of the candidate actions, and choose the one minimizing the reward
            reward_collection = np.ones((a_base_len_up,)) * (-inf)
            user_power_collection = []
            for a_base_len_index in range(a_base_len_up):
                # choose a candidate action
                action_check_up = a_collection_copy_up[a_base_len_index]
                # The selected action should firstly satisfy the QoS and the service availability constraints
                # Step 1: check whether the service availability constraint is violated
                vio_count = 0
                # The step 1 is commented because S2 should reflect whether the generated action violate the constraints
                for j_ap_index in range(int(args['ap_number'])):
                    if np.sum(action_check_up[:, j_ap_index]) > service_ability_up[j_ap_index]:
                        vio_count = vio_count + 1

                if not vio_count and np.sum(action_check_up):
                    # verify the effectiveness of the selected action,
                    # the feasibility only indicates that actions will make the power control problem feasibility
                    user_power, pro_feasibility_final = \
                        uplink_scenario.uplink_optimization(action_check_up, user_location, ap_location, q_plus,
                                                            user_height, float(args['ap_height']))

                    if pro_feasibility_final:  # all actions should be feasible
                        # calculate the reward of the selected action
                        # obtain the objective function value
                        # power_sum = np.dot(q_plus, (np.array(user_power) -
                        #                             (10 ** (float(args['average_total_user_power']) / 10) -
                        #                              10 ** (float(args['user_circuit_power']) / 10)) *
                        #                             np.sum(action_check_up, 1))) + 0.001  # for dividing zero
                        power_sum = np.dot(10 ** (float(args['user_circuit_power']) / 10) + np.array(user_power),
                                           np.sum(action_check_up, 1)) / \
                                    (10 ** (float(args['average_total_user_power']) / 10) *
                                     np.sum(action_check_up))

                        # calculate the maximize - f(p_t), for maximizing - f(p_t)
                        reward_collection[a_base_len_index] = - power_sum + float(args['tradeoff_coefficient_v']) / \
                                                              int(args['user_number']) * \
                                                              int(np.sum(np.max(action_check_up, 1)))
                else:
                    user_power = np.ones((int(args['user_number']), ))
                user_power_collection.append(user_power)

            # # # # # # #  choose one action from the action set
            # #  -----------------    find the action such that the reward is minimized      #  #
            max_index_up, max_value_up = max(enumerate(reward_collection), key=operator.itemgetter(1))
            pro_feasibility_final = False
            if max_value_up != -inf:
                pro_feasibility_final = True

            # Get the best action
            a_up = a_collection_copy_up[max_index_up]
            active_user_num_testing = np.sum(a_up)
            user_power = user_power_collection[max_index_up]

            if pro_feasibility_final:
                feasible_up = True
            else:
                feasible_up = False

            for state_index in range(int(args['ap_number'])):
                state_uplink_s2[state_index] = int(np.sum(a_up[:, state_index])) / service_ability_up[0]
            # step two (2):  The channel gain coefficients of S2
            ap_offset_up = int(args['ap_number'])
            hijt = uplink_scenario.pathloss_calculate(user_location, ap_location, user_height, float(args['ap_height']))
            hijt -= hijt.mean()
            assert hijt.std() > 0
            hijt /= hijt.std()
            state_uplink_s2[range(ap_offset_up, ap_offset_up+int(args['user_number'])*int(args['ap_number']))] = hijt

            # step three (3): The user power consumption
            channelgain_offset_up = int(args['user_number']) * int(args['ap_number'])
            s2_index = ap_offset_up + channelgain_offset_up
            user_power -= user_power.mean()
            # if not user_power.std():
            #     hd_test = 1
            # assert user_power.std() > 0
            user_power /= (user_power.std()+0.002)
            state_uplink_s2[range(s2_index, s2_index+int(args['user_number']))] = user_power

            if not np.sum(state_uplink_s2[range(int(args['ap_number']))] > 1):
                ability_violation_up = False
            else:
                ability_violation_up = True

            if feasible_up and not ability_violation_up:
                if max_value_up != -inf:
                    r_up = max_value_up
                else:
                    r_up = 0
            else:
                r_up = past_reward - 10 * np.abs(past_reward)
                # if max_value_up != -inf:
                #     r_up = max_value_up - 10 * np.abs(max_value_up)
                # else:
                #     r_up = -10
            # print("r[" + str(train_iter) + "]=" + str(r_up))
            past_reward = r_up

            # s2, r, terminal, info = env.step(a[0])
            initial_forgot_count = initial_forgot_count + 1
            if initial_forgot_count > int(args['forgot_len']):
                replay_buffer_uplink.add(np.reshape(state_uplink, (actor_uplink.s_dim,)),
                                         np.reshape(a_up, (actor_uplink.a_dim,)), r_up,
                                         np.reshape(state_uplink_s2, (actor_uplink.s_dim,)))

            # Keep adding experience to the memory until
            # there are at least minibatch size samples
            if replay_buffer_uplink.size() > int(args['minibatch_size']):
                s_batch_up, a_batch_up, r_batch_up, s2_batch_up = \
                    replay_buffer_uplink.sample_batch(int(args['minibatch_size']))

                Q_i_up = []
                for k in range(int(args['minibatch_size'])):
                    Q_i_up.append(r_batch_up[k])
                opt_out_batch_up = np.reshape(Q_i_up, (int(args['minibatch_size']), 1))

                ep_ave_max_q_up += np.amax(opt_out_batch_up)

                if replay_buffer_uplink.size() % int(args['training_interval']) == 0:
                    # train the actor network
                    _, critic_loss_value_up = actor_uplink.train(s_batch_up, a_batch_up)
                    # save the loss value
                    critic_loss_collection_up.append(critic_loss_value_up)
                    # save the reward
                    reward_train_interval_collection.append(r_up)
                    print('| Epoch: {:d} | The training loss is: {:.4f}'.format(j, critic_loss_value_up))

            state_uplink = state_uplink_s2
            ep_reward_up += r_up
            train_iter += 1
            reward_t_collection.append(r_up)

        # statistical results collection after one episode
        summary_str = sess.run(summary_ops, feed_dict={
            summary_vars[0]: ep_reward_up,
            summary_vars[1]: ep_ave_max_q_up /
                             (float(args['max_episode_len']) - int(args['forgot_len']) - int(args['minibatch_size']))
        })

        writer.add_summary(summary_str, i)
        writer.flush()

        print('| Reward: {:d} | Episode: {:d} | Running time this epoch: {:.4f} seconds'.format(int(ep_reward_up), i,
                                                                                             time.time() - sum_time))

        # save the trained model, i.e., sess parameters in each episode

        ul_save_path = saver.save(sess, path + '/UL_DNN_model_' + 'uplink_UserNum' + str(int(args['user_number'])) +
                                  '_' + str(i) + '.ckpt',
                                  write_meta_graph=False)
        print('Model:' + ul_save_path)

        # print('Network disconnect times over epoch: {:d} | Out of boundary times over epoch: {:d}'.format(
        #     int(disconnect_epoch), int(out_of_boundary_counter_epoch)))

    # # plot the loss value of the critic network
    # plt.figure(1)
    # plt.plot(critic_loss_collection_up)
    # plt.show()
    # plt.figure(2)
    # plt.plot(reward_train_interval_collection)
    # plt.show()
    # plt.figure(3)
    # plt.plot(reward_t_collection)
    # plt.show()
    # pass
    if mode is 'OP':
        file_name = 'OP_uplink_critic_loss_' + str(int(args['user_number'])) + '.mat'
        io.savemat(file_name, {'uplink_critic_loss': critic_loss_collection_up})
        file_name = 'OP_UL_reward_interval_value_' + str(int(args['user_number'])) + '.mat'
        io.savemat(file_name, {'reward_interval_value': reward_train_interval_collection})
        file_name = 'OP_UL_reward_t_value_' + str(int(args['user_number'])) + '.mat'
        io.savemat(file_name, {'reward_t_value': reward_t_collection})
    elif mode is 'KNN':
        file_name = 'KNN_uplink_critic_loss_' + str(int(args['user_number'])) + '.mat'
        io.savemat(file_name, {'uplink_critic_loss': critic_loss_collection_up})
        file_name = 'KNN_UL_reward_interval_value_' + str(int(args['user_number'])) + '.mat'
        io.savemat(file_name, {'reward_interval_value': reward_train_interval_collection})
        file_name = 'KNN_UL_reward_t_value_' + str(int(args['user_number'])) + '.mat'
        io.savemat(file_name, {'reward_t_value': reward_t_collection})
    else:
        print('The mode must be OP or KNN, the results are not saved!')


# ===========================
#   Agent Testing
# ===========================


def test_uplink(sess, env_task, args, actor_uplink, path,
                 ap_location, user_location_collection, seq_len_min_index,
                 interfering_user_list, interfering_user_array, num_groups, user_height, mode):
    # create a folder
    # subpath = path + '/uplink_test_results'
    # mkdir(subpath)
    if mode is 'OP':
        path = path + '/OP_DNN_UL_training_' + str(int(args['user_number']))
        mkdir(path)
    elif mode is 'KNN':
        path = path + '/KNN_DNN_UL_training_' + str(int(args['user_number']))
        mkdir(path)
    else:
        print('The mode must be OP or KNN!')

    # saver = tf.train.Saver(max_to_keep=int(args['max_episodes']))
    saver = tf.train.Saver()  # the maximum number of recent checkpoints to save is 1
    # as the actor network is initialized, we can restore the network parameters
    # restore_dir = path + '/DNN_uplink_trained_para_ckpt'
    # saver.restore(sess, tf.train.latest_checkpoint(restore_dir))
    saver.restore(sess, path + '/UL_DNN_model_' + 'uplink_UserNum' + str(int(args['user_number'])) + '_' +
                  str(int(int(args['max_episodes'])-1)) + '.ckpt')
    # Initialize the scenario
    uplink_scenario = UplinkScenarioNoInterference(env_task,
                                                   float(args['noise_power']),
                                                   float(args['uplink_bandwidth']),
                                                   int(args['ap_number']),
                                                   float(args['uplink_QoS']),
                                                   float(args['alpha']),
                                                   int(args['user_number']),
                                                   interfering_user_list,
                                                   interfering_user_array,
                                                   num_groups,
                                                   10 ** (float(args['inst_total_user_power']) / 10) -
                                                   10 ** (float(args['user_circuit_power']) / 10),
                                                   float(args['rayleigh_gain'])
                                                   )
    # Initialize the interfering indicator matrix
    uplink_scenario.initialize_interfering_indicator_matrix()

    # (Awaiting) should call a function to obtain [Q]^+ vector
    q_plus = np.ones((int(args['user_number']),))
    q_collection = []
    for i_q in range(int(args['user_number'])):
        q_collection.append([100.])

    sum_time = time.time()

    # Initialize users' locations
    user_location = []
    for num_user in range(int(args['user_number'])):
        user_i_loc = user_location_collection[num_user]  # a 2-array in R^{T * 2}
        # get the user location at time slot t = 10
        user_location.append(user_i_loc[:, 0].tolist())
    user_location = np.array(user_location)  # all users' locations

    service_ability_up = np.ones((int(args['ap_number']),)) * int(args['ap_uplink_serving_users'])
    # obtain the h_matrix in R^{num_antenna, num_antenna * num_user * num_ap}
    distance_ij_matrix_up = np.zeros((int(args['user_number']), int(args['ap_number'])))

    # ==========================
    #       initialize  state;  it is an one-dimensional array | 1-d array
    # ==========================
    s_dim = int(args['ap_number']) + int(args['user_number']) * int(args['ap_number']) + int(args['user_number'])
    state_uplink = np.zeros((s_dim,))
    # specify the number of users served by each ap, using the nearest principle
    # update the distance_ij_matrix
    for user_index in range(int(args['user_number'])):
        for ap_index in range(int(args['ap_number'])):
            distance_ij_matrix_up[user_index][ap_index] = \
                uplink_scenario.dis_calculate(user_index, ap_index, user_location, ap_location,
                                              user_height, float(args['ap_height']))

    init_j_star = []  # the index of j_star for each user i
    init_aij = np.zeros((int(args['user_number']), int(args['ap_number'])))
    for user_index in range(int(args['user_number'])):
        dis_list = distance_ij_matrix_up[user_index].tolist()
        init_j_star.append(dis_list.index(np.min(distance_ij_matrix_up[user_index])))
        init_aij[user_index, init_j_star[user_index]] = 1

    for ap_index in range(int(args['ap_number'])):
        state_uplink[ap_index] = np.sum(init_aij[:, ap_index]) / service_ability_up[0]

    # specify the channel gain coefficients
    ap_offset = int(args['ap_number'])
    channelgain_offset = int(args['user_number']) * int(args['ap_number'])

    hijt = uplink_scenario.pathloss_calculate(user_location, ap_location, user_height, float(args['ap_height']))
    hijt -= hijt.mean()
    assert hijt.std() > 0
    hijt /= hijt.std()
    state_uplink[range(ap_offset, ap_offset + channelgain_offset)] = hijt

    # specify the user power
    user_power = np.random.rand((int(args['user_number']))) * 20
    user_power -= user_power.mean()
    assert user_power.std() > 0
    user_power /= user_power.std()
    state_uplink[
        range(ap_offset + channelgain_offset, ap_offset + channelgain_offset + int(args['user_number']))] = user_power

    ep_reward_up = 0
    accumulated_ep_reward_up = []
    reward_up_real_time = []
    train_iter = 0
    count_t = 0
    past_reward = 1.0
    for j in range(int(args['max_episode_len_test'])):
        # update the users' locations every x times
        if int(train_iter % int(np.ceil(int(args['max_episode_len_test']) /
                                        len(user_location_collection[seq_len_min_index][0, :])))) == 0:
            # obtain a user's location
            user_location = []
            for num_user in range(int(args['user_number'])):
                user_i_loc = user_location_collection[num_user]  # a 2-array in R^{T * 2}
                # get the user location at time slot t = 10
                user_location.append(user_i_loc[:, count_t].tolist())
            user_location = np.array(user_location)  # all users' locations

            # user_location = np.array([[0, 0], [150, 150], [600, 200], [300, 360]])
            # ap_location = np.array([[100.0, 200.0], [400.0, 600.0], [330.0, 460.0]])  # it is a list

            # antenna_gain = np.ones((int(args['user_number']), int(args['ap_number'])))
            service_ability_up = np.ones((int(args['ap_number']),)) * int(args['ap_uplink_serving_users'])
            # obtain the h_matrix in R^{num_antenna, num_antenna * num_user * num_ap}
            distance_ij_matrix_up = np.zeros((int(args['user_number']), int(args['ap_number'])))
            for user_index in range(int(args['user_number'])):
                for ap_index in range(int(args['ap_number'])):
                    distance_ij_matrix_up[user_index][ap_index] = \
                        uplink_scenario.dis_calculate(user_index, ap_index, user_location, ap_location,
                                                      user_height, float(args['ap_height']))
            count_t += 1
        # initialize the data structure for training, save in row format
        state_uplink_s2 = np.zeros((s_dim,)) + 0.0001

        # ========================
        #           state 2
        # ========================
        # Calculate the sample action a = \mu(s|\theta^{\mu}), add exploration noise using the EE scheme
        a_ori_up = actor_uplink.predict(np.reshape(state_uplink, (1, actor_uplink.s_dim)))

        a_collection_up = []  # list, R^{i <= a_base_len}, each element is a 2d array
        a_base_collection_up = []  # it includes the objective function value of each candidate action by summing a row

        # # # # # # # # # # # # -------------------------------- # # # # # # # #
        # # # ------ Quantize the original action to K <= N action vectors, 2-d array, R^{user_number, ap_number}
        a_ori_2array_up = np.array(a_ori_up).reshape((int(args['user_number']), int(args['ap_number'])))

        # step one: order the original action
        a_ori_user_up = np.max(a_ori_2array_up, 1)  # 1-d array, R^{user_number}, the maximum action

        a_base_ascend_up = np.argsort(np.abs(a_ori_user_up))
        assert len(a_base_ascend_up.tolist()) == int(args['user_number']), \
            "The utilization of the list operator is wrong!"

        ability_violation_up = True  # an indicator indicates whether the service ability constraint is violated

        a_base_len_up = len(a_base_ascend_up)
        a_intermed_collection_2array_up = np.ones((int(args['user_number']), int(args['user_number'])))
        # # # # # # ----  Case II:  -----  # # # # # # #
        # obtain all the reference base actions

        # Two methods of generating the candidate actions
        if mode is 'OP':
            # step two: generate the 1st candidate action
            # set the reference base be 0.5; as sigmoid(0) = 0.5, and we did not activate the output with sigmoid
            a_base_collection_up.append(1 * (a_ori_user_up > 0))
            if int(args['user_number']) > 1:
                # step three: generate other candidate actions
                idx_array = a_base_ascend_up[:int(args['user_number']) - 1]
                for base_index in range(int(args['user_number']) - 1):
                    if a_ori_user_up[idx_array[base_index]] > 0:
                        # set a positive user to 0
                        a_base_collection_up.append(1 * (a_ori_user_up - a_ori_user_up[idx_array[base_index]] > 0))
                    else:
                        # set a negtive user to 1
                        a_base_collection_up.append(1 * (a_ori_user_up - a_ori_user_up[idx_array[base_index]] >= 0))
            a_intermed_collection_2array_up = np.array(a_base_collection_up)
        elif mode is 'KNN':
            # list all 2^N binary offloading actions
            enumerate_actions = np.array(list(map(list, itertools.product([0, 1], repeat=int(args['user_number'])))))

            # the 2-norm
            sqd = ((enumerate_actions - a_ori_user_up) ** 2).sum(1)
            idx = np.argsort(sqd)
            a_intermed_collection_2array_up = enumerate_actions[idx[:int(args['user_number'])]]
        else:
            print("The action selection must be 'OP' or 'KNN'")

        # recover the quantized action set according to the ref base actions
        # a_intermed_collection_2array, all intermediate candidate actions, 2d array,R^{a_base_len, user_number}
        for a_base_len_index in range(a_base_len_up):
            immed_action_up = copy.deepcopy(a_ori_2array_up)  # 2d array, R^{user_number, ap_number}
            for user_index in range(int(args['user_number'])):
                immed_action_up[user_index] = np.zeros((int(args['ap_number']),))
                if a_intermed_collection_2array_up[a_base_len_index][user_index] == 1:
                    # obtain the index of the maximum value in a[i]
                    max_index, max_value = max(enumerate(a_ori_2array_up[user_index].tolist()),
                                               key=operator.itemgetter(1))
                    immed_action_up[user_index][max_index] = int(1)
            # collect the candidate actions, the length is a_base_len
            # a_base_len: the number of candidate actions
            a_collection_up.append(immed_action_up)  # list, R^{a_base_len}, each element is a 2d array

        # copy the a_collection
        a_collection_copy_up = copy.deepcopy(a_collection_up)

        # # # # # # # #   ------------------------------------   # # # # # # # #
        # # # # # Verify the effectiveness of the candidate actions, and choose the one minimizing the reward
        reward_collection = np.ones((a_base_len_up,)) * (-inf)
        user_power_collection = []
        for a_base_len_index in range(a_base_len_up):
            # choose a candidate action
            action_check_up = a_collection_copy_up[a_base_len_index]
            # The selected action should firstly satisfy the QoS and the service availability constraints
            # Step 1: check whether the service availability constraint is violated
            vio_count = 0
            # The step 1 is commented because S2 should reflect whether the generated action violate the constraints
            for j_ap_index in range(int(args['ap_number'])):
                if np.sum(action_check_up[:, j_ap_index]) > service_ability_up[j_ap_index]:
                    vio_count = vio_count + 1

            if not vio_count and np.sum(action_check_up):
                # verify the effectiveness of the selected action,
                # the feasibility only indicates that actions will make the power control problem feasibility
                user_power, pro_feasibility_final = \
                    uplink_scenario.uplink_optimization(action_check_up, user_location, ap_location, q_plus,
                                                        user_height, float(args['ap_height']))

                if pro_feasibility_final:  # all actions should be feasible
                    # calculate the reward of the selected action
                    # obtain the objective function value
                    # power_sum = np.dot(q_plus, (np.array(user_power) -
                    #                             (10 ** (float(args['average_total_user_power']) / 10) -
                    #                              10 ** (float(args['user_circuit_power']) / 10)) *
                    #                             np.sum(action_check_up, 1))) + 0.001  # for dividing zero
                    power_sum = np.dot(10 ** (float(args['user_circuit_power']) / 10) + np.array(user_power),
                                       np.sum(action_check_up, 1)) / \
                                (10 ** (float(args['average_total_user_power']) / 10) *
                                 np.sum(action_check_up))

                    # calculate the maximize - f(p_t), for maximizing - f(p_t)
                    reward_collection[a_base_len_index] = - power_sum + float(args['tradeoff_coefficient_v']) / \
                                                          int(args['user_number']) * \
                                                          int(np.sum(np.max(action_check_up, 1)))
            else:
                user_power = np.ones((int(args['user_number']),))
            user_power_collection.append(user_power)

        # # # # # # #  choose one action from the action set
        # #  -----------------    find the action such that the reward is minimized      #  #
        max_index_up, max_value_up = max(enumerate(reward_collection), key=operator.itemgetter(1))
        pro_feasibility_final = False
        if max_value_up != -inf:
            pro_feasibility_final = True

        # Get the best action
        a_up = a_collection_copy_up[max_index_up]
        active_user_num_testing = np.sum(a_up)
        user_power = user_power_collection[max_index_up]

        if pro_feasibility_final:
            feasible_up = True
        else:
            feasible_up = False

        for state_index in range(int(args['ap_number'])):
            state_uplink_s2[state_index] = int(np.sum(a_up[:, state_index])) / service_ability_up[0]
        # step two (2):  The channel gain coefficients of S2
        ap_offset_up = int(args['ap_number'])
        hijt = uplink_scenario.pathloss_calculate(user_location, ap_location, user_height, float(args['ap_height']))
        hijt -= hijt.mean()
        assert hijt.std() > 0
        hijt /= hijt.std()
        state_uplink_s2[range(ap_offset_up, ap_offset_up + int(args['user_number']) * int(args['ap_number']))] = hijt

        # step three (3): The user power consumption
        channelgain_offset_up = int(args['user_number']) * int(args['ap_number'])
        s2_index = ap_offset_up + channelgain_offset_up
        user_power -= user_power.mean()
        # if not user_power.std():
        #     hd_test = 1
        # assert user_power.std() > 0
        user_power /= (user_power.std() + 0.002)
        state_uplink_s2[range(s2_index, s2_index + int(args['user_number']))] = user_power

        if not np.sum(state_uplink_s2[range(int(args['ap_number']))] > 1):
            ability_violation_up = False
        else:
            ability_violation_up = True

        if feasible_up and not ability_violation_up:
            if max_value_up != -inf:
                r_up = max_value_up
            else:
                r_up = 0
        else:
            r_up = 0
            # if max_value_up != -inf:
            #     r_up = max_value_up - 10 * np.abs(max_value_up)
            # else:
            #     r_up = -10
        # print("r[" + str(train_iter) + "]=" + str(r_up))
        past_reward = r_up

        # ======================
        # #         s = s2
        # #    for the next epoch
        # ======================
        state_uplink = state_uplink_s2
        ep_reward_up += r_up
        accumulated_ep_reward_up.append(ep_reward_up)
        reward_up_real_time.append(r_up)
        train_iter += 1

        # print('| Accumulated Reward: {:d} | Epoch: {:d}'.format(int(ep_reward_up), j))

    if mode is 'OP':
        file_name = 'Test_OP_UL_reward_t_value_' + str(int(args['user_number'])) + '.mat'
        io.savemat(file_name, {'reward_t_value': reward_up_real_time})
    elif mode is 'KNN':
        file_name = 'Test_KNN_UL_reward_t_value_' + str(int(args['user_number'])) + '.mat'
        io.savemat(file_name, {'reward_t_value': reward_up_real_time})
    else:
        print('The mode must be OP or KNN, the results are not saved!')

#
#     plt.figure(2, figsize=(6, 3))
#     plt.subplot(121)
#     plt.scatter(9, energy_efficiency)
#     # only this sub-figure is not shown originally
#     plt.subplot(122)
#     plt.plot(profit_time)
#     plt.show()
#
#     # the x-axis is time slot t
#     plt.figure(3, figsize=(9, 3))
#     plt.subplot(131)
#     plt.plot(accumulate_reward_time)
#     plt.subplot(132)
#     plt.plot(average_coverage_ratio_time)
#     plt.subplot(133)
#     plt.plot(fairness_time)
#     plt.show()
#
#     print('| coverage_ratio_T: {:.4f} | fairness_T: {:.4f} | normalized_energy: {:.4f} | energy_efficiency: {:.4f}'
#           .format(average_coverage_ratio_all_t, fairness_all_t,
#                   normalized_average_uav_energy_consumption, energy_efficiency))
#
#     # print the times of out_of boundary and network disconnect
#     print('Network disconnect times when testing: {:d} | Out of boundary times when testing: {:d}'.format(
#         int(disconnect_test), int(out_of_boundary_counter_test)))


def main(args):
    start_time = time.time()
    # gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=0.7)
    with tf.Session() as sess:

        # env = gym.make(args['env'])
        np.random.seed(int(args['random_seed']))
        tf.set_random_seed(int(args['random_seed']))
        # env.seed(int(args['random_seed']))

        # generate user locations
        # (Awaiting) load the original data
        user_location_collection = []
        user_location_len = []
        min_x = []
        min_y = []
        max_x = []
        max_y = []
        for num_user in range(int(args['user_number'])):
            data_path = 'C:/Users/swan/PycharmProjects/Federated_ESN_VR/original_data_sets/Predicted_Trajectory_' + \
                        str(num_user + 1) + '.mat'
            data = sio.loadmat(data_path)
            print(data.keys())
            # ori_data = data['userInterpLocations']  # a 2-array in R^{T*2}
            ori_data = data['predicted_trajectory']

            min_x.append(np.min(ori_data[:, 0]))
            min_y.append(np.min(ori_data[:, 1]))
            max_x.append(np.max(ori_data[:, 0]))
            max_y.append(np.max(ori_data[:, 1]))

            # find the minimum sequence length of all user data
            user_location_len.append(len(ori_data[:, 0]))
            user_location_collection.append(ori_data)  # a list including 64 2-arrays

        # obtain the boundary of user locations
        min_loc_x = np.min(min_x)
        min_loc_y = np.min(min_y)
        max_loc_x = np.max(max_x)
        max_loc_y = np.max(max_y)

        # calculate the radius of a circular communication coverage region
        radius_comm = np.sqrt((max_loc_y - min_loc_y) ** 2 + (max_loc_x - min_loc_x) ** 2) / 2

        # obtain the aps' locations
        ap_location = np.zeros((int(args['ap_number']), 2))
        for j in range(int(args['ap_number'])):
            ap_location[j, 0] = radius_comm * np.cos(2 * np.pi / int(args['ap_number']) * j) + radius_comm
            ap_location[j, 1] = radius_comm * np.sin(2 * np.pi / int(args['ap_number']) * j) + radius_comm

        seq_len_min_index = user_location_len.index(min(user_location_len))

        # Description of the uplink state: 1) the number of users served by ap j for all j;
        # 2) if ap j is service ability violated, whether user i results in it;
        # 3) if the QoS constraint of user j is violated, whether user i leads to it;
        # 4) how many interference users does user i have;
        # 5) 1 represents whether the uplink prob is feasible under the given action.
        state_dim_uplink = int(args['ap_number']) + int(args['user_number']) * int(args['ap_number']) + \
                           int(args['user_number'])
        # for each user i and each ap j, the value of a_{ij}^{dl}
        action_dim_uplink = int(args['user_number']) * int(args['ap_number'])

        # generate the users' heights
        user_height = np.random.normal(float(args['user_height']),
                                       float(args['user_height_std']), int(args['user_number']))

        # clustering users into four groups, where only users in the same group will interfere with each other
        interfering_user_list = list(range(int(args['user_number'])))
        np.random.shuffle(interfering_user_list)
        interfering_user_array = \
            np.reshape(interfering_user_list, (int(args['user_groups']),
                                                int(int(args['user_number'])/int(args['user_groups']))))  # a 2-array

        Run = False
        # Run = True  # testing
        mode = 'OP'    # the quantization mode could be 'OP' (Order-preserving) or 'KNN'
        if not Run:
            actor_uplink = ActorNetworkUplink(sess, state_dim_uplink, action_dim_uplink, float(args['actor_lr']),
                             np.int16(args['minibatch_size']))
            path = 'DNN_uplink_trained_para_ckpt'
            with mosek.Env() as env_task:
                # create mosek task
                train_uplink(sess, env_task, args, actor_uplink, path,
                             ap_location, user_location_collection, seq_len_min_index,
                             interfering_user_list, interfering_user_array, int(args['user_groups']), user_height, mode)
        else:
            actor_uplink = ActorNetworkUplink(sess, state_dim_uplink, action_dim_uplink, float(args['actor_lr']),
                                              np.int16(args['minibatch_size']))
            path = 'DNN_uplink_trained_para_ckpt'
            with mosek.Env() as env_task:
                # create mosek task
                test_uplink(sess, env_task, args, actor_uplink, path,
                            ap_location, user_location_collection, seq_len_min_index,
                            interfering_user_list, interfering_user_array, int(args['user_groups']), user_height, mode)

        # print the running time of this program
        print("The running time of this program is --- %.4f seconds ---" % (time.time() - start_time))
        # if args['use_gym_monitor']:
        #     env.monitor.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='provide arguments for DDPG agent')

    # agent parameters
    parser.add_argument('--actor-lr', help='actor network learning rate', default=0.1)
    # parser.add_argument('--critic-lr', help='critic network learning rate', default=0.01)
    parser.add_argument('--gamma', help='discount factor for critic updates', default=0.99)
    parser.add_argument('--tau', help='soft target update parameter', default=0.001)
    parser.add_argument('--buffer-size', help='max size of the replay buffer', default=1000000)  # 1000000
    parser.add_argument('--minibatch-size', help='size of minibatch for minibatch-SGD', default=64)  # 1024
    parser.add_argument('--forgot-len', help='length of initial forgotten samples', default=200)  # 1024
    parser.add_argument('--training-interval', help='training interval', default=20)  # 10
    # deployment scenario parameters
    # user configuration
    parser.add_argument('--average-total-user-power', help='the average total user power', default=28.5)  # in dBm 700
    parser.add_argument('--inst-total-user-power', help='the total instant user power', default=27.0)  # in dBm28.76
    parser.add_argument('--user-circuit-power', help='user circuit power', default=23.0)  # in dBm
    parser.add_argument('--noise-power', help='noise power', default=-167.0)  # 107.0
    parser.add_argument('--uplink-bandwidth', help='uplink bandwidth', default=200)  # in MHz, 20MHz  4GHz/num_groups
    parser.add_argument('--alpha', help='the path loss coefficient', default=5.0)  # 2-4
    parser.add_argument('--tradeoff-coefficient-v', help='the tradeoff coefficient value V', default=1)  # 200
    parser.add_argument('--uplink-QoS', help='the QoS of uplink transmission', default=200)  # .2 in times or 20 dB
    parser.add_argument('--user-number', help='the number of users', default=20)  # 64
    parser.add_argument('--user-groups', help='the group number of users', default=20)  # classify users into 4 groups
    parser.add_argument('--user-height', help='the height of a user', default=1.8)
    parser.add_argument('--user-height-std', help='the standard variance of the height of a user', default=0.05)
    parser.add_argument('--rayleigh-gain', help='the Rayleigh channel gain', default=0.3)


    # ap configuration
    parser.add_argument('--ap-power', help='the ap power', default=230.0)
    parser.add_argument('--ap-inst-power', help='the instant ap power', default=30.0)
    parser.add_argument('--downlink-bandwidth', help='the downlink bandwidth', default=200)  # in MHz
    parser.add_argument('--ap-number', help='the number of aps', default=3)
    parser.add_argument('--antenna-number', help='the number of antennas', default=2)
    parser.add_argument('--downlink-QoS', help='the QoS of downlink transmission', default=0.02)
    parser.add_argument('--eta-LoS', help='max length of 1 episode for test', default=2.0)
    parser.add_argument('--eta-NLoS', help='max length of 1 episode for test', default=2.4)
    parser.add_argument('--sigma-LoS', help='max length of 1 episode for test', default=5.3)
    parser.add_argument('--sigma-NLoS', help='max length of 1 episode for test', default=5.27)
    parser.add_argument('--light-speed', help='max length of 1 episode for test', default=3e+8)
    parser.add_argument('--carrier-frequency', help='the carrier frequency of downlink transmission', default=2.8e+10)
    parser.add_argument('--ap-uplink-serving-users', help='number of uplink serving users of the ap', default=7)  # [3 5 6 7]
    parser.add_argument('--ap-height', help='height of an ap', default=5.5)

    parser.add_argument('--max-episode-len-test', help='max length of 1 episode for test', default=5000)

    # run parameters
    parser.add_argument('--env', help='choose the gym env- tested on {Pendulum-v0}', default='Pendulum-v0')
    parser.add_argument('--random-seed', help='random seed for repeatability', default=1234)
    parser.add_argument('--max-episodes', help='max num of episodes to do while training', default=10)  # 2000
    parser.add_argument('--max-episode-len', help='max length of 1 episode', default=1000)  # 2000
    parser.add_argument('--render-env', help='render the gym env', action='store_true')
    parser.add_argument('--use-gym-monitor', help='record gym results', action='store_true')
    parser.add_argument('--monitor-dir', help='directory for storing gym results', default='./results/gym_ddpg')
    parser.add_argument('--summary-dir', help='directory for storing tensorboard info', default='./results/tf_ddpg')

    parser.set_defaults(render_env=False)
    parser.set_defaults(use_gym_monitor=True)

    args = vars(parser.parse_args())

    pp.pprint(args)

    main(args)